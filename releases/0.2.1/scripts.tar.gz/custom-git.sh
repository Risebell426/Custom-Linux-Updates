#!/usr/bin/env bash

# custom-git.sh
#
# Einfache Git-Steuerung für das Custom-Linux-Projekt.
#
# Funktionen:
# - Status anzeigen
# - Änderungen anzeigen
# - Dateien per Checkbox auswählen und stagen
# - alle Änderungen stagen
# - gestagte Änderungen anzeigen
# - Commit erstellen
# - Commit erstellen und pushen
# - Pull ausführen
# - letzte Commits anzeigen
# - komplettes Staging rückgängig machen
#
# Der normale Git-Befehl wird nicht ersetzt.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(dirname -- "$SCRIPT_PATH")"

export DIALOGRC="$SCRIPT_DIR/custom-dialogrc"

PROJECT_ROOT=""
TEMP_DIR=""

cleanup() {
    if [[ -n "${TEMP_DIR:-}" && -d "$TEMP_DIR" ]]; then
        rm -rf -- "$TEMP_DIR"
    fi
}

trap cleanup EXIT

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

require_dialog_config() {
    if [[ ! -f "$DIALOGRC" ]]; then
        fail "Custom-Dialog-Konfiguration fehlt: $DIALOGRC"
    fi

    if [[ ! -r "$DIALOGRC" ]]; then
        fail "Custom-Dialog-Konfiguration ist nicht lesbar: $DIALOGRC"
    fi
}

find_project_root_from() {
    local current="$1"

    while [[ "$current" != "/" ]]; do
        if [[ -d "$current/.git" ]]; then
            printf '%s\n' "$current"
            return 0
        fi

        current="$(dirname -- "$current")"
    done

    return 1
}

detect_project_root() {
    PROJECT_ROOT="$(
        find_project_root_from "$SCRIPT_DIR" 2>/dev/null ||
        true
    )"

    if [[ -z "$PROJECT_ROOT" ]]; then
        PROJECT_ROOT="$(
            find_project_root_from "$PWD" 2>/dev/null ||
            true
        )"
    fi

    [[ -n "$PROJECT_ROOT" ]] ||
        fail "Kein Git-Projekt gefunden."
}

require_commands() {
    local command_name=""

    for command_name in base64 dialog git mktemp readlink tput; do
        command -v "$command_name" >/dev/null 2>&1 ||
            fail "Benötigter Befehl fehlt: $command_name"
    done
}

copy_file_to_clipboard() {
    local file="$1"
    local encoded=""

    if [[ -n "${WAYLAND_DISPLAY:-}" ]] &&
       command -v wl-copy >/dev/null 2>&1; then

        if wl-copy < "$file"; then
            return 0
        fi
    fi

    if [[ -n "${DISPLAY:-}" ]] &&
       command -v xclip >/dev/null 2>&1; then

        if xclip -selection clipboard < "$file"; then
            return 0
        fi
    fi

    if [[ -n "${SSH_CONNECTION:-}" ||
          "${XDG_SESSION_TYPE:-}" == "tty" ]]; then

        encoded="$(base64 -w0 < "$file")" || return 1

        printf '\033]52;c;%s\a' "$encoded"

        return 0
    fi

    return 1
}

show_file() {
    local title="$1"
    local file="$2"
    local result=0

    local terminal_rows=0
    local terminal_columns=0

    local box_width=110
    local main_height=30
    local help_height=5
    local gap=1

    local total_height=0
    local start_y=0
    local start_x=0
    local help_y=0

    if [[ ! -s "$file" ]]; then
        printf 'Keine Ausgabe.\n' > "$file"
    fi

    terminal_rows="$(tput lines)"
    terminal_columns="$(tput cols)"

    if (( terminal_columns < box_width + 4 )); then
        box_width=$((terminal_columns - 4))
    fi

    if (( box_width < 60 )); then
        box_width=60
    fi

    if (( terminal_rows < main_height + help_height + gap + 2 )); then
        main_height=$((terminal_rows - help_height - gap - 2))
    fi

    if (( main_height < 10 )); then
        main_height=10
    fi

    total_height=$((main_height + gap + help_height))

    start_y=$(((terminal_rows - total_height) / 2))
    start_x=$(((terminal_columns - box_width) / 2))

    if (( start_y < 0 )); then
        start_y=0
    fi

    if (( start_x < 0 )); then
        start_x=0
    fi

    help_y=$((start_y + main_height + gap))

    while true; do
        if dialog \
            --keep-window \
            --begin "$help_y" "$start_x" \
            --title "Bedienung" \
            --infobox \
            "Pfeile = scrollen\nTab / Shift+Tab = Button wechseln\nEnter = auswählen" \
            "$help_height" "$box_width" \
            --and-widget \
            --begin "$start_y" "$start_x" \
            --title "$title" \
            --ok-label "Zurück" \
            --extra-button \
            --extra-label "Kopieren" \
            --textbox "$file" \
            "$main_height" "$box_width"; then

            result=0
        else
            result=$?
        fi

        case "$result" in
            0|1|255)
                return
                ;;

            3)
                if copy_file_to_clipboard "$file"; then
                    show_message \
                        "Die komplette Ausgabe wurde in die Zwischenablage kopiert."
                else
                    show_message \
                        "Kopieren nicht möglich.\n\nKeine unterstützte Zwischenablage wurde gefunden."
                fi
                ;;
        esac
    done
}

show_message() {
    dialog \
        --clear \
        --title "Custom Git" \
        --msgbox "$1" \
        10 70
}

confirm_action() {
    dialog \
        --clear \
        --title "Bestätigung" \
        --yes-label "y" \
        --no-label "n" \
        --defaultno \
        --yesno "$1" \
        10 70
}

show_status() {
    local output="$TEMP_DIR/status.txt"

    {
        printf 'Projekt: %s\n\n' "$PROJECT_ROOT"
        git -C "$PROJECT_ROOT" status --short
    } > "$output"

    show_file "Git-Status" "$output"
}

show_changes() {
    local output="$TEMP_DIR/changes.txt"

    {
        printf '===== Nicht gestagte Änderungen =====\n\n'
        git -C "$PROJECT_ROOT" diff

        printf '\n\n===== Nicht versionierte Dateien =====\n\n'
        git -C "$PROJECT_ROOT" ls-files \
            --others \
            --exclude-standard
    } > "$output"

    show_file "Änderungen" "$output"
}

collect_changed_files() {
    local -n result_array="$1"
    local file=""

    result_array=()

    while IFS= read -r -d '' file; do
        result_array+=("$file")
    done < <(
        {
            git -C "$PROJECT_ROOT" diff --name-only -z
            git -C "$PROJECT_ROOT" ls-files \
                --others \
                --exclude-standard \
                -z
        } | awk -v RS='\0' '!seen[$0]++ { printf "%s%c", $0, 0 }'
    )
}

select_files_to_stage() {
    local -a files=()
    local -a dialog_items=()
    local -a selected_numbers=()

    local index=0
    local file=""
    local selection=""

    collect_changed_files files

    if (( ${#files[@]} == 0 )); then
        show_message "Es gibt aktuell keine Änderungen zum Stagen."
        return
    fi

    for index in "${!files[@]}"; do
        file="${files[$index]}"

        dialog_items+=(
            "$index"
            "$file"
            "off"
        )
    done

    selection="$(
        dialog \
            --clear \
            --title "Dateien auswählen" \
            --separate-output \
            --checklist \
            "Leertaste = auswählen/abwählen\nEnter = bestätigen" \
            30 110 20 \
            "${dialog_items[@]}" \
            3>&1 1>&2 2>&3
    )" || return

    if [[ -z "$selection" ]]; then
        show_message "Keine Datei ausgewählt."
        return
    fi

    mapfile -t selected_numbers <<< "$selection"

    for index in "${selected_numbers[@]}"; do
        git -C "$PROJECT_ROOT" add -- "${files[$index]}"
    done

    show_message "Die ausgewählten Dateien wurden gestaged."
}

stage_all_changes() {
    if ! confirm_action \
        "Wirklich ALLE Änderungen des Projekts stagen?\n\nAuch neue und gelöschte Dateien werden aufgenommen."; then
        return
    fi

    git -C "$PROJECT_ROOT" add -A

    show_message "Alle Änderungen wurden gestaged."
}

show_staged_changes() {
    local output="$TEMP_DIR/staged.txt"

    {
        printf '===== Gestagte Dateien =====\n\n'
        git -C "$PROJECT_ROOT" diff --cached --name-status

        printf '\n\n===== Gestagter Diff =====\n\n'
        git -C "$PROJECT_ROOT" diff --cached
    } > "$output"

    show_file "Gestagte Änderungen" "$output"
}

ask_commit_message() {
    local message=""

    message="$(
        dialog \
            --clear \
            --title "Commit erstellen" \
            --inputbox \
            "Commit-Nachricht eingeben:" \
            10 80 \
            3>&1 1>&2 2>&3
    )" || return 1

    [[ -n "$message" ]] || {
        show_message "Commit abgebrochen: Keine Commit-Nachricht eingegeben."
        return 1
    }

    printf '%s\n' "$message"
}

create_commit() {
    local message=""
    local output="$TEMP_DIR/commit.txt"

    if git -C "$PROJECT_ROOT" diff --cached --quiet; then
        show_message "Es sind keine Änderungen für einen Commit gestaged."
        return 1
    fi

    message="$(ask_commit_message)" || return 1

    if ! confirm_action \
        "Commit mit dieser Nachricht erstellen?\n\n$message"; then
        return 1
    fi

    if ! git -C "$PROJECT_ROOT" commit -m "$message" \
        > "$output" 2>&1; then

        show_file "Commit fehlgeschlagen" "$output"
        return 1
    fi

    show_message "Commit wurde erfolgreich erstellt."
}

commit_and_push() {
    local message=""
    local branch=""
    local commit_output="$TEMP_DIR/commit-push-commit.txt"
    local push_output="$TEMP_DIR/push.txt"

    if git -C "$PROJECT_ROOT" diff --cached --quiet; then
        show_message "Es sind keine Änderungen für einen Commit gestaged."
        return
    fi

    message="$(ask_commit_message)" || return

    branch="$(
        git -C "$PROJECT_ROOT" branch --show-current 2>/dev/null ||
        true
    )"

    if [[ -z "$branch" ]]; then
        show_message \
            "Kein normaler Git-Branch erkannt.\n\nMöglicherweise befindet sich das Repository im detached-HEAD-Zustand.\n\nCommit + Push wurde abgebrochen."
        return
    fi

    if ! git -C "$PROJECT_ROOT" remote get-url origin \
        >/dev/null 2>&1; then

        show_message \
            "Kein Git-Remote namens 'origin' gefunden.\n\nPrüfen mit:\ngit remote -v"
        return
    fi

    if ! confirm_action \
        "Commit erstellen und anschließend auf origin/$branch pushen?\n\n$message"; then
        return
    fi

    if ! git -C "$PROJECT_ROOT" commit -m "$message" \
        > "$commit_output" 2>&1; then

        show_file "Commit fehlgeschlagen" "$commit_output"
        return
    fi

    if ! git -C "$PROJECT_ROOT" push origin "$branch" \
        > "$push_output" 2>&1; then

        show_message \
            "Der Commit wurde lokal erfolgreich erstellt.\n\nDer Push zu origin/$branch ist jedoch fehlgeschlagen.\n\nDer lokale Commit bleibt erhalten."

        show_file "Push fehlgeschlagen" "$push_output"
        return
    fi

    show_message "Commit und Push waren erfolgreich."
}

pull_changes() {
    local branch=""
    local output="$TEMP_DIR/pull.txt"

    branch="$(
        git -C "$PROJECT_ROOT" branch --show-current 2>/dev/null ||
        true
    )"

    if [[ -z "$branch" ]]; then
        show_message \
            "Kein normaler Git-Branch erkannt.\n\nMöglicherweise befindet sich das Repository im detached-HEAD-Zustand.\n\nPull wurde abgebrochen."
        return
    fi

    if ! git -C "$PROJECT_ROOT" remote get-url origin \
        >/dev/null 2>&1; then

        show_message \
            "Kein Git-Remote namens 'origin' gefunden.\n\nPrüfen mit:\ngit remote -v"
        return
    fi

    if ! confirm_action \
        "Änderungen von origin/$branch herunterladen?"; then
        return
    fi

    if ! git -C "$PROJECT_ROOT" pull --ff-only origin "$branch" \
        > "$output" 2>&1; then

        show_file "Pull fehlgeschlagen" "$output"
        return
    fi

    show_message "Pull wurde erfolgreich abgeschlossen."
}

show_log() {
    local output="$TEMP_DIR/log.txt"

    git -C "$PROJECT_ROOT" log \
        --oneline \
        --decorate \
        -20 > "$output"

    show_file "Letzte 20 Commits" "$output"
}

unstage_all() {
    if git -C "$PROJECT_ROOT" diff --cached --quiet; then
        show_message "Aktuell ist nichts gestaged."
        return
    fi

    if ! confirm_action \
        "Komplettes Staging rückgängig machen?\n\nDie Dateien selbst werden NICHT gelöscht oder zurückgesetzt."; then
        return
    fi

    git -C "$PROJECT_ROOT" reset

    show_message "Staging wurde zurückgesetzt.\n\nDie lokalen Änderungen bleiben erhalten."
}

show_menu() {
    local choice=""

    while true; do
        choice="$(
            dialog \
                --clear \
                --title "Custom Linux - Git-Menü" \
                --menu \
                "Projekt:\n$PROJECT_ROOT\n\nAktion auswählen:" \
                28 90 15 \
                1 "Git-Status anzeigen" \
                2 "Änderungen anzeigen" \
                3 "Dateien auswählen und stagen" \
                4 "Alle Änderungen stagen" \
                5 "Gestagte Änderungen anzeigen" \
                6 "Commit erstellen" \
                7 "Commit erstellen + Push" \
                8 "Pull" \
                9 "Letzte Commits anzeigen" \
                10 "Komplettes Staging rückgängig machen" \
                0 "Beenden" \
                3>&1 1>&2 2>&3
        )" || exit 0

        case "$choice" in
            1)
                show_status
                ;;
            2)
                show_changes
                ;;
            3)
                select_files_to_stage
                ;;
            4)
                stage_all_changes
                ;;
            5)
                show_staged_changes
                ;;
            6)
                create_commit || true
                ;;
            7)
                commit_and_push
                ;;
            8)
                pull_changes
                ;;
            9)
                show_log
                ;;
            10)
                unstage_all
                ;;
            0)
                exit 0
                ;;
        esac
    done
}

main() {
    require_commands
    require_dialog_config
    detect_project_root

    TEMP_DIR="$(mktemp -d)"

    show_menu
}

main "$@"
