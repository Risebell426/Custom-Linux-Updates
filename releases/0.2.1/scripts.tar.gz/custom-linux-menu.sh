#!/usr/bin/env bash

# custom-linux-menu.sh
#
# Zentrale Steuerung für das Custom-Linux-Projekt.
#
# Das Skript erkennt automatisch, ob es läuft:
# - auf dem Arch-Bau-System,
# - im Custom-Linux-Live-System,
# - oder im installierten Custom-Linux.
#
# Die eigentliche Arbeit bleibt weiterhin in den einzelnen Skripten.
# Dieses Menü dient nur als gemeinsame, leicht bedienbare Oberfläche.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_PATH="$(
    readlink -f -- "${BASH_SOURCE[0]}"
)"

SCRIPT_DIR="$(
    cd -- "$(dirname -- "$SCRIPT_PATH")"
    pwd
)"

PROJECT_ROOT=""
ENVIRONMENT="unknown"
CHECK_ERRORS=0

info() {
    printf '[INFO] %s\n' "$*"
}


warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}


fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}


pause_menu() {
    printf '\n'
    read -r -p 'Enter drücken, um zum Menü zurückzukehren ...' _
}


confirm_action() {
    local answer=""

    printf '\n'
    read -r -p "$1 [y/N]: " answer

    case "$answer" in
        y|Y|yes|YES|Yes)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}


find_project_root_from() {
    local current="$1"

    while [[ "$current" != "/" ]]; do
        if [[ -d "$current/.git" ]] &&
           [[ -d "$current/archiso/releng" ]]; then
            printf '%s\n' "$current"
            return 0
        fi

        current="$(dirname -- "$current")"
    done

    return 1
}


detect_environment() {
    PROJECT_ROOT="$(
        find_project_root_from "$SCRIPT_DIR" 2>/dev/null ||
        true
    )"

    if [[ -z "$PROJECT_ROOT" ]]; then
        PROJECT_ROOT="$(
            find_project_root_from "$PWD" 2>/dev/null ||
            true
        )"
    fi

    if [[ -n "$PROJECT_ROOT" ]]; then
        ENVIRONMENT="build"
        return
    fi

    if [[ -d /root/custom-linux ]] &&
       command -v archinstall >/dev/null 2>&1; then
        ENVIRONMENT="live"
        return
    fi

    if [[ -d /opt/custom-linux-installer ]]; then
        ENVIRONMENT="installed"
        return
    fi

    ENVIRONMENT="unknown"
}


check_project_scripts() {

    local scripts=(
        "01-preflight-copy.sh"
        "02-postinstall-test.sh"
        "03-postinstall-setup.sh"
        "start-archinstall.sh"
        "save-archinstall-config.sh"
        "custom-linux-menu.sh"
        "custom-git.sh"
    )

    local script=""
    local path=""
    local errors=0
    local base="$PROJECT_ROOT/archiso/releng/airootfs/root/custom-linux"

    printf '\n'
    info "Prüfe Bash-Syntax aller Custom-Linux-Skripte."
    printf '\n'

    for script in "${scripts[@]}"; do
        path="$base/$script"

        if [[ ! -f "$path" ]]; then
            printf '[FEHLER] %-32s Datei fehlt\n' "$script"
            errors=$((errors + 1))
            continue
        fi

        if bash -n "$path"; then
            printf '[OK]     %s\n' "$script"
        else
            printf '[FEHLER] %s\n' "$script"
            errors=$((errors + 1))
        fi
    done

    printf '\n'
    info "Prüfe Git-Whitespace."

    if git -C "$PROJECT_ROOT" diff --check; then
        printf '[OK]     git diff --check\n'
    else
        printf '[FEHLER] git diff --check\n'
        errors=$((errors + 1))
    fi

    printf '\n'

    CHECK_ERRORS="$errors"

    if (( errors == 0 )); then
        info "Alle Prüfungen waren erfolgreich."
    else
        warn "$errors Prüfung(en) waren nicht erfolgreich."
    fi
}


show_git_status() {
    printf '\n'
    info "Git-Status:"
    printf '\n'

    git -C "$PROJECT_ROOT" status --short

    printf '\n'
    info "Aktueller Branch:"

    git -C "$PROJECT_ROOT" branch --show-current
}


show_iso_files() {
    local iso_directory="$PROJECT_ROOT/iso"

    printf '\n'

    if [[ ! -d "$iso_directory" ]]; then
        warn "ISO-Verzeichnis existiert noch nicht:"
        warn "$iso_directory"
        return
    fi

    info "Vorhandene ISO-Dateien:"
    printf '\n'

    find "$iso_directory" \
        -maxdepth 1 \
        -type f \
        -name '*.iso' \
        -printf '%TY-%Tm-%Td %TH:%TM  %10s Byte  %f\n' \
        | sort
}


build_iso() {
    local work_directory="$PROJECT_ROOT/build/work"
    local output_directory="$PROJECT_ROOT/iso"
    local profile_directory="$PROJECT_ROOT/archiso/releng"
    local newest_iso=""

    command -v mkarchiso >/dev/null 2>&1 ||
        fail "mkarchiso wurde auf diesem System nicht gefunden."

    if ! confirm_action "Altes Build-Arbeitsverzeichnis löschen und neue ISO bauen?"; then
        info "ISO-Build abgebrochen."
        return
    fi

    printf '\n'
    info "Prüfe zuerst die Skripte."

    check_project_scripts

if (( CHECK_ERRORS > 0 )); then
    printf '\n'
    warn "ISO-Build wurde abgebrochen."
    warn "Zuerst müssen alle Prüfungsfehler behoben werden."
    return
fi

    printf '\n'
    info "Lösche altes Build-Arbeitsverzeichnis:"
    info "$work_directory"

    sudo rm -rf -- "$work_directory"

    mkdir -p \
        "$PROJECT_ROOT/build" \
        "$output_directory"

    printf '\n'
    info "Starte Archiso-Build."
    printf '\n'

    sudo mkarchiso \
        -v \
        -w "$work_directory" \
        -o "$output_directory" \
        "$profile_directory"

    newest_iso="$(
        find "$output_directory" \
            -maxdepth 1 \
            -type f \
            -name '*.iso' \
            -printf '%T@ %p\n' \
            | sort -nr \
            | head -n 1 \
            | cut -d' ' -f2-
    )"

    if [[ -z "$newest_iso" ]] ||
       [[ ! -f "$newest_iso" ]]; then
        fail "Nach dem Build wurde keine ISO gefunden."
    fi

    printf '\n'
    info "ISO-Build abgeschlossen:"
    info "$newest_iso"

    printf '\n'
    info "SHA256:"
    sha256sum "$newest_iso"
}


run_live_script() {
    local script="$1"
    shift

    local path="$SCRIPT_DIR/$script"

    [[ -x "$path" ]] ||
        fail "Skript fehlt oder ist nicht ausführbar: $path"

    "$path" "$@"
}

run_installed_script() {
    local script="$1"
    shift

    local path="$SCRIPT_DIR/$script"

    [[ -x "$path" ]] ||
        fail "Skript fehlt oder ist nicht ausführbar: $path"

    "$path" "$@"
}

run_updater() {
    local updater=""

    case "$ENVIRONMENT" in
        build)
            updater="$PROJECT_ROOT/archiso/releng/airootfs/usr/lib/custom-linux/custom-update.sh"
            ;;
        live|installed)
            updater="/usr/lib/custom-linux/custom-update.sh"
            ;;
        *)
            fail "Updater ist in dieser Umgebung nicht verfügbar."
            ;;
    esac

    [[ -x "$updater" ]] ||
        fail "Updater fehlt oder ist nicht ausführbar: $updater"

    "$updater" "$@"
}

run_custom_git() {
    local git_menu="$PROJECT_ROOT/archiso/releng/airootfs/root/custom-linux/custom-git.sh"

    [[ -x "$git_menu" ]] ||
        fail "Custom-Git wurde nicht gefunden oder ist nicht ausführbar: $git_menu"

    "$git_menu"
}

show_update_menu() {
    local choice=""
    local version=""

    while true; do
        clear

        printf 'Custom Linux - Script-Updates\n'
        printf '=============================\n\n'
        printf 'Umgebung: %s\n\n' "$ENVIRONMENT"

        printf '1) Auf Updates prüfen\n'
        printf '2) Neueste stabile Script-Version installieren\n'
        printf '3) Installierte Versionen anzeigen\n'
        printf '4) Andere installierte Version auswählen\n'
        printf '5) Rollback auf vorherige Version\n'
        printf '6) ISO-/System-Basisversion wiederherstellen\n'
        printf '\n'
        printf '0) Zurück\n\n'

        read -r -p 'Auswahl: ' choice

        case "$choice" in
            1)
                run_updater check stable
                pause_menu
                ;;
            2)
                if confirm_action \
                    "Neueste stabile Script-Version installieren?"; then
                    run_updater update stable
                else
                    info "Vorgang abgebrochen."
                fi
                pause_menu
                ;;
            3)
                run_updater versions
                pause_menu
                ;;
            4)
                printf '\n'
                read -r -p 'Version eingeben: ' version

                if [[ -z "$version" ]]; then
                    warn "Keine Version angegeben."
                elif confirm_action \
                    "Script-Version $version aktivieren?"; then
                    run_updater rollback "$version"
                else
                    info "Vorgang abgebrochen."
                fi

                pause_menu
                ;;
            5)
                if confirm_action \
                    "Auf die vorherige Script-Version zurückrollen?"; then
                    run_updater rollback
                else
                    info "Vorgang abgebrochen."
                fi
                pause_menu
                ;;
            6)
                if confirm_action \
                    "ISO-/System-Basisversion wiederherstellen?"; then
                    run_updater restore-bundled
                else
                    info "Vorgang abgebrochen."
                fi
                pause_menu
                ;;
            0)
                return
                ;;
            *)
                warn "Ungültige Auswahl: $choice"
                sleep 1
                ;;
        esac
    done
}

show_build_menu() {
    local choice=""

    while true; do
        clear

        printf 'Custom Linux - Entwicklungsmenü\n'
        printf '================================\n\n'
        printf 'Umgebung: Arch-Bau-System\n'
        printf 'Projekt:  %s\n\n' "$PROJECT_ROOT"

        printf '1) Alle Skripte prüfen\n'
	printf '2) Git-Menü öffnen\n'
	printf '3) Git-Status anzeigen\n'
	printf '4) Vorhandene ISO-Dateien anzeigen\n'
	printf '5) Neue ISO bauen\n'
	printf '\n'
	printf 'H) Hauptmenü\n'
	printf 'G) Git-Menü\n'
	printf '0) Beenden\n\n'

        read -r -p 'Auswahl: ' choice

        case "$choice" in
            1)
                check_project_scripts
                pause_menu
                ;;
            2)
                run_custom_git
                ;;
            3)
                show_git_status
                pause_menu
                ;;
            4)
                show_iso_files
                pause_menu
                ;;
            5)
                build_iso
                pause_menu
                ;;
            h|H)
                exec "$SCRIPT_PATH"
                ;;
            g|G)
                run_custom_git
                ;;
            0)
                exit 0
                ;;
            *)
                warn "Ungültige Auswahl: $choice"
                sleep 1
                ;;
        esac
    done
}


show_live_menu() {
    local choice=""

    while true; do
        clear

        printf 'Custom Linux - Live-System\n'
        printf '==========================\n\n'
        printf '1) Archinstall starten\n'
        printf '2) Archinstall-Konfiguration auf Ventoy speichern\n'
        printf '3) Installation nur vorprüfen\n'
        printf '4) Postinstall-Dateien ins Zielsystem kopieren\n'
        printf '5) Script-Updates\n'
        printf '\n'
        printf '0) Beenden\n\n'

        read -r -p 'Auswahl: ' choice

        case "$choice" in
            1)
                run_live_script "start-archinstall.sh"
                ;;
            2)
                run_live_script "save-archinstall-config.sh"
                pause_menu
                ;;
            3)
                run_live_script "01-preflight-copy.sh"
                pause_menu
                ;;
            4)
                if confirm_action "Dateien kopieren und Zielsystem konfigurieren?"; then
                    run_live_script "01-preflight-copy.sh" --copy
                else
                    info "Vorgang abgebrochen."
                fi
                pause_menu
                ;;
            5)
                show_update_menu
                ;;

            0)
                exit 0
                ;;
            *)
                warn "Ungültige Auswahl: $choice"
                sleep 1
                ;;
        esac
    done
}


show_installed_status() {
    printf '\n'

    if [[ -f /var/lib/custom-linux/postinstall-test.ok ]]; then
        printf '[OK] Postinstall-Test wurde erfolgreich abgeschlossen.\n'
    else
        printf '[OFFEN] Postinstall-Test wurde noch nicht erfolgreich abgeschlossen.\n'
    fi

    printf '\n'
}


show_installed_menu() {
    local choice=""

    while true; do
        clear

        printf 'Custom Linux - Installiertes System\n'
        printf '===================================\n\n'

        printf '1) Postinstall-Test starten\n'
        printf '2) Programme und iNiR installieren\n'
        printf '3) Installationsstatus anzeigen\n'
        printf '4) Script-Updates\n'
        printf '\n'
        printf 'H) Hauptmenü\n'
        printf 'G) Git-Menü\n'
        printf '0) Beenden\n\n'

        read -r -p 'Auswahl: ' choice

        case "$choice" in
            1)
                run_installed_script "02-postinstall-test.sh"
                pause_menu
                ;;
            2)
                if confirm_action "Postinstall-Setup jetzt starten?"; then
                    run_installed_script "03-postinstall-setup.sh"
                else
                    info "Vorgang abgebrochen."
                fi
                pause_menu
                ;;
            3)
                show_installed_status
                pause_menu
                ;;
            4)
                show_update_menu
                ;;
            h|H)
                exec "$SCRIPT_PATH"
                ;;
            g|G)
                if [[ -n "$PROJECT_ROOT" ]]; then
                    run_custom_git
                else
                    warn "Git-Menü ist nur verfügbar, wenn das Custom-Linux-Projekt gefunden wurde."
                    sleep 2
                fi
                ;;
            0)
                exit 0
                ;;
            *)
                warn "Ungültige Auswahl: $choice"
                sleep 1
                ;;
        esac
    done
}

show_main_menu() {
    local choice=""

    while true; do
        clear

        printf 'Custom Linux - Hauptmenü\n'
        printf '========================\n\n'

        printf '1) Entwicklungs-/Build-Menü\n'
        printf '2) Installiertes-System-Menü\n'
        printf '3) Git-Menü öffnen\n'
        printf '\n'
        printf '0) Beenden\n\n'

        read -r -p 'Auswahl: ' choice

        case "$choice" in
            1)
                show_build_menu
                ;;
            2)
                show_installed_menu
                ;;
            3|g|G)
                run_custom_git
                ;;
            0)
                exit 0
                ;;
            *)
                warn "Ungültige Auswahl: $choice"
                sleep 1
                ;;
        esac
    done
}

run_self_test() {
    local required_file=""
    local -a required_executables=(
        "01-preflight-copy.sh"
        "02-postinstall-test.sh"
        "03-postinstall-setup.sh"
        "custom-git.sh"
        "custom-linux-menu.sh"
        "save-archinstall-config.sh"
        "start-archinstall.sh"
    )

    [[ "$SCRIPT_DIR" == /* && -d "$SCRIPT_DIR" ]] ||
        fail "Ungültiges Script-Verzeichnis: $SCRIPT_DIR"

    for required_file in "${required_executables[@]}"; do
        [[ -x "$SCRIPT_DIR/$required_file" ]] ||
            fail "Self-Test: Datei fehlt oder ist nicht ausführbar: $required_file"
    done

    [[ -f "$SCRIPT_DIR/custom-dialogrc" ]] ||
        fail "Self-Test: custom-dialogrc fehlt."

    case "$ENVIRONMENT" in
        build|live|installed)
            info "Self-Test-Umgebung: $ENVIRONMENT"
            ;;
        unknown)
            warn "Self-Test läuft außerhalb einer erkannten Custom-Linux-Umgebung."
            ;;
        *)
            fail "Self-Test: Ungültige Umgebung: $ENVIRONMENT"
            ;;
    esac

    printf '[OK] Custom-Linux-Menü-Self-Test erfolgreich.\n'
}



main() {
    local command="${1:-}"

    detect_environment

    case "$command" in
        "")
            case "$ENVIRONMENT" in
                build)
                    show_main_menu
                    ;;
                live)
                    show_live_menu
                    ;;
                installed)
                    show_installed_menu
                    ;;
                *)
                    fail "Custom-Linux-Umgebung konnte nicht erkannt werden."
                    ;;
            esac
            ;;
        self-test|--self-test)
            run_self_test
            ;;
        update)
            case "$ENVIRONMENT" in
                live|installed)
                    show_update_menu
                    ;;
                build)
                    fail "Release-Updates sind im Build-System nicht verfügbar."
                    ;;
                *)
                    fail "Updater ist in dieser Umgebung nicht verfügbar."
                    ;;
            esac
            ;;

        git)
            if [[ -z "$PROJECT_ROOT" ]]; then
                fail "Git-Menü benötigt das Custom-Linux-Projekt mit Git-Repository."
            fi

            run_custom_git
            ;;

        build)
            if [[ -z "$PROJECT_ROOT" ]]; then
                fail "Build-Menü benötigt das Custom-Linux-Projekt mit Git-Repository."
            fi

            show_build_menu
            ;;

        installed)
            show_installed_menu
            ;;

        *)
            fail "Unbekannter Aufruf: $command. Möglich: git, build, update, installed, self-test"
            ;;
    esac
}

main "$@"
