#!/usr/bin/env bash

# start-archinstall.sh
#
# Aufgabe:
# - Wird im Custom-Linux-Live-System ausgeführt.
# - Sucht die Ventoy-Datenpartition anhand des Labels "Ventoy SSK".
# - Mountet sie unter /mnt/ventoy.
# - Sucht dort nach der gespeicherten Archinstall-Konfiguration.
# - Startet Archinstall mit der gefundenen Konfiguration.
#
# Die Archinstall-Konfiguration bleibt außerhalb der ISO:
#
# Ventoy SSK/
# └── custom-linux/
#     └── archinstall/
#         └── user_configuration.json
#
# Sicherheit:
# - Das Skript formatiert selbst keine Datenträger.
# - Es speichert keine Passwörter.
# - user_credentials.json wird absichtlich nicht automatisch verwendet.
# - Fehlt die Konfiguration, wird Archinstall normal gestartet.
#
# Benötigte Rechte:
# - Root im Arch-Live-System.
#
# Betroffene Bereiche:
# - /mnt/ventoy
# - Ventoy-Datenpartition wird nur eingehängt.
#
# Die eigentliche Installation wird weiterhin von Archinstall durchgeführt.

set -Eeuo pipefail
IFS=$'\n\t'

VENTOY_LABEL="Ventoy SSK"
MOUNT_POINT="/mnt/ventoy"
CONFIG_RELATIVE="custom-linux/archinstall/user_configuration.json"

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

trap '
rc=$?
printf "\n[FEHLER] Zeile %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2
printf "[FEHLER] Abbruch mit Exit-Code %s.\n" "$rc" >&2
exit "$rc"
' ERR

(( EUID == 0 )) ||
    fail "Dieses Skript muss im Arch-Live-System als Root ausgeführt werden."

for required_command in \
    archinstall \
    blkid \
    mkdir \
    mount \
    mountpoint
do
    command -v "$required_command" >/dev/null 2>&1 ||
        fail "Benötigter Befehl fehlt: $required_command"
done

info "Suche Ventoy-Datenpartition mit Label: $VENTOY_LABEL"

VENTOY_DEVICE="$(
    blkid \
        -L "$VENTOY_LABEL" \
        2>/dev/null ||
    true
)"

[[ -n "$VENTOY_DEVICE" ]] ||
    fail "Die Ventoy-Datenpartition '$VENTOY_LABEL' wurde nicht gefunden."

[[ -b "$VENTOY_DEVICE" ]] ||
    fail "Gefundenes Ventoy-Gerät ist kein Blockgerät: $VENTOY_DEVICE"

info "Ventoy-Partition gefunden: $VENTOY_DEVICE"

VENTOY_DEVICE_NAME="${VENTOY_DEVICE##*/}"
VENTOY_MAPPER_DEVICE="/dev/mapper/$VENTOY_DEVICE_NAME"
VENTOY_MOUNT_DEVICE="$VENTOY_DEVICE"

if [[ ! -b "$VENTOY_MAPPER_DEVICE" ]]; then
    if command -v udevadm >/dev/null 2>&1; then
        info "Ventoy-Mapper wurde noch nicht gefunden. Aktualisiere udev."

        udevadm trigger
        udevadm settle
    fi
fi

if [[ -b "$VENTOY_MAPPER_DEVICE" ]]; then
    VENTOY_MOUNT_DEVICE="$VENTOY_MAPPER_DEVICE"

    info "Ventoy-Mapper erkannt:"
    info "$VENTOY_MOUNT_DEVICE"
else
    warn "Kein Ventoy-Mapper gefunden."
    warn "Versuche direktes Gerät: $VENTOY_DEVICE"
fi

mkdir -p "$MOUNT_POINT"

if mountpoint -q "$MOUNT_POINT"; then
    info "Ventoy-Mountpunkt ist bereits eingehängt."
    info "Stelle sicher, dass Ventoy schreibbar eingehängt ist."

    mount \
        --options remount,rw \
        "$MOUNT_POINT"
else
    info "Hänge Ventoy schreibbar unter $MOUNT_POINT ein."

    mount \
        --options rw \
        "$VENTOY_MOUNT_DEVICE" \
        "$MOUNT_POINT"
fi

CONFIG_FILE="$MOUNT_POINT/$CONFIG_RELATIVE"

if [[ -f "$CONFIG_FILE" ]]; then
    info "Archinstall-Konfiguration gefunden:"
    info "$CONFIG_FILE"

    printf '\n'
    printf 'Archinstall wird mit der gespeicherten Konfiguration gestartet.\n'
    printf 'Die Einstellungen vor Beginn der Installation bitte kontrollieren.\n'
    printf '\n'

    exec archinstall \
        --config "$CONFIG_FILE"
else
    warn "Keine gespeicherte Archinstall-Konfiguration gefunden:"
    warn "$CONFIG_FILE"

    printf '\n'
    printf 'Archinstall wird ohne gespeicherte Konfiguration gestartet.\n'
    printf 'Nach dem Einstellen können wir die Konfiguration auf Ventoy speichern.\n'
    printf '\n'

    exec archinstall
fi
