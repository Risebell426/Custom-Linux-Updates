#!/usr/bin/env bash

# 04-optional-software-setup.sh
#
# Aufgabe:
# - Wird im installierten Custom-Linux-System als normaler Benutzer gestartet.
# - Zeigt optionale Programme mit ihrem aktuellen Installationsstatus an.
# - Die Auswahl erfolgt im Dialog-Menü mit Leertaste und wird vor der
#   Installation nochmals als Kontrollliste angezeigt.
# - Prüft jedes ausgewählte Programm unmittelbar vor und nach der Installation.
# - Aktualisiert nach erfolgreichen Installationen einmalig die Werkzeugübersicht.
# - Ein Fehler der Werkzeugübersicht verändert erfolgreiche Installationen nicht.
# - Zeigt mit --versions die lokal erkannten Programmversionen und Quellen an.
# - Die Versionsanzeige synchronisiert keine Paketdatenbanken und verändert nichts.
# - Erstellt mit --update-preview eine sichere Vorschau für Pacman- und AUR-Updates.
# - Festgelegte Downloads und geprüfte AUR-Stände werden nicht ungeprüft aktualisiert.
# - Bietet nach der Programmbearbeitung optional ein vollständiges Systemupdate an.
# - Unterstützt für Programmupdates die Auswahl aller oder bestimmter Programme.
# - Zeigt vor jeder Bestätigung alle betroffenen Programme und Updatewege an.
# - Bearbeitet AUR-Programmupdates einzeln und läuft nach einzelnen Fehlern weiter.
# - Führt niemals selbstständig einen Neustart oder Dienstneustart aus.
# - Speichert Versuchszähler und eigene Fehlerprotokolle unter
#   ~/.local/state/custom-linux/optional-software/.
#
# Rechte und Sicherheit:
# - Das Skript selbst darf nicht mit sudo gestartet werden.
# - Nur pacman, systemctl und usermod erhalten bei Bedarf über sudo Root-Rechte.
# - Eine leere, abgebrochene oder nicht bestätigte Auswahl verändert nichts.
# - Ein fehlgeschlagenes optionales Programm kann nach zehn Sekunden automatisch
#   übersprungen und bei einem späteren Aufruf erneut ausgewählt werden.
#
# Dieser erste Ausbau enthält die Programme, die bisher gemeinsam über die
# Pacman-Basisliste installiert werden. Weitere Kategorien und Installationsarten
# werden nach getrennten Paket- und Funktionstests ergänzt.

set -Eeuo pipefail
IFS=$'\n\t'

STATE_DIR="$HOME/.local/state/custom-linux/optional-software"
LOG_DIR="$STATE_DIR/logs"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DIALOGRC_FILE="$SCRIPT_DIR/custom-dialogrc"
TOOL_OVERVIEW_SCRIPT="$SCRIPT_DIR/06-tool-overview-setup.sh"

dialog_no_cursor() (
    trap 'tput cnorm 2>/dev/null || true' EXIT INT TERM HUP
    tput civis 2>/dev/null || true
    DIALOGRC="$DIALOGRC_FILE" command dialog "$@"
)


POWERSHELL_VERSION="7.6.5"
POWERSHELL_ARCHIVE="powershell-${POWERSHELL_VERSION}-linux-x64.tar.gz"
POWERSHELL_URL="https://github.com/PowerShell/PowerShell/releases/download/v${POWERSHELL_VERSION}/${POWERSHELL_ARCHIVE}"
POWERSHELL_SHA256="b34ab3b19acac1d3d4d0d3cfdb02acf62f457b0b6a962ff008132033f7566844"
POWERSHELL_INSTALL_DIRECTORY="/opt/microsoft/powershell/$POWERSHELL_VERSION"
POWERSHELL_LINK="/usr/local/bin/pwsh"
POWERSHELL_VERSION_QUERY="\$PSVersionTable.PSVersion.ToString()"

XAMPP_VERSION="8.2.12-0"
XAMPP_URL="https://sourceforge.net/projects/xampp/files/XAMPP%20Linux/8.2.12/xampp-linux-x64-8.2.12-0-installer.run/download"
XAMPP_SHA256="df0774e7a6d0d0754a5f0132015411234b5f953df2365b693d3758fc35a30374"

VSCODE_AUR_REPOSITORY="https://aur.archlinux.org/visual-studio-code-bin.git"
VSCODE_AUR_COMMIT="69b361eca02a84aa97c43c885e23d463eec96770"
VSCODE_PKGBUILD_SHA256="5126484b61d9a5aea86ab4f028d0ab973f2250c9cb5db5c820ae603a012d6898"
VSCODE_SRCINFO_SHA256="ea5b46738af95b1281f7e76a4ab215beb6a2ee7d07c62d2f3cd5d2fe6baf75cb"

ARDUINO_IDE_AUR_REPOSITORY="https://aur.archlinux.org/arduino-ide-bin.git"
ARDUINO_IDE_AUR_COMMIT="78ca53e1cd1b9fd1ce73b3d8b246a6900fd5ac50"
ARDUINO_IDE_PKGBUILD_SHA256="0ba571f25f0ace1f7f29552af9b85f46415b60cd0dc770a82b2c61965d5540b1"
ARDUINO_IDE_SRCINFO_SHA256="5161a6fec4309781484ac6c85279a253e0a4363b12eba7a8048a91ffbe3707f5"

BURPSUITE_AUR_REPOSITORY="https://aur.archlinux.org/burpsuite.git"
BURPSUITE_AUR_COMMIT="0a6ffd4fbc7f36726e6928d528c0de87fe6a1311"
BURPSUITE_PKGBUILD_SHA256="4352c45c4c1468cde321f4aec5d1a4045c5987256ac2e6a786f20f02e122b436"
BURPSUITE_SRCINFO_SHA256="00646740d24652411aecbdd205e096738ee7e356fbfb13b1a642510c9a025fc8"

FFUF_AUR_REPOSITORY="https://aur.archlinux.org/ffuf.git"
FFUF_AUR_COMMIT="4665d9a8344c268ba8d44bf837ba994c42b345a9"
FFUF_PKGBUILD_SHA256="dc135dd9fed7fb8a4b249c0b94998274402f1e5a6ee5c9f7c63ca451c8395e5c"
FFUF_SRCINFO_SHA256="78b82c02eb1d9aa33772dda5d495d6c635ca19c77f3515e320bab0e05b2e7037"

ARDUINO_UDEV_RULES_FILE="/etc/udev/rules.d/60-custom-linux-arduino.rules"
ARDUINO_UDEV_RULES_SHA256="4b5f40892e81f8c2107c7a449e97f7eea0420d5a87ac6614492dfa152d48373f"

declare -a PROGRAM_IDS=(
    obsidian
    element
    discord
    prismlauncher
    mysql-workbench
    docker
    brave
    powershell
    vscode
    arduino
    xampp
    wireshark
    tcpdump
    keepassxc
    clamav
    lynis
    nmap
    burpsuite
    zaproxy
    sqlmap
    gobuster
    ffuf
    hydra
    john
    hashcat
    aircrack-ng
    metasploit
)

declare -A PROGRAM_LABELS=(
    [obsidian]="Obsidian"
    [element]="Element"
    [discord]="Discord"
    [prismlauncher]="PrismLauncher"
    [mysql-workbench]="MySQL Workbench"
    [docker]="Docker mit Docker Compose"
    [brave]="Brave Browser"
    [powershell]="PowerShell 7.6.5"
    [vscode]="Visual Studio Code"
    [arduino]="Arduino IDE mit udev-Regeln"
    [xampp]="XAMPP"
    [wireshark]="Wireshark"
    [tcpdump]="tcpdump"
    [keepassxc]="KeePassXC"
    [clamav]="ClamAV"
    [lynis]="Lynis"
    [nmap]="Nmap"
    [burpsuite]="Burp Suite Community Edition"
    [zaproxy]="OWASP ZAP"
    [sqlmap]="SQLMap"
    [gobuster]="Gobuster"
    [ffuf]="ffuf"
    [hydra]="Hydra"
    [john]="John the Ripper"
    [hashcat]="Hashcat"
    [aircrack-ng]="Aircrack-ng"
    [metasploit]="Metasploit Framework"
)

# Für die späteren gruppierten Programmuntermenüs vorbereitete Metadaten.
# shellcheck disable=SC2034
declare -A PROGRAM_CATEGORIES=(
    [obsidian]="Schule und Organisation"
    [element]="Private Programme"
    [discord]="Private Programme"
    [prismlauncher]="Private Programme"
    [mysql-workbench]="Schule und Entwicklung"
    [docker]="Schule und Entwicklung"
    [brave]="Browser"
    [powershell]="Schule und Administration"
    [vscode]="Schule und Entwicklung"
    [arduino]="Schule und Entwicklung"
    [xampp]="Schule und Entwicklung"
    [wireshark]="Schule – Sicherheit"
    [tcpdump]="Schule – Sicherheit"
    [keepassxc]="Schule – Sicherheit"
    [clamav]="Schule – Sicherheit"
    [lynis]="Schule – Sicherheit"
    [nmap]="Schule – Hacking-Tests"
    [burpsuite]="Schule – Hacking-Tests"
    [zaproxy]="Schule – Hacking-Tests"
    [sqlmap]="Schule – Hacking-Tests"
    [gobuster]="Schule – Hacking-Tests"
    [ffuf]="Schule – Hacking-Tests"
    [hydra]="Schule – Hacking-Tests"
    [john]="Schule – Hacking-Tests"
    [hashcat]="Schule – Hacking-Tests"
    [aircrack-ng]="Schule – Hacking-Tests"
    [metasploit]="Schule – Hacking-Tests"
)

declare -A PROGRAM_DESCRIPTIONS=(
    [obsidian]="Notizen und Wissensverwaltung"
    [element]="Matrix-Messenger"
    [discord]="Sprach- und Textchat"
    [prismlauncher]="Minecraft-Launcher"
    [mysql-workbench]="Grafische MySQL-Verwaltung"
    [docker]="Container-Laufzeit und Compose-Werkzeug"
    [brave]="Zusätzlicher Webbrowser"
    [powershell]="PowerShell für Administration und Schule"
    [vscode]="Code-Editor und Entwicklungsumgebung"
    [arduino]="Arduino IDE einschließlich Gerätezugriffsregeln"
    [xampp]="Lokale Apache-, MariaDB- und PHP-Umgebung"
    [wireshark]="Grafische Analyse von Netzwerkverkehr"
    [tcpdump]="Netzwerkmitschnitte im Terminal"
    [keepassxc]="Lokale Verwaltung von Passwörtern"
    [clamav]="Virenscanner für Dateien und Verzeichnisse"
    [lynis]="Lokale Sicherheits- und Härtungsprüfung"
    [nmap]="Netzwerkprüfung in erlaubten Testumgebungen"
    [burpsuite]="Webanwendungsprüfung in erlaubten Testumgebungen"
    [zaproxy]="Webanwendungsanalyse in erlaubten Testumgebungen"
    [sqlmap]="SQL-Prüfung auf ausdrücklich erlaubten Testsystemen"
    [gobuster]="Inhaltssuche auf erlaubten Testsystemen"
    [ffuf]="Web-Fuzzing auf erlaubten Testsystemen"
    [hydra]="Anmeldeprüfung auf ausdrücklich erlaubten Testsystemen"
    [john]="Passwortprüfung mit eigenen oder freigegebenen Hashes"
    [hashcat]="Passwortprüfung mit eigenen oder freigegebenen Hashes"
    [aircrack-ng]="WLAN-Prüfung ausschließlich in eigenen Testnetzen"
    [metasploit]="Sicherheitsprüfung in isolierten erlaubten Laboren"
)

declare -a PROGRAM_GROUP_IDS=(
    private
    school
    school-security
    all
)

declare -A PROGRAM_GROUP_LABELS=(
    [private]="Privat"
    [school]="Schule und Entwicklung"
    [school-security]="Security"
    [all]="Alle Programme"
)

declare -A PROGRAM_GROUP_DESCRIPTIONS=(
    [private]="Browser, Kommunikation und private Programme"
    [school]="Lernen, Entwicklung und Administration"
    [school-security]="Sicherheits- und Testwerkzeuge"
    [all]="Sämtliche optionalen Programme gemeinsam anzeigen"
)

declare -A PROGRAM_GROUPS=(
    [element]="private"
    [discord]="private"
    [prismlauncher]="private"
    [brave]="private"
    [obsidian]="school"
    [mysql-workbench]="school"
    [docker]="school"
    [powershell]="school"
    [vscode]="school"
    [arduino]="school"
    [xampp]="school"
    [wireshark]="school-security"
    [tcpdump]="school-security"
    [keepassxc]="school-security"
    [clamav]="school-security"
    [lynis]="school-security"
    [nmap]="school-security"
    [burpsuite]="school-security"
    [zaproxy]="school-security"
    [sqlmap]="school-security"
    [gobuster]="school-security"
    [ffuf]="school-security"
    [hydra]="school-security"
    [john]="school-security"
    [hashcat]="school-security"
    [aircrack-ng]="school-security"
    [metasploit]="school-security"
)

SELECTED_PROGRAM_GROUP=""
declare -a VISIBLE_PROGRAM_IDS=()

declare -a SELECTED_PROGRAMS=()
declare -a INSTALLED_PROGRAMS=()
declare -a ALREADY_INSTALLED_PROGRAMS=()
declare -a FAILED_PROGRAMS=()
declare -a UNAVAILABLE_PROGRAM_IDS=()
declare -a UNAVAILABLE_PROGRAMS=()
declare -a NOT_SELECTED_PROGRAMS=()

TOOL_OVERVIEW_STATUS="nicht erforderlich"
TOOL_OVERVIEW_LOG=""
TOOL_OVERVIEW_REQUIRED=0

OFFICIAL_UPDATE_STATUS="nicht geprüft"
AUR_UPDATE_STATUS="nicht geprüft"
UPDATE_AUR_HELPER=""

declare -a OFFICIAL_UPDATE_LINES=()
declare -a MANAGED_SYSTEM_UPDATE_LINES=()
declare -a OTHER_SYSTEM_UPDATE_LINES=()
declare -a AUR_UPDATE_LINES=()
declare -a MANAGED_AUR_UPDATE_LINES=()
declare -a PINNED_AUR_UPDATE_LINES=()
declare -a OTHER_AUR_UPDATE_LINES=()
declare -a PINNED_UPDATE_PROGRAMS=()
declare -a UPDATE_PREVIEW_WARNINGS=()

declare -a AVAILABLE_UPDATE_PROGRAM_IDS=()
declare -a SELECTED_UPDATE_PROGRAM_IDS=()
declare -a UPDATED_PROGRAMS=()
declare -a ALREADY_CURRENT_UPDATE_PROGRAMS=()
declare -a FAILED_UPDATE_PROGRAMS=()
declare -a DEFERRED_UPDATE_PROGRAMS=()
declare -a PROGRAM_UPDATE_LOGS=()

SYSTEM_UPDATE_STATUS="nicht angeboten"
SYSTEM_UPDATE_LOG=""
SYSTEM_UPDATE_DURATION=0
SYSTEM_RESTART_RECOMMENDED=0

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

find_aur_helper() {
    local helper=""

    for helper in paru pikaur yay; do
        if command -v "$helper" >/dev/null 2>&1; then
            printf '%s\n' "$helper"
            return 0
        fi
    done

    return 1
}

install_brave() {
    local aur_helper=""

    aur_helper="$(find_aur_helper)" ||
        fail "Brave benötigt unter Arch einen AUR-Helfer."

    info "Installiere brave-bin mit dem vorhandenen AUR-Helfer: $aur_helper"

    "$aur_helper" \
        --sync \
        --needed \
        --noconfirm \
        brave-bin

    check_brave_complete ||
        fail "brave-bin wurde installiert, aber Brave wurde nicht gefunden."

    info "Brave-Installationsschritt abgeschlossen."
}

install_powershell() {
    local archive_file=""
    local extraction_directory=""
    local actual_hash=""
    local installed_version=""

    [[ "$(uname -m)" == "x86_64" ]] ||
        fail "Das vorbereitete PowerShell-Archiv unterstützt nur x86_64."

    if check_powershell_complete; then
        info "PowerShell $POWERSHELL_VERSION ist bereits vollständig vorhanden."
        return 0
    fi

    if [[ -x "$POWERSHELL_INSTALL_DIRECTORY/pwsh" ]]; then
        installed_version="$(
            "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
                -NoLogo \
                -NoProfile \
                -Command "$POWERSHELL_VERSION_QUERY" 2>/dev/null ||
                true
        )"

        if [[ "$installed_version" == "$POWERSHELL_VERSION" ]]; then
            if [[ -e "$POWERSHELL_LINK" && ! -L "$POWERSHELL_LINK" ]]; then
                fail "Der PowerShell-Linkpfad ist durch eine normale Datei belegt:
$POWERSHELL_LINK"
            fi

            sudo ln -sfn \
                "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
                "$POWERSHELL_LINK"

            info "Vorhandene PowerShell-Installation wurde wieder verknüpft."
            return 0
        fi
    fi

    archive_file="$(
        mktemp "$STATE_DIR/powershell-${POWERSHELL_VERSION}.XXXXXX.tar.gz"
    )"

    extraction_directory="$(
        mktemp -d "$STATE_DIR/powershell-extract.XXXXXX"
    )"

    (
        trap 'rm -f -- "$archive_file"; rm -rf -- "$extraction_directory"' EXIT

        info "Lade das offizielle PowerShell-$POWERSHELL_VERSION-Archiv."

        curl \
            --fail \
            --location \
            --show-error \
            --output "$archive_file" \
            "$POWERSHELL_URL"

        actual_hash="$(
            sha256sum "$archive_file" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$POWERSHELL_SHA256" ]] ||
            fail "Die PowerShell-Prüfsumme stimmt nicht.

Erwartet: $POWERSHELL_SHA256
Gefunden: $actual_hash"

        info "PowerShell-Archiv wurde erfolgreich per SHA-256 geprüft."

        tar \
            --extract \
            --gzip \
            --file "$archive_file" \
            --directory "$extraction_directory"

        [[ -f "$extraction_directory/pwsh" ]] ||
            fail "Das PowerShell-Archiv enthält keine pwsh-Datei."

        if [[ -e "$POWERSHELL_INSTALL_DIRECTORY" &&
              ! -d "$POWERSHELL_INSTALL_DIRECTORY" ]]; then
            fail "Der PowerShell-Zielpfad ist kein Verzeichnis:
$POWERSHELL_INSTALL_DIRECTORY"
        fi

        info "Ersetze ausschließlich das Ziel dieser PowerShell-Version:"
        info "$POWERSHELL_INSTALL_DIRECTORY"

        sudo rm -rf -- "$POWERSHELL_INSTALL_DIRECTORY"

        sudo install \
            -d \
            -m 0755 \
            "$POWERSHELL_INSTALL_DIRECTORY"

        sudo cp -a \
            "$extraction_directory/." \
            "$POWERSHELL_INSTALL_DIRECTORY/"

        sudo chmod 0755 "$POWERSHELL_INSTALL_DIRECTORY/pwsh"

        if [[ -e "$POWERSHELL_LINK" && ! -L "$POWERSHELL_LINK" ]]; then
            fail "Der PowerShell-Linkpfad ist durch eine normale Datei belegt:
$POWERSHELL_LINK"
        fi

        sudo ln -sfn \
            "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
            "$POWERSHELL_LINK"
    )

    check_powershell_complete ||
        fail "PowerShell wurde installiert, aber Version $POWERSHELL_VERSION konnte nicht bestätigt werden."

    installed_version="$(
        pwsh \
            -NoLogo \
            -NoProfile \
            -Command "$POWERSHELL_VERSION_QUERY"
    )"

    info "PowerShell wurde erfolgreich installiert: $installed_version"
}

install_pinned_aur_package() {
    local label="$1"
    local package_name="$2"
    local repository_url="$3"
    local expected_commit="$4"
    local expected_pkgbuild_hash="$5"
    local expected_srcinfo_hash="$6"
    local source_directory=""
    local actual_commit=""
    local actual_pkgbuild_hash=""
    local actual_srcinfo_hash=""

    if pacman -Q "$package_name" >/dev/null 2>&1; then
        info "$label ist bereits als Paket installiert: $package_name"
        return 0
    fi

    source_directory="$(
        mktemp -d "$STATE_DIR/${package_name}-build.XXXXXX"
    )"

    (
        trap 'rm -rf -- "$source_directory"' EXIT

        info "Lade die festgelegte AUR-Paketdefinition: $package_name"

        git clone \
            "$repository_url" \
            "$source_directory"

        git -C "$source_directory" \
            checkout \
            --detach \
            "$expected_commit"

        actual_commit="$(
            git -C "$source_directory" rev-parse HEAD
        )"

        [[ "$actual_commit" == "$expected_commit" ]] ||
            fail "Der AUR-Commit für $package_name stimmt nicht.

Erwartet: $expected_commit
Gefunden: $actual_commit"

        actual_pkgbuild_hash="$(
            sha256sum "$source_directory/PKGBUILD" |
                awk '{print $1}'
        )"

        [[ "$actual_pkgbuild_hash" == "$expected_pkgbuild_hash" ]] ||
            fail "Die PKGBUILD-Prüfsumme für $package_name stimmt nicht.

Erwartet: $expected_pkgbuild_hash
Gefunden: $actual_pkgbuild_hash"

        actual_srcinfo_hash="$(
            sha256sum "$source_directory/.SRCINFO" |
                awk '{print $1}'
        )"

        [[ "$actual_srcinfo_hash" == "$expected_srcinfo_hash" ]] ||
            fail "Die .SRCINFO-Prüfsumme für $package_name stimmt nicht.

Erwartet: $expected_srcinfo_hash
Gefunden: $actual_srcinfo_hash"

        info "AUR-Commit und Paketdefinition wurden geprüft."

        cd "$source_directory"

        makepkg \
            --syncdeps \
            --install \
            --needed \
            --noconfirm
    )

    pacman -Q "$package_name" >/dev/null 2>&1 ||
        fail "$label wurde nicht als Paket installiert: $package_name"

    info "$label wurde erfolgreich installiert."
}

install_vscode() {
    install_pinned_aur_package \
        "Microsoft Visual Studio Code" \
        visual-studio-code-bin \
        "$VSCODE_AUR_REPOSITORY" \
        "$VSCODE_AUR_COMMIT" \
        "$VSCODE_PKGBUILD_SHA256" \
        "$VSCODE_SRCINFO_SHA256"

    check_vscode_complete ||
        fail "Microsoft Visual Studio Code wurde installiert, aber 'code' fehlt."
}

install_arduino_ide() {
    install_pinned_aur_package \
        "Arduino IDE" \
        arduino-ide-bin \
        "$ARDUINO_IDE_AUR_REPOSITORY" \
        "$ARDUINO_IDE_AUR_COMMIT" \
        "$ARDUINO_IDE_PKGBUILD_SHA256" \
        "$ARDUINO_IDE_SRCINFO_SHA256"

    check_arduino_ide_complete ||
        fail "Arduino IDE wurde installiert, aber 'arduino-ide' fehlt."
}

install_burpsuite() {
    install_pinned_aur_package \
        "Burp Suite Community Edition" \
        burpsuite \
        "$BURPSUITE_AUR_REPOSITORY" \
        "$BURPSUITE_AUR_COMMIT" \
        "$BURPSUITE_PKGBUILD_SHA256" \
        "$BURPSUITE_SRCINFO_SHA256"

    command -v burpsuite >/dev/null 2>&1 ||
        fail "Burp Suite wurde installiert, aber 'burpsuite' fehlt."
}

install_ffuf() {
    install_pinned_aur_package \
        "ffuf" \
        ffuf \
        "$FFUF_AUR_REPOSITORY" \
        "$FFUF_AUR_COMMIT" \
        "$FFUF_PKGBUILD_SHA256" \
        "$FFUF_SRCINFO_SHA256"

    command -v ffuf >/dev/null 2>&1 ||
        fail "ffuf wurde installiert, aber der Befehl fehlt."
}


configure_arduino_udev() {
    local temporary_rules=""
    local actual_hash=""

    command -v udevadm >/dev/null 2>&1 ||
        fail "udevadm wurde nicht gefunden."

    temporary_rules="$(
        mktemp "$STATE_DIR/arduino-udev-rules.XXXXXX"
    )"

    (
        trap 'rm -f -- "$temporary_rules"' EXIT

        cat > "$temporary_rules" <<'ARDUINO_UDEV_RULES'
# Custom Linux - Arduino udev rules
# Based on the official Arduino unified rules retrieved on 2026-09-02.

SUBSYSTEMS=="usb", ATTRS{idVendor}=="2341", MODE="0660", TAG+="uaccess"
SUBSYSTEMS=="tty", ENV{ID_REVISION}=="03eb", ENV{ID_MODEL_ID}=="2145", MODE="0660", TAG+="uaccess", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_CANDIDATE}="0"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="03eb", ATTRS{idProduct}=="2145", MODE="0660", TAG+="uaccess", ENV{ID_MM_DEVICE_IGNORE}="1"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="05c6", ATTRS{idProduct}=="9008", MODE="0660", TAG+="uaccess"
ACTION!="add|change", GOTO="custom_linux_openocd_rules_end"
SUBSYSTEM!="usb|tty|hidraw", GOTO="custom_linux_openocd_rules_end"
ATTRS{product}=="*CMSIS-DAP*", MODE="0660", TAG+="uaccess"
LABEL="custom_linux_openocd_rules_end"
ARDUINO_UDEV_RULES

        actual_hash="$(
            sha256sum "$temporary_rules" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$ARDUINO_UDEV_RULES_SHA256" ]] ||
            fail "Die erzeugten Arduino-udev-Regeln stimmen nicht.

Erwartet: $ARDUINO_UDEV_RULES_SHA256
Gefunden: $actual_hash"

        info "Die eingebetteten Arduino-udev-Regeln wurden per SHA-256 geprüft."
        info "Installiere ausschließlich die verwaltete Custom-Linux-Regeldatei:"
        info "$ARDUINO_UDEV_RULES_FILE"

        sudo install \
            --directory \
            --mode 0755 \
            /etc/udev/rules.d

        sudo install \
            --mode 0644 \
            --owner root \
            --group root \
            -- \
            "$temporary_rules" \
            "$ARDUINO_UDEV_RULES_FILE"

        sudo udevadm control --reload-rules
    )

    check_arduino_udev_complete ||
        fail "Die verwalteten Arduino-udev-Regeln konnten nicht bestätigt werden."

    info "Arduino-udev-Regeln wurden eingerichtet."
    info "Ein angeschlossenes Arduino-Board bitte einmal aus- und wieder einstecken."
}

install_xampp() {
    local installer=""
    local actual_hash=""

    if check_xampp_complete; then
        info "Eine vorhandene XAMPP-Installation wurde erkannt."
        info "XAMPP wird nicht erneut installiert."
        return 0
    fi

    installer="$(
        mktemp "$STATE_DIR/xampp-${XAMPP_VERSION}.XXXXXX.run"
    )"

    (
        trap 'rm -f -- "$installer"' EXIT

        info "Lade XAMPP $XAMPP_VERSION vom festgelegten offiziellen Download."

        curl \
            --fail \
            --location \
            --show-error \
            --output "$installer" \
            "$XAMPP_URL"

        actual_hash="$(
            sha256sum "$installer" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$XAMPP_SHA256" ]] ||
            fail "Die SHA-256-Prüfsumme des XAMPP-Installers stimmt nicht.

Erwartet: $XAMPP_SHA256
Gefunden: $actual_hash"

        info "Der XAMPP-Installer wurde erfolgreich per SHA-256 geprüft."

        chmod 0755 "$installer"

        info "Installiere XAMPP ohne zusätzliche Installationsdialoge."

        sudo "$installer" \
            --mode unattended \
            --unattendedmodeui none \
            --installer-language de
    )

    check_xampp_complete ||
        fail "XAMPP wurde ausgeführt, aber /opt/lampp/lampp wurde nicht gefunden."

    info "XAMPP $XAMPP_VERSION wurde erfolgreich installiert."
}

check_brave_complete() {
    command -v brave-browser >/dev/null 2>&1 ||
        command -v brave >/dev/null 2>&1
}

check_powershell_complete() {
    local command_path=""
    local installed_version=""

    command_path="$(command -v pwsh 2>/dev/null)" ||
        return 1

    installed_version="$(
        "$command_path" \
            -NoLogo \
            -NoProfile \
            -Command "$POWERSHELL_VERSION_QUERY" 2>/dev/null
    )" || return 1

    [[ "$installed_version" == "$POWERSHELL_VERSION" ]]
}

check_vscode_complete() {
    pacman -Q visual-studio-code-bin >/dev/null 2>&1 &&
        command -v code >/dev/null 2>&1
}

check_arduino_ide_complete() {
    pacman -Q arduino-ide-bin >/dev/null 2>&1 &&
        command -v arduino-ide >/dev/null 2>&1
}

check_arduino_udev_complete() {
    local actual_hash=""
    local ownership_and_mode=""

    [[ -f "$ARDUINO_UDEV_RULES_FILE" ]] ||
        return 1

    actual_hash="$(
        sha256sum "$ARDUINO_UDEV_RULES_FILE" 2>/dev/null |
            awk '{print $1}'
    )"

    [[ "$actual_hash" == "$ARDUINO_UDEV_RULES_SHA256" ]] ||
        return 1

    ownership_and_mode="$(
        stat \
            --format='%U:%G:%a' \
            "$ARDUINO_UDEV_RULES_FILE" \
            2>/dev/null
    )"

    [[ "$ownership_and_mode" == "root:root:644" ]]
}

check_wireshark_complete() {
    pacman -Q wireshark-qt >/dev/null 2>&1 &&
        command -v wireshark >/dev/null 2>&1 &&
        getent group wireshark >/dev/null 2>&1 &&
        id -nG "$USER" 2>/dev/null |
        tr ' ' '\n' |
        grep -qx wireshark
}

configure_wireshark_capture() {
    getent group wireshark >/dev/null 2>&1 ||
        fail "Die benötigte Gruppe 'wireshark' wurde nicht gefunden."

    if id -nG "$USER" 2>/dev/null |
        tr ' ' '\n' |
        grep -qx wireshark
    then
        info "Der Benutzer ist bereits Mitglied der Gruppe wireshark."
        return 0
    fi

    info "Ergänze den Benutzer um die für Wireshark-Aufzeichnungen vorgesehene Gruppe."

    sudo usermod -aG wireshark "$USER"

    id -nG "$USER" 2>/dev/null |
        tr ' ' '\n' |
        grep -qx wireshark ||
        fail "Die Wireshark-Gruppenmitgliedschaft konnte nicht bestätigt werden."

    info "Die Wireshark-Gruppe wurde ergänzt."
    info "Damit sie in der laufenden Sitzung gilt, ist eine erneute Anmeldung erforderlich."
}

install_wireshark() {
    program_is_available wireshark || return 1

    if pacman -Q wireshark-qt >/dev/null 2>&1; then
        info "Das Paket wireshark-qt ist bereits installiert."
    else
        info "Installiere Wireshark aus dem offiziellen Arch-Repository."

        sudo pacman             --sync             --needed             --noconfirm             wireshark-qt || return $?
    fi

    configure_wireshark_capture

    check_wireshark_complete ||
        fail "Wireshark wurde nicht vollständig eingerichtet."
}


check_xampp_complete() {
    [[ -x /opt/lampp/lampp ]]
}

program_packages() {
    case "$1" in
        obsidian)
            printf '%s\n' obsidian
            ;;
        element)
            printf '%s\n' element-desktop
            ;;
        discord)
            printf '%s\n' discord
            ;;
        prismlauncher)
            printf '%s\n' prismlauncher
            ;;
        mysql-workbench)
            printf '%s\n' mysql-workbench
            ;;
        docker)
            printf '%s\n' docker docker-compose
            ;;
        wireshark)
            printf '%s\n' wireshark-qt
            ;;
        burpsuite|ffuf)
            printf '%s\n' "$1"
            ;;
        tcpdump|keepassxc|clamav|lynis|nmap|zaproxy|sqlmap|gobuster|hydra|john|hashcat|aircrack-ng|metasploit)
            printf '%s\n' "$1"
            ;;
        *)
            return 1
            ;;
    esac
}


program_command() {
    case "$1" in
        obsidian|discord|prismlauncher|mysql-workbench|docker|wireshark|tcpdump|keepassxc|lynis|nmap|burpsuite|zaproxy|sqlmap|gobuster|ffuf|hydra|john|hashcat|aircrack-ng)
            printf '%s\n' "$1"
            ;;
        element)
            printf '%s\n' element-desktop
            ;;
        clamav)
            printf '%s\n' clamscan
            ;;
        metasploit)
            printf '%s\n' msfconsole
            ;;
        *)
            return 1
            ;;
    esac
}


program_is_installed() {
    local program_id="$1"
    local package=""
    local required_command=""
    local -a packages=()

    case "$program_id" in
        brave)
            check_brave_complete
            return
            ;;
        powershell)
            check_powershell_complete
            return
            ;;
        vscode)
            check_vscode_complete
            return
            ;;
        arduino)
            check_arduino_ide_complete &&
                check_arduino_udev_complete
            return
            ;;
        wireshark)
            check_wireshark_complete
            return
            ;;
        xampp)
            check_xampp_complete
            return
            ;;
    esac

    mapfile -t packages < <(
        program_packages "$program_id"
    ) || return 1

    ((${#packages[@]} > 0)) || return 1

    for package in "${packages[@]}"; do
        pacman -Q "$package" >/dev/null 2>&1 || return 1
    done

required_command="$(
    program_command "$program_id" 2>/dev/null ||
        true
)"

if [[ -n "$required_command" ]]; then
    command -v "$required_command" >/dev/null 2>&1 ||
        return 1
fi

if [[ "$program_id" == "docker" ]]; then
        command -v docker >/dev/null 2>&1 &&
            systemctl is-enabled docker.service >/dev/null 2>&1 &&
            id -nG "$USER" 2>/dev/null |
                tr ' ' '\n' |
                grep -qx docker
        return
    fi

    return 0
}

commands_are_available() {
    local command_name=""

    for command_name in "$@"; do
        if ! command -v "$command_name" >/dev/null 2>&1; then
            warn "Benötigter Befehl wurde nicht gefunden: $command_name"
            return 1
        fi
    done

    return 0
}

verify_pinned_aur_source_available() (
    set -Eeuo pipefail

    local label="$1"
    local repository="$2"
    local commit="$3"
    local pkgbuild_sha256="$4"
    local srcinfo_sha256="$5"
    local temporary_directory=""
    local repository_directory=""

    temporary_directory="$(
        mktemp -d -t custom-linux-aur-source-check.XXXXXXXX
    )"
    repository_directory="$temporary_directory/repository"

    trap 'rm -rf -- "$temporary_directory"' EXIT

    info "$label: Geprüfte AUR-Quelle wird vor der Bestätigung kontrolliert."

    if ! timeout 45 git clone \
        --quiet \
        --no-checkout \
        "$repository" \
        "$repository_directory"; then
        warn "$label: AUR-Repository ist derzeit nicht erreichbar."
        return 1
    fi

    if ! git -C "$repository_directory" \
        cat-file -e "${commit}^{commit}" 2>/dev/null; then
        warn "$label: Der festgelegte AUR-Commit ist nicht verfügbar."
        return 1
    fi

    if ! git -C "$repository_directory" \
        checkout --quiet "$commit"; then
        warn "$label: Der festgelegte AUR-Commit konnte nicht ausgecheckt werden."
        return 1
    fi

    if [[ ! -f "$repository_directory/PKGBUILD" ||
          ! -f "$repository_directory/.SRCINFO" ]]; then
        warn "$label: PKGBUILD oder .SRCINFO fehlt im geprüften Commit."
        return 1
    fi

    if ! (
        cd "$repository_directory"

        printf '%s  PKGBUILD\n' "$pkgbuild_sha256" |
            sha256sum --check --status

        printf '%s  .SRCINFO\n' "$srcinfo_sha256" |
            sha256sum --check --status
    ); then
        warn "$label: Die AUR-Prüfsummen stimmen nicht mit dem geprüften Stand überein."
        return 1
    fi

    info "$label: Repository, Commit und AUR-Prüfsummen stimmen."
)

program_is_available() {
    local program_id="$1"
    local package=""
    local aur_helper=""
    local -a packages=()

    case "$program_id" in
        brave)
            aur_helper="$(find_aur_helper)" || {
                warn "Brave benötigt einen vorhandenen AUR-Helfer."
                return 1
            }

            info "Verfügbarer AUR-Helfer für Brave: $aur_helper"
            return 0
            ;;
        powershell)
            commands_are_available curl sha256sum tar
            return
            ;;
        vscode)
            commands_are_available git sha256sum makepkg pacman
            return
            ;;
        arduino)
            commands_are_available \
                git \
                sha256sum \
                makepkg \
                pacman \
                udevadm \
                install
            return
            ;;
        wireshark)
            commands_are_available                 pacman                 getent                 id                 tr                 grep                 sudo                 usermod ||
                return 1

            pacman -Si wireshark-qt >/dev/null 2>&1 || {
                warn "Paket nicht in den aktiven Pacman-Repositories gefunden: wireshark-qt"
                return 1
            }

            return 0
            ;;
        burpsuite)
            commands_are_available \
                git \
                sha256sum \
                makepkg \
                pacman \
                mktemp \
                timeout ||
                return 1

            verify_pinned_aur_source_available \
                "${PROGRAM_LABELS[$program_id]}" \
                "$BURPSUITE_AUR_REPOSITORY" \
                "$BURPSUITE_AUR_COMMIT" \
                "$BURPSUITE_PKGBUILD_SHA256" \
                "$BURPSUITE_SRCINFO_SHA256"
            return
            ;;
        ffuf)
            commands_are_available \
                git \
                sha256sum \
                makepkg \
                pacman \
                mktemp \
                timeout ||
                return 1

            verify_pinned_aur_source_available \
                "${PROGRAM_LABELS[$program_id]}" \
                "$FFUF_AUR_REPOSITORY" \
                "$FFUF_AUR_COMMIT" \
                "$FFUF_PKGBUILD_SHA256" \
                "$FFUF_SRCINFO_SHA256"
            return
            ;;
        xampp)
            commands_are_available curl sha256sum chmod
            return
            ;;
    esac

    mapfile -t packages < <(
        program_packages "$program_id"
    ) || return 1

    for package in "${packages[@]}"; do
        pacman -Si "$package" >/dev/null 2>&1 || {
            warn \
                "Paket nicht in den aktiven Pacman-Repositories gefunden: $package"
            return 1
        }
    done

    return 0
}

read_failure_field() {
    local failure_file="$1"
    local field_name="$2"

    [[ -r "$failure_file" ]] || return 1

    awk \
        -F= \
        -v wanted="$field_name" \
        '
            $1 == wanted {
                sub(/^[^=]*=/, "")
                print
                exit
            }
        ' \
        "$failure_file"
}

log_matches() {
    local log_file="$1"
    local pattern="$2"

    [[ -r "$log_file" ]] || return 1

    LC_ALL=C grep \
        -E \
        -i \
        -q \
        -- \
        "$pattern" \
        "$log_file"
}

detect_failure_source() {
    local program_id="$1"
    local result="$2"
    local log_file="$3"
    local post_check_failed="${4:-0}"

    if (( post_check_failed != 0 )); then
        printf '%s\n' postcheck
        return 0
    fi

    if log_matches \
        "$log_file" \
        '\[TESTSPERRE\].*sudo.*blockiert'
    then
        printf '%s\n' test-lock
        return 0
    fi

    if log_matches \
        "$log_file" \
        'Prüfsumme.*stimmt nicht|checksum.*(failed|did not pass|mismatch)'
    then
        printf '%s\n' checksum
        return 0
    fi

    if log_matches "$log_file" 'curl: \([0-9]+\)'; then
        printf '%s\n' curl
        return 0
    fi

    if log_matches \
        "$log_file" \
        'unable to lock database|Datenbank.*nicht.*sperr|target not found|Ziel nicht gefunden|failed retrieving file|failed to commit transaction|Transaktion.*fehlgeschlagen|invalid or corrupted package|ungültiges oder beschädigtes Paket|conflicting files|Dateikonflikt'
    then
        printf '%s\n' pacman
        return 0
    fi

    if log_matches \
        "$log_file" \
        '==> (ERROR|FEHLER):|A failure occurred in build|Fehler beim Erstellen'
    then
        printf '%s\n' makepkg
        return 0
    fi

    if log_matches \
        "$log_file" \
        'fatal:|not a git repository|Authentication failed|Repository not found|pathspec .* did not match'
    then
        printf '%s\n' git
        return 0
    fi

    if log_matches \
        "$log_file" \
        'tar:|unexpected end of file|unexpected EOF|not in gzip format'
    then
        printf '%s\n' archive
        return 0
    fi

    if log_matches \
        "$log_file" \
        'Failed to enable unit|Failed to start|Unit .* not found|Einheit .* nicht gefunden|systemctl:'
    then
        printf '%s\n' systemd
        return 0
    fi

    if log_matches "$log_file" 'usermod:'; then
        printf '%s\n' usermod
        return 0
    fi

    if log_matches \
        "$log_file" \
        'sudo:|not in the sudoers|nicht in der sudoers'
    then
        printf '%s\n' sudo
        return 0
    fi

    case "$result" in
        126|127|130|137|139|141|143)
            printf '%s\n' shell
            return 0
            ;;
    esac

    case "$program_id" in
        obsidian|element|discord|prismlauncher|mysql-workbench|docker)
            printf '%s\n' pacman
            ;;
        brave)
            printf '%s\n' aur-helper
            ;;
        vscode|arduino)
            printf '%s\n' aur-build
            ;;
        powershell|xampp)
            printf '%s\n' installer
            ;;
        *)
            printf '%s\n' unknown
            ;;
    esac
}

failure_source_label() {
    case "$1" in
        pacman)
            printf '%s\n' pacman
            ;;
        curl)
            printf '%s\n' curl
            ;;
        git)
            printf '%s\n' git
            ;;
        makepkg)
            printf '%s\n' makepkg
            ;;
        aur-helper)
            printf '%s\n' AUR-Helfer
            ;;
        aur-build)
            printf '%s\n' AUR-Paketbau
            ;;
        checksum)
            printf '%s\n' SHA-256-Prüfung
            ;;
        archive)
            printf '%s\n' Archivverarbeitung
            ;;
        systemd)
            printf '%s\n' systemctl
            ;;
        usermod)
            printf '%s\n' Benutzergruppenverwaltung
            ;;
        sudo)
            printf '%s\n' sudo
            ;;
        installer)
            printf '%s\n' Installationsablauf
            ;;
        postcheck)
            printf '%s\n' Abschlussprüfung
            ;;
        test-lock)
            printf '%s\n' Testsperre
            ;;
        shell)
            printf '%s\n' Shell/Prozess
            ;;
        *)
            printf '%s\n' unbekannte Fehlerquelle
            ;;
    esac
}

failure_phase_text() {
    case "$1" in
        pacman)
            printf '%s\n' 'Paket aus Arch-Repositories installieren'
            ;;
        curl)
            printf '%s\n' 'Datei aus dem Internet herunterladen'
            ;;
        git)
            printf '%s\n' 'Git-Repository laden oder festgelegten Commit auschecken'
            ;;
        makepkg|aur-build)
            printf '%s\n' 'AUR-Paket prüfen, bauen und installieren'
            ;;
        aur-helper)
            printf '%s\n' 'AUR-Paket über einen vorhandenen Helfer installieren'
            ;;
        checksum)
            printf '%s\n' 'Heruntergeladene Datei oder Paketdefinition verifizieren'
            ;;
        archive)
            printf '%s\n' 'Heruntergeladenes Archiv entpacken'
            ;;
        systemd)
            printf '%s\n' 'Systemdienst einrichten'
            ;;
        usermod)
            printf '%s\n' 'Benutzer einer benötigten Gruppe hinzufügen'
            ;;
        sudo)
            printf '%s\n' 'Befehl mit Administratorrechten ausführen'
            ;;
        postcheck)
            printf '%s\n' 'Installation abschließend bestätigen'
            ;;
        test-lock)
            printf '%s\n' 'Sicherer Test ohne echte Installation'
            ;;
        shell)
            printf '%s\n' 'Installationsprozess ausführen'
            ;;
        *)
            printf '%s\n' 'Programminstallation ausführen'
            ;;
    esac
}

general_exit_code_meaning() {
    local result="$1"
    local signal_number=0
    local signal_name=""

    case "$result" in
        0)
            printf '%s\n' 'Der Befehl wurde erfolgreich abgeschlossen.'
            ;;
        1)
            printf '%s\n' 'Der Befehl meldete einen allgemeinen Fehler.'
            ;;
        2)
            printf '%s\n' 'Der Befehl meldete einen falschen Aufruf oder einen eigenen Fehlercode 2.'
            ;;
        126)
            printf '%s\n' 'Der Befehl wurde gefunden, konnte aber nicht ausgeführt werden.'
            ;;
        127)
            printf '%s\n' 'Der benötigte Befehl wurde nicht gefunden.'
            ;;
        130)
            printf '%s\n' 'Der Prozess wurde mit Strg+C unterbrochen.'
            ;;
        137)
            printf '%s\n' 'Der Prozess wurde gewaltsam beendet; möglich sind Speichermangel oder SIGKILL.'
            ;;
        139)
            printf '%s\n' 'Der Prozess wurde durch einen Speicherzugriffsfehler beendet.'
            ;;
        141)
            printf '%s\n' 'Eine Ausgabe-Pipeline wurde geschlossen; der Prozess erhielt SIGPIPE.'
            ;;
        143)
            printf '%s\n' 'Der Prozess wurde regulär durch SIGTERM beendet.'
            ;;
        255)
            printf '%s\n' 'Der Befehl meldete einen schweren oder nicht näher eingeordneten Fehler.'
            ;;
        *)
            if [[ "$result" =~ ^[0-9]+$ ]] &&
               (( result >= 129 && result <= 192 )); then
                signal_number=$((result - 128))
                signal_name="$(
                    kill -l "$signal_number" 2>/dev/null ||
                        true
                )"

                if [[ -n "$signal_name" ]]; then
                    printf \
                        'Der Prozess wurde durch das Signal %s beendet.' \
                        "$signal_name"
                    printf '\n'
                else
                    printf \
                        'Der Prozess wurde durch Linux-Signal %s beendet.\n' \
                        "$signal_number"
                fi
            else
                printf \
                    'Für diesen Exit-Code existiert keine eindeutige allgemeine Bedeutung.\n'
            fi
            ;;
    esac
}

curl_exit_code_meaning() {
    case "$1" in
        1)
            printf '%s\n' 'Das verwendete Netzwerkprotokoll wird von curl nicht unterstützt.'
            ;;
        2)
            printf '%s\n' 'curl konnte nicht korrekt initialisiert werden.'
            ;;
        3)
            printf '%s\n' 'Die Downloadadresse besitzt ein ungültiges Format.'
            ;;
        5)
            printf '%s\n' 'Der Name des eingestellten Proxyservers konnte nicht aufgelöst werden.'
            ;;
        6)
            printf '%s\n' 'Der Name des Downloadservers konnte nicht per DNS aufgelöst werden.'
            ;;
        7)
            printf '%s\n' 'Die Verbindung zum Downloadserver konnte nicht aufgebaut werden.'
            ;;
        18)
            printf '%s\n' 'Die heruntergeladene Datei war unvollständig.'
            ;;
        22)
            printf '%s\n' 'Der Webserver antwortete mit einem HTTP-Fehler ab Status 400.'
            ;;
        23)
            printf '%s\n' 'Die heruntergeladenen Daten konnten nicht lokal gespeichert werden.'
            ;;
        27)
            printf '%s\n' 'curl hatte nicht genügend Arbeitsspeicher.'
            ;;
        28)
            printf '%s\n' 'Der Download überschritt das erlaubte Zeitlimit.'
            ;;
        35)
            printf '%s\n' 'Der Aufbau der verschlüsselten TLS-Verbindung ist fehlgeschlagen.'
            ;;
        47)
            printf '%s\n' 'Der Download wurde zu oft auf eine andere Adresse weitergeleitet.'
            ;;
        52)
            printf '%s\n' 'Der Server schloss die Verbindung, ohne Daten zurückzugeben.'
            ;;
        55)
            printf '%s\n' 'Netzwerkdaten konnten nicht gesendet werden.'
            ;;
        56)
            printf '%s\n' 'Beim Empfangen der Netzwerkdaten trat ein Fehler auf.'
            ;;
        60)
            printf '%s\n' 'Das Zertifikat des Servers konnte nicht erfolgreich geprüft werden.'
            ;;
        63)
            printf '%s\n' 'Die heruntergeladene Datei überschritt die erlaubte Maximalgröße.'
            ;;
        77)
            printf '%s\n' 'Die lokale Datei mit vertrauenswürdigen Zertifikaten konnte nicht gelesen werden.'
            ;;
        78)
            printf '%s\n' 'Die angeforderte Datei wurde auf dem Server nicht gefunden.'
            ;;
        92)
            printf '%s\n' 'Im verwendeten HTTP/2-Datenstrom trat ein Fehler auf.'
            ;;
        95)
            printf '%s\n' 'In der HTTP/3-Verbindung trat ein Fehler auf.'
            ;;
        96)
            printf '%s\n' 'Die QUIC-Verbindung für HTTP/3 konnte nicht aufgebaut werden.'
            ;;
        97)
            printf '%s\n' 'Der Verbindungsaufbau über den Proxy ist fehlgeschlagen.'
            ;;
        *)
            general_exit_code_meaning "$1"
            ;;
    esac
}

failure_meaning() {
    local source_id="$1"
    local result="$2"
    local log_file="$3"

    case "$source_id" in
        test-lock)
            printf '%s\n' 'Die Testsperre hat den Administratorbefehl absichtlich blockiert.'
            ;;
        postcheck)
            printf '%s\n' 'Der Installationsbefehl meldete Erfolg, das Programm wurde danach aber nicht vollständig gefunden.'
            ;;
        curl)
            curl_exit_code_meaning "$result"
            ;;
        checksum)
            printf '%s\n' 'Die berechnete SHA-256-Prüfsumme stimmt nicht mit dem festgelegten Wert überein.'
            ;;
        pacman)
            if log_matches "$log_file" 'unable to lock database|Datenbank.*nicht.*sperr'; then
                printf '%s\n' 'Die Pacman-Datenbank ist durch einen anderen Paketvorgang gesperrt.'
            elif log_matches "$log_file" 'target not found|Ziel nicht gefunden'; then
                printf '%s\n' 'Das angeforderte Paket wurde in den aktiven Repositories nicht gefunden.'
            elif log_matches "$log_file" 'failed retrieving file|Datei.*konnte nicht.*übertragen'; then
                printf '%s\n' 'Eine Paketdatei konnte nicht vom Spiegelserver geladen werden.'
            elif log_matches "$log_file" 'invalid or corrupted package|ungültiges oder beschädigtes Paket|PGP signature|PGP-Signatur'; then
                printf '%s\n' 'Ein Paket oder seine kryptografische Signatur konnte nicht bestätigt werden.'
            elif log_matches "$log_file" 'not enough free disk space|nicht genügend freier Speicher'; then
                printf '%s\n' 'Für die Installation ist nicht genügend freier Speicherplatz vorhanden.'
            elif log_matches "$log_file" 'conflicting files|Dateikonflikt'; then
                printf '%s\n' 'Vorhandene Dateien stehen mit dem zu installierenden Paket in Konflikt.'
            elif log_matches "$log_file" 'could not satisfy dependencies|Abhängigkeiten.*nicht.*erfüllt'; then
                printf '%s\n' 'Mindestens eine benötigte Paketabhängigkeit konnte nicht erfüllt werden.'
            else
                printf '%s\n' 'Pacman konnte die Paketinstallation nicht abschließen.'
            fi
            ;;
        git)
            if log_matches "$log_file" 'Could not resolve host|Name or service not known'; then
                printf '%s\n' 'Der Git-Server konnte nicht per DNS aufgelöst werden.'
            elif log_matches "$log_file" 'Connection timed out|Connection refused'; then
                printf '%s\n' 'Die Verbindung zum Git-Server ist fehlgeschlagen.'
            elif log_matches "$log_file" 'Authentication failed|Permission denied'; then
                printf '%s\n' 'Die Anmeldung oder Zugriffsberechtigung am Git-Repository ist fehlgeschlagen.'
            elif log_matches "$log_file" 'Repository not found'; then
                printf '%s\n' 'Das angeforderte Git-Repository wurde nicht gefunden.'
            elif log_matches "$log_file" 'pathspec .* did not match|reference is not a tree'; then
                printf '%s\n' 'Der festgelegte Git-Commit oder Verweis ist nicht verfügbar.'
            else
                printf '%s\n' 'Git konnte das Repository oder den festgelegten Stand nicht verarbeiten.'
            fi
            ;;
        makepkg|aur-build)
            if log_matches "$log_file" 'Could not resolve all dependencies|Abhängigkeiten.*nicht.*auflösen'; then
                printf '%s\n' 'Die Abhängigkeiten des AUR-Pakets konnten nicht aufgelöst werden.'
            elif log_matches "$log_file" 'One or more files did not pass the validity check|Gültigkeitsprüfung.*fehlgeschlagen'; then
                printf '%s\n' 'Mindestens eine Quelldatei des AUR-Pakets bestand die Prüfsummenprüfung nicht.'
            elif log_matches "$log_file" 'A failure occurred in build|Fehler beim Erstellen'; then
                printf '%s\n' 'Das AUR-Paket konnte nicht erfolgreich gebaut werden.'
            else
                printf '%s\n' 'Die AUR-Paketdefinition konnte nicht vollständig gebaut oder installiert werden.'
            fi
            ;;
        aur-helper)
            printf '%s\n' 'Der AUR-Helfer konnte das ausgewählte Paket nicht installieren.'
            ;;
        archive)
            printf '%s\n' 'Das heruntergeladene Archiv konnte nicht vollständig entpackt werden.'
            ;;
        systemd)
            printf '%s\n' 'Der benötigte Systemdienst konnte nicht eingerichtet oder gestartet werden.'
            ;;
        usermod)
            printf '%s\n' 'Der Benutzer konnte nicht der benötigten Systemgruppe hinzugefügt werden.'
            ;;
        sudo)
            printf '%s\n' 'Der benötigte Administratorbefehl konnte nicht ausgeführt werden.'
            ;;
        installer)
            printf '%s\n' 'Der programmspezifische Installationsablauf konnte nicht abgeschlossen werden.'
            ;;
        shell)
            general_exit_code_meaning "$result"
            ;;
        *)
            general_exit_code_meaning "$result"
            ;;
    esac
}

failure_recommendation() {
    local source_id="$1"
    local result="$2"
    local log_file="$3"

    case "$source_id" in
        test-lock)
            printf '%s\n' 'Keine Maßnahme nötig; dies war ein absichtlich gesicherter Test.'
            ;;
        postcheck)
            printf '%s\n' 'Programmstatus und letzte Protokollzeilen prüfen und die Auswahl danach erneut starten.'
            ;;
        curl)
            case "$result" in
                5|6)
                    printf '%s\n' 'Internetverbindung und DNS-Auflösung prüfen.'
                    ;;
                7|28|52|55|56)
                    printf '%s\n' 'Netzwerk, Firewall und Erreichbarkeit des Downloadservers prüfen und später erneut versuchen.'
                    ;;
                22|78)
                    printf '%s\n' 'Downloadadresse und festgelegte Programmversion prüfen.'
                    ;;
                35|60|77)
                    printf '%s\n' 'Systemzeit, Zertifikatspaket und TLS-Verbindung prüfen.'
                    ;;
                23|63)
                    printf '%s\n' 'Freien Speicherplatz und Schreibrechte des Zielverzeichnisses prüfen.'
                    ;;
                *)
                    printf '%s\n' 'Die curl-Meldung im Programmprotokoll prüfen und den Download erneut versuchen.'
                    ;;
            esac
            ;;
        checksum)
            printf '%s\n' 'Datei nicht verwenden; Downloadquelle, Version und festgelegte Prüfsumme kontrollieren.'
            ;;
        pacman)
            if log_matches "$log_file" 'unable to lock database|Datenbank.*nicht.*sperr'; then
                printf '%s\n' 'Anderen Paketmanager beenden und niemals die Sperrdatei während eines laufenden Vorgangs löschen.'
            elif log_matches "$log_file" 'target not found|Ziel nicht gefunden'; then
                printf '%s\n' 'Paketnamen und synchronisierte Repository-Datenbanken prüfen.'
            elif log_matches "$log_file" 'failed retrieving file|Datei.*konnte nicht.*übertragen'; then
                printf '%s\n' 'Internetverbindung und Arch-Spiegelserver prüfen und später erneut versuchen.'
            elif log_matches "$log_file" 'PGP signature|PGP-Signatur|invalid or corrupted package|ungültiges oder beschädigtes Paket'; then
                printf '%s\n' 'Schlüsselbund und Systemzeit prüfen; das Paket nicht ungeprüft erzwingen.'
            elif log_matches "$log_file" 'not enough free disk space|nicht genügend freier Speicher'; then
                printf '%s\n' 'Speicherplatz freigeben und die Programmauswahl erneut starten.'
            else
                printf '%s\n' 'Die letzten Pacman-Zeilen im angegebenen Protokoll prüfen.'
            fi
            ;;
        git)
            printf '%s\n' 'Netzwerk, Repository-Adresse und festgelegten Commit anhand des Protokolls prüfen.'
            ;;
        makepkg|aur-build|aur-helper)
            printf '%s\n' 'AUR-Paketdefinition, Abhängigkeiten und die letzten Build-Zeilen im Protokoll prüfen.'
            ;;
        archive)
            printf '%s\n' 'Download und Prüfsumme kontrollieren; eine unvollständige Datei nicht weiterverwenden.'
            ;;
        systemd)
            printf '%s\n' 'Dienstname sowie systemctl- und journalctl-Ausgabe prüfen.'
            ;;
        usermod)
            printf '%s\n' 'Benutzername, Zielgruppe und Administratorrechte prüfen.'
            ;;
        sudo)
            printf '%s\n' 'sudo-Berechtigung und eingegebenes Kennwort prüfen.'
            ;;
        shell)
            case "$result" in
                126)
                    printf '%s\n' 'Dateirechte, Dateiformat und passenden Interpreter prüfen.'
                    ;;
                127)
                    printf '%s\n' 'Das fehlende Programm installieren oder den verwendeten Befehl korrigieren.'
                    ;;
                130)
                    printf '%s\n' 'Die Auswahl erneut starten, falls der Abbruch nicht beabsichtigt war.'
                    ;;
                137)
                    printf '%s\n' 'Arbeitsspeicher, Swap und Kernel-Protokoll auf einen OOM-Abbruch prüfen.'
                    ;;
                *)
                    printf '%s\n' 'Die letzten Zeilen des angegebenen Protokolls prüfen.'
                    ;;
            esac
            ;;
        *)
            printf '%s\n' 'Die letzten Zeilen des angegebenen Programmprotokolls prüfen.'
            ;;
    esac
}

program_status_text() {
    local program_id="$1"
    local failure_file="$STATE_DIR/$program_id.failed"
    local result=""
    local source_label=""
    local meaning=""

    if program_is_installed "$program_id"; then
        printf 'bereits installiert'
        return 0
    fi

    if [[ -s "$failure_file" ]]; then
        result="$(
            read_failure_field "$failure_file" exit_code ||
                true
        )"
        source_label="$(
            read_failure_field "$failure_file" source_label ||
                true
        )"
        meaning="$(
            read_failure_field "$failure_file" meaning ||
                true
        )"

        if [[ -n "$result" && -n "$meaning" ]]; then
            printf \
                'offen – Exit-Code %s (%s): %s' \
                "$result" \
                "${source_label:-unbekannt}" \
                "$meaning"
            return 0
        fi

        printf 'offen – vorheriger Installationsfehler'
        return 0
    fi

    printf 'nicht installiert'
}

validate_program_id() {
    [[ -n "${PROGRAM_LABELS[$1]+vorhanden}" ]]
}

program_matches_group() {
    local program_id="$1"
    local group_id="$2"

    [[ "$group_id" == "all" ||
       "${PROGRAM_GROUPS[$program_id]:-}" == "$group_id" ]]
}

prepare_visible_programs() {
    local program_id=""

    VISIBLE_PROGRAM_IDS=()

    for program_id in "${PROGRAM_IDS[@]}"; do
        if program_matches_group \
            "$program_id" \
            "$SELECTED_PROGRAM_GROUP"
        then
            VISIBLE_PROGRAM_IDS+=("$program_id")
        fi
    done

    ((${#VISIBLE_PROGRAM_IDS[@]} > 0))
}

program_is_visible() {
    local requested_id="$1"
    local program_id=""

    for program_id in "${VISIBLE_PROGRAM_IDS[@]}"; do
        if [[ "$program_id" == "$requested_id" ]]; then
            return 0
        fi
    done

    return 1
}

validate_visible_program_id() {
    validate_program_id "$1" &&
        program_is_visible "$1"
}


program_is_selected() {
    local wanted_program_id="$1"
    local selected_program_id=""

    for selected_program_id in "${SELECTED_PROGRAMS[@]}"; do
        if [[ "$selected_program_id" == "$wanted_program_id" ]]; then
            return 0
        fi
    done

    return 1
}

requested_selection_contains() {
    local wanted_program_id="$1"
    local requested_program_id=""

    shift

    for requested_program_id in "$@"; do
        if [[ "$requested_program_id" == "$wanted_program_id" ]]; then
            return 0
        fi
    done

    return 1
}

replace_visible_program_selection() {
    local -a requested_programs=("$@")
    local -a updated_programs=()
    local program_id=""

    for program_id in "${SELECTED_PROGRAMS[@]}"; do
        if ! program_is_visible "$program_id"; then
            updated_programs+=("$program_id")
        fi
    done

    for program_id in "${VISIBLE_PROGRAM_IDS[@]}"; do
        if requested_selection_contains             "$program_id"             "${requested_programs[@]}"; then
            updated_programs+=("$program_id")
        fi
    done

    SELECTED_PROGRAMS=("${updated_programs[@]}")
}

select_program_group_dialog() {
    local group_id=""
    local output=""
    local -a menu_items=()

    for group_id in "${PROGRAM_GROUP_IDS[@]}"; do
        menu_items+=(
            "$group_id"
            "${PROGRAM_GROUP_LABELS[$group_id]} – ${PROGRAM_GROUP_DESCRIPTIONS[$group_id]}"
        )
    done

    menu_items+=(
        finish
        "Auswahl abschließen – ${#SELECTED_PROGRAMS[@]} gewählt"
        back
        "Zurück – Auswahl verwerfen"
    )

    if ! output="$(
        dialog_no_cursor             --clear             --title "Programmkategorien"             --ok-label "Öffnen"             --cancel-label "Zurück"             --menu             "Mehrere Kategorien können nacheinander geöffnet werden.
Aktuell ausgewählt: ${#SELECTED_PROGRAMS[@]}"             22 86 10             "${menu_items[@]}"             3>&1 1>&2 2>&3
    )"; then
        SELECTED_PROGRAM_GROUP="back"
        return 0
    fi

    SELECTED_PROGRAM_GROUP="$output"
}

select_program_group_text() {
    local answer=""
    local group_id=""
    local index=1
    local group_count="${#PROGRAM_GROUP_IDS[@]}"
    local finish_index=$((group_count + 1))
    local choice_number=0

    printf '
Programmkategorien:

'
    printf 'Auswahlkorb: %s Programm(e)

' "${#SELECTED_PROGRAMS[@]}"

    for group_id in "${PROGRAM_GROUP_IDS[@]}"; do
        printf '  %d) %-26s %s
' \
            "$index" \
            "${PROGRAM_GROUP_LABELS[$group_id]}" \
            "${PROGRAM_GROUP_DESCRIPTIONS[$group_id]}"

        index=$((index + 1))
    done

    printf '  %d) %s
' "$finish_index" "Auswahl abschließen"
    printf '  0) %s
' "Zurück – Auswahl verwerfen"
    printf '
'

    read -r -p 'Kategorie oder Aktion wählen: ' answer || {
        SELECTED_PROGRAM_GROUP="back"
        return 0
    }

    case "$answer" in
        0)
            SELECTED_PROGRAM_GROUP="back"
            return 0
            ;;

        "$finish_index")
            SELECTED_PROGRAM_GROUP="finish"
            return 0
            ;;
    esac

    if [[ ! "$answer" =~ ^[0-9]+$ ]]; then
        warn "Ungültige Kategorieauswahl: $answer"
        return 1
    fi

    choice_number=$((10#$answer))

    if (( choice_number < 1 || choice_number > group_count )); then
        warn "Ungültige Kategorieauswahl: $answer"
        return 1
    fi

    SELECTED_PROGRAM_GROUP="${PROGRAM_GROUP_IDS[$((choice_number - 1))]}"
}


select_programs_dialog() {
    local program_id=""
    local status=""
    local selection_state=""
    local output=""
    local -a checklist_items=()
    local -a requested_programs=()

    for program_id in "${VISIBLE_PROGRAM_IDS[@]}"; do
        status="$(program_status_text "$program_id")"
        selection_state="off"

        if program_is_selected "$program_id"; then
            selection_state="on"
        fi

        checklist_items+=(
            "$program_id"
            "${PROGRAM_LABELS[$program_id]} – ${PROGRAM_DESCRIPTIONS[$program_id]} [$status]"
            "$selection_state"
        )
    done

    if ! output="$(
        dialog_no_cursor             --clear             --title "Optionale Programme – ${PROGRAM_GROUP_LABELS[$SELECTED_PROGRAM_GROUP]}"             --ok-label "Auswahl speichern"             --cancel-label "Zurück"             --separate-output             --checklist             "Leertaste: auswählen oder abwählen
Enter: Auswahl für diese Kategorie speichern
Zurück: bisher gespeicherte Auswahl behalten"             28 100 16             "${checklist_items[@]}"             3>&1 1>&2 2>&3
    )"; then
        return 1
    fi

    if [[ -n "$output" ]]; then
        mapfile -t requested_programs <<<"$output"
    fi

    replace_visible_program_selection "${requested_programs[@]}"
}

select_programs_text() {
    local answer=""
    local program_id=""
    local selection_marker=""
    local -a requested_programs=()

    printf '
Verfügbare Programme:

'

    for program_id in "${VISIBLE_PROGRAM_IDS[@]}"; do
        selection_marker="[ ]"

        if program_is_selected "$program_id"; then
            selection_marker="[x]"
        fi

        printf '  %s %-18s %-28s %s
' \
            "$selection_marker" \
            "$program_id" \
            "${PROGRAM_LABELS[$program_id]}" \
            "$(program_status_text "$program_id")"
    done

    printf '
Mehrere IDs mit Leerzeichen trennen.
'
    printf 'Bereits gespeicherte IDs dieser Kategorie erneut mit angeben.
'
    printf 'none leert diese Kategorie, 0 geht ohne Änderung zurück.
'

    read -r -p 'Auswahl speichern oder zurück: ' answer || return 1

    case "${answer,,}" in
        0|"")
            return 1
            ;;

        none)
            replace_visible_program_selection "${requested_programs[@]}"
            return 0
            ;;
    esac

    IFS=' ' read -r -a requested_programs <<<"$answer"

    for program_id in "${requested_programs[@]}"; do
        validate_visible_program_id "$program_id" || {
            warn "Unbekannte oder in dieser Kategorie nicht sichtbare Programm-ID: $program_id"
            return 1
        }
    done

    replace_visible_program_selection "${requested_programs[@]}"
}

select_programs() {
    local use_dialog=0

    SELECTED_PROGRAMS=()
    VISIBLE_PROGRAM_IDS=()
    SELECTED_PROGRAM_GROUP=""

    if [[ -t 0 && -t 2 ]] &&
       command -v dialog >/dev/null 2>&1 &&
       [[ -r "$DIALOGRC_FILE" ]]; then
        use_dialog=1
    fi

    while true; do
        if (( use_dialog != 0 )); then
            select_program_group_dialog || return 1
        else
            select_program_group_text || continue
        fi

        case "$SELECTED_PROGRAM_GROUP" in
            back)
                SELECTED_PROGRAMS=()
                VISIBLE_PROGRAM_IDS=()
                return 1
                ;;

            finish)
                if ((${#SELECTED_PROGRAMS[@]} == 0)); then
                    warn "Der Auswahlkorb ist noch leer."
                    continue
                fi

                VISIBLE_PROGRAM_IDS=("${PROGRAM_IDS[@]}")
                return 0
                ;;

            private|school|school-security|all)
                prepare_visible_programs || {
                    warn "In dieser Kategorie wurden keine Programme gefunden."
                    continue
                }

                if (( use_dialog != 0 )); then
                    if select_programs_dialog; then
                        info "Auswahl gespeichert: ${#SELECTED_PROGRAMS[@]} Programm(e) im Auswahlkorb."
                    else
                        info "Zurück zur Kategorieauswahl. Der bisherige Auswahlkorb bleibt erhalten."
                    fi
                elif select_programs_text; then
                    info "Auswahl gespeichert: ${#SELECTED_PROGRAMS[@]} Programm(e) im Auswahlkorb."
                else
                    info "Zurück zur Kategorieauswahl. Der bisherige Auswahlkorb bleibt erhalten."
                fi
                ;;

            *)
                warn "Unbekannte Programmkategorie: $SELECTED_PROGRAM_GROUP"
                ;;
        esac
    done
}


confirm_selection() {
    local answer=""
    local program_id=""

    printf '\nAusgewählte Programme:\n\n'

    for program_id in "${SELECTED_PROGRAMS[@]}"; do
        printf '  - %s (%s)\n' \
            "${PROGRAM_LABELS[$program_id]}" \
            "$(program_status_text "$program_id")"
    done

    printf '\n'

    while true; do
        read -r -p 'Diese Auswahl jetzt bearbeiten? [y/N]: ' answer || return 1

        case "${answer,,}" in
            y|yes)
                return 0
                ;;
            ""|n|no)
                return 1
                ;;
            *)
                printf 'Bitte y/yes oder n/no eingeben.\n'
                ;;
        esac
    done
}

confirm_continue_without_program() {
    local label="$1"
    local timeout_seconds=10
    local deadline=$((SECONDS + timeout_seconds))
    local remaining="$timeout_seconds"
    local elapsed=0
    local bar_width=10
    local position=0
    local progress=""
    local answer=""
    local character=""

    printf '\n'
    warn "Die Installation von '$label' ist fehlgeschlagen."

    if [[ ! -t 0 ]]; then
        warn "Keine interaktive Eingabe verfügbar."
        warn "Das Setup fährt in $timeout_seconds Sekunden automatisch ohne '$label' fort."
        sleep "$timeout_seconds"
        return 0
    fi

    while (( SECONDS < deadline )); do
        remaining=$((deadline - SECONDS))
        elapsed=$((timeout_seconds - remaining))
        progress=""

        for ((position = 0; position < bar_width; position++)); do
            if (( position < elapsed )); then
                progress+="█"
            else
                progress+="░"
            fi
        done

        printf '\r\033[2K'
        printf \
            "Ohne %s fortfahren? [Y/n] [%s] %2d Sekunden  Eingabe: %s" \
            "$label" \
            "$progress" \
            "$remaining" \
            "$answer"

        character=""

        if IFS= read -r -s -n 1 -t 1 character; then
            case "$character" in
                "")
                    printf '\r\033[2K'

                    case "${answer,,}" in
                        ""|y|yes)
                            return 0
                            ;;
                        n|no)
                            return 1
                            ;;
                        *)
                            printf \
                                'Bitte y/yes oder n/no eingeben. Der Timer läuft weiter.\n'
                            answer=""
                            ;;
                    esac
                    ;;

                $'\177'|$'\b')
                    if [[ -n "$answer" ]]; then
                        answer="${answer::-1}"
                    fi
                    ;;

                *)
                    if [[ "$character" =~ [[:print:]] ]] &&
                       ((${#answer} < 12)); then
                        answer+="$character"
                    fi
                    ;;
            esac
        fi
    done

    progress=""

    for ((position = 0; position < bar_width; position++)); do
        progress+="█"
    done

    printf '\r\033[2K'
    printf \
        "Ohne %s fortfahren? [Y/n] [%s]  0 Sekunden  Eingabe: %s\n" \
        "$label" \
        "$progress" \
        "$answer"
    warn "Die 10 Sekunden sind abgelaufen."
    warn "Das Setup fährt automatisch ohne '$label' fort."

    return 0
}

install_program() {
    local program_id="$1"
    local package=""
    local -a packages=()

    case "$program_id" in
        brave)
            install_brave
            return
            ;;
        powershell)
            install_powershell
            return
            ;;
        vscode)
            install_vscode
            return
            ;;
        arduino)
            install_arduino_ide
            configure_arduino_udev
            return
            ;;
        wireshark)
            install_wireshark
            return
            ;;
        burpsuite)
            install_burpsuite
            return
            ;;
        ffuf)
            install_ffuf
            return
            ;;
        xampp)
            install_xampp
            return
            ;;
    esac

    program_is_available "$program_id" || return 1

    mapfile -t packages < <(
        program_packages "$program_id"
    ) || return 1

    info "Installiere ${PROGRAM_LABELS[$program_id]}."

    sudo pacman \
        --sync \
        --needed \
        --noconfirm \
        "${packages[@]}" || return $?

    if [[ "$program_id" == "docker" ]]; then
        sudo systemctl enable --now docker.service || return $?
        sudo usermod -aG docker "$USER" || return $?
    fi
}

next_attempt_number() {
    local program_id="$1"
    local attempts_file="$STATE_DIR/$program_id.attempts"
    local attempts=0

    if [[ -r "$attempts_file" ]]; then
        read -r attempts <"$attempts_file" || attempts=0
    fi

    [[ "$attempts" =~ ^[0-9]+$ ]] || attempts=0
    attempts=$((attempts + 1))
    printf '%s\n' "$attempts" >"$attempts_file"
    printf '%s\n' "$attempts"
}

record_program_failure() {
    local program_id="$1"
    local result="$2"
    local log_file="$3"
    local source_id="$4"
    local source_label="$5"
    local phase="$6"
    local meaning="$7"
    local recommendation="$8"

    {
        printf 'program_id=%s\n' "$program_id"
        printf 'label=%s\n' "${PROGRAM_LABELS[$program_id]}"
        printf 'timestamp=%s\n' "$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
        printf 'exit_code=%s\n' "$result"
        printf 'source=%s\n' "$source_id"
        printf 'source_label=%s\n' "$source_label"
        printf 'phase=%s\n' "$phase"
        printf 'meaning=%s\n' "$meaning"
        printf 'recommendation=%s\n' "$recommendation"
        printf 'log=%s\n' "$log_file"
    } >"$STATE_DIR/$program_id.failed"
}

run_program_action() (
    set -Eeuo pipefail
    "$@"
)

run_selected_program() {
    local program_id="$1"
    local label="${PROGRAM_LABELS[$program_id]}"
    local attempt=0
    local result=0
    local started="$SECONDS"
    local duration=0
    local log_file=""
    local post_check_failed=0
    local source_id=""
    local source_label=""
    local phase=""
    local meaning=""
    local recommendation=""

    if program_is_installed "$program_id"; then
        info "$label ist bereits vollständig installiert und wird nicht neu installiert."
        ALREADY_INSTALLED_PROGRAMS+=("$label")
        rm -f -- "$STATE_DIR/$program_id.failed"
        return 0
    fi

    attempt="$(next_attempt_number "$program_id")"
    mkdir -p "$LOG_DIR/$program_id"
    log_file="$LOG_DIR/$program_id/attempt-${attempt}-$(date -u +'%Y%m%dT%H%M%SZ').log"

    set +e
    run_program_action install_program "$program_id" 2>&1 |
        tee -a "$log_file"
    result="${PIPESTATUS[0]}"
    set -e

    duration=$((SECONDS - started))

    if (( result == 0 )) && program_is_installed "$program_id"; then
        info "$label wurde erfolgreich installiert."
        printf '[INFO] Programmdauer: %s Minute(n) und %s Sekunde(n).\n' \
            "$((duration / 60))" \
            "$((duration % 60))"

        INSTALLED_PROGRAMS+=("$label")
        TOOL_OVERVIEW_REQUIRED=1
        rm -f -- "$STATE_DIR/$program_id.failed"
        return 0
    fi

    if (( result == 0 )); then
        result=1
        post_check_failed=1
        warn "$label meldete keinen Installationsfehler, wurde anschließend aber nicht gefunden."
    fi

    source_id="$(
        detect_failure_source \
            "$program_id" \
            "$result" \
            "$log_file" \
            "$post_check_failed"
    )"

    source_label="$(failure_source_label "$source_id")"
    phase="$(failure_phase_text "$source_id")"
    meaning="$(failure_meaning "$source_id" "$result" "$log_file")"
    recommendation="$(
        failure_recommendation \
            "$source_id" \
            "$result" \
            "$log_file"
    )"

    record_program_failure \
        "$program_id" \
        "$result" \
        "$log_file" \
        "$source_id" \
        "$source_label" \
        "$phase" \
        "$meaning" \
        "$recommendation"

    FAILED_PROGRAMS+=(
        "$label – Exit-Code $result ($source_label): $meaning – $log_file"
    )

    printf '\n'
    warn "Fehlercode: $result"
    warn "Fehlerquelle: $source_label"
    warn "Phase: $phase"
    warn "Bedeutung: $meaning"
    warn "Mögliche Abhilfe: $recommendation"
    warn "Programmprotokoll: $log_file"

    printf '[WARNUNG] Zeit bis zum Fehler: %s Minute(n) und %s Sekunde(n).\n' \
        "$((duration / 60))" \
        "$((duration % 60))"

    confirm_continue_without_program "$label"
}

print_program_precheck_note() {
    local program_id="$1"

    case "$program_id" in
        wireshark)
            info "Wireshark: Für Paketmitschnitte kann nach der Einrichtung eine erneute Anmeldung notwendig sein."
            ;;
        clamav)
            info "ClamAV: Signaturdaten und Prüfungen werden nicht automatisch gestartet."
            ;;
        burpsuite|ffuf)
            info "${PROGRAM_LABELS[$program_id]}: Installation erfolgt aus dem fest geprüften AUR-Stand."
            ;;
        hashcat)
            info "Hashcat: Zusätzliche GPU- oder OpenCL-Laufzeiten werden nicht automatisch installiert."
            ;;
        aircrack-ng)
            info "Aircrack-ng: Netzwerkadapter und Monitor-Modus werden nicht automatisch verändert."
            ;;
        metasploit)
            info "Metasploit: Datenbank und Dienste werden nicht automatisch eingerichtet."
            ;;
    esac
}

precheck_selected_programs() {
    local program_id=""
    local label=""
    local -a installable_programs=()

    UNAVAILABLE_PROGRAM_IDS=()
    UNAVAILABLE_PROGRAMS=()

    printf '\nVorprüfung der ausgewählten Programme\n'
    printf '======================================\n'

    for program_id in "${SELECTED_PROGRAMS[@]}"; do
        label="${PROGRAM_LABELS[$program_id]}"

        if program_is_installed "$program_id"; then
            info "$label ist bereits vollständig installiert."
            installable_programs+=("$program_id")
            print_program_precheck_note "$program_id"
            continue
        fi

        if program_is_available "$program_id"; then
            info "$label kann über den vorgesehenen Installationsweg installiert werden."
            installable_programs+=("$program_id")
            print_program_precheck_note "$program_id"
        else
            warn "$label ist derzeit nicht installierbar und wird übersprungen."
            UNAVAILABLE_PROGRAM_IDS+=("$program_id")
            UNAVAILABLE_PROGRAMS+=("$label")
        fi
    done

    SELECTED_PROGRAMS=("${installable_programs[@]}")
}

collect_not_selected_programs() {
    local program_id=""
    local selected_id=""
    local unavailable_id=""
    local was_selected=0
    local was_unavailable=0

    NOT_SELECTED_PROGRAMS=()

    for program_id in "${VISIBLE_PROGRAM_IDS[@]}"; do
        was_selected=0
        was_unavailable=0

        for selected_id in "${SELECTED_PROGRAMS[@]}"; do
            if [[ "$program_id" == "$selected_id" ]]; then
                was_selected=1
                break
            fi
        done

        for unavailable_id in "${UNAVAILABLE_PROGRAM_IDS[@]}"; do
            if [[ "$program_id" == "$unavailable_id" ]]; then
                was_unavailable=1
                break
            fi
        done

        if (( was_selected == 0 && was_unavailable == 0 )); then
            NOT_SELECTED_PROGRAMS+=("${PROGRAM_LABELS[$program_id]}")
        fi
    done
}

print_named_list() {
    local heading="$1"
    shift

    (($# > 0)) || return 0

    printf '\n%s:\n' "$heading"
    printf '  - %s\n' "$@"
}

refresh_tool_overview_after_changes() {
    local result=0
    local started="$SECONDS"
    local duration=0

    if (( TOOL_OVERVIEW_REQUIRED == 0 )); then
        TOOL_OVERVIEW_STATUS="nicht erforderlich – keine Programme verändert"
        return 0
    fi

    printf '\nWerkzeugübersicht automatisch aktualisieren\n'
    printf '===========================================\n'

    if [[ ! -f "$TOOL_OVERVIEW_SCRIPT" ]]; then
        TOOL_OVERVIEW_STATUS="fehlgeschlagen/offen – Skript fehlt"
        warn "Die Werkzeugübersicht konnte nicht aktualisiert werden."
        warn "Skript nicht gefunden: $TOOL_OVERVIEW_SCRIPT"
        return 0
    fi

    if [[ ! -x "$TOOL_OVERVIEW_SCRIPT" ]]; then
        TOOL_OVERVIEW_STATUS="fehlgeschlagen/offen – Skript nicht ausführbar"
        warn "Die Werkzeugübersicht konnte nicht aktualisiert werden."
        warn "Skript ist nicht ausführbar: $TOOL_OVERVIEW_SCRIPT"
        return 0
    fi

    TOOL_OVERVIEW_LOG="$(
        mktemp "$LOG_DIR/tool-overview-$(date -u +'%Y%m%dT%H%M%SZ').XXXXXXXX.log"
    )"

    info "Mindestens ein Programm wurde installiert oder aktualisiert."
    info "Die Werkzeugübersicht wird jetzt einmal aktualisiert."

    set +e
    "$TOOL_OVERVIEW_SCRIPT" 2>&1 |
        tee -a "$TOOL_OVERVIEW_LOG"
    result="${PIPESTATUS[0]}"
    set -e

    duration=$((SECONDS - started))

    if (( result == 0 )); then
        TOOL_OVERVIEW_STATUS="erfolgreich"
        info "Die Werkzeugübersicht wurde erfolgreich aktualisiert."
    else
        TOOL_OVERVIEW_STATUS="fehlgeschlagen/offen – Exit-Code $result"
        warn "Die Werkzeugübersicht konnte nicht vollständig aktualisiert werden."
        warn "Die erfolgreichen Programminstallationen bleiben trotzdem gültig."
        warn "Protokoll: $TOOL_OVERVIEW_LOG"
    fi

    printf '[INFO] Dauer der Werkzeugübersicht: %s Minute(n) und %s Sekunde(n).\n'         "$((duration / 60))"         "$((duration % 60))"

    return 0
}

print_final_report() {
    printf '\nOptionale Programme – Zusammenfassung\n'
    printf '=====================================\n'
    printf 'Neu installiert:       %s\n' "${#INSTALLED_PROGRAMS[@]}"
    printf 'Bereits installiert:   %s\n' "${#ALREADY_INSTALLED_PROGRAMS[@]}"
    printf 'Nicht verfügbar:       %s\n' "${#UNAVAILABLE_PROGRAMS[@]}"
    printf 'Fehlgeschlagen/offen:  %s\n' "${#FAILED_PROGRAMS[@]}"
    printf 'Nicht ausgewählt:      %s\n' "${#NOT_SELECTED_PROGRAMS[@]}"
    printf 'Werkzeugübersicht:     %s\n' "$TOOL_OVERVIEW_STATUS"

    if [[ -n "$TOOL_OVERVIEW_LOG" ]]; then
        printf 'Übersichtsprotokoll:   %s\n' "$TOOL_OVERVIEW_LOG"
    fi

    print_named_list "Neu installiert" "${INSTALLED_PROGRAMS[@]}"
    print_named_list "Bereits installiert" "${ALREADY_INSTALLED_PROGRAMS[@]}"
    print_named_list "Derzeit nicht verfügbar und übersprungen" "${UNAVAILABLE_PROGRAMS[@]}"
    print_named_list "Fehlgeschlagen und erneut auswählbar" "${FAILED_PROGRAMS[@]}"
    print_named_list "Nicht ausgewählt" "${NOT_SELECTED_PROGRAMS[@]}"
}

program_source_text() {
    case "$1" in
        brave)
            printf 'AUR über vorhandenen Helfer'
            ;;
        vscode|arduino|burpsuite|ffuf)
            printf 'AUR – geprüfte Paketdefinition'
            ;;
        powershell|xampp)
            printf 'offizieller festgelegter Download'
            ;;
        *)
            printf 'offizielles Arch-Repository'
            ;;
    esac
}

program_version_packages() {
    case "$1" in
        brave)
            printf '%s\n' brave-bin
            ;;
        vscode)
            printf '%s\n' visual-studio-code-bin
            ;;
        arduino)
            printf '%s\n' arduino-ide-bin
            ;;
        powershell|xampp)
            return 0
            ;;
        *)
            program_packages "$1"
            ;;
    esac
}

program_version_text() {
    local program_id="$1"
    local package=""
    local package_output=""
    local version=""
    local version_entry=""
    local separator=""
    local command_path=""
    local -a packages=()
    local -a version_parts=()

    if ! program_is_installed "$program_id"; then
        printf 'nicht installiert'
        return 0
    fi

    case "$program_id" in
        powershell)
            command_path="$(command -v pwsh 2>/dev/null)" || {
                printf 'installiert – Version unbekannt'
                return 0
            }

            version="$(
                "$command_path"                     -NoLogo                     -NoProfile                     -Command "$POWERSHELL_VERSION_QUERY"                     2>/dev/null
            )" || {
                printf 'installiert – Version unbekannt'
                return 0
            }

            version="${version//$'\r'/}"
            version="${version%%$'\n'*}"
            printf '%s' "${version:-installiert – Version unbekannt}"
            return 0
            ;;

        xampp)
            printf '%s' "$XAMPP_VERSION"
            return 0
            ;;
    esac

    mapfile -t packages < <(
        program_version_packages "$program_id"
    ) || {
        printf 'installiert – Version unbekannt'
        return 0
    }

    for package in "${packages[@]}"; do
        if package_output="$(pacman -Q "$package" 2>/dev/null)"; then
            version="${package_output#* }"
            version_parts+=("$package $version")
        fi
    done

    if ((${#version_parts[@]} == 0)); then
        printf 'installiert – Version unbekannt'
        return 0
    fi

    if ((${#version_parts[@]} == 1)); then
        printf '%s' "${version_parts[0]#* }"
        return 0
    fi

    for version_entry in "${version_parts[@]}"; do
        printf '%s%s' "$separator" "$version_entry"
        separator=", "
    done
}

show_versions() {
    local program_id=""

    printf 'Optionale Programme – Versionen\n'
    printf '================================\n\n'
    printf '%-34s %-48s %s\n'         "Programm"         "Installierte Version"         "Installationsquelle"
    printf '%-34s %-48s %s\n'         "----------------------------------"         "------------------------------------------------"         "------------------------------"

    for program_id in "${PROGRAM_IDS[@]}"; do
        printf '%-34s %-48s %s\n'             "${PROGRAM_LABELS[$program_id]}"             "$(program_version_text "$program_id")"             "$(program_source_text "$program_id")"
    done
}

program_update_policy() {
    case "$1" in
        brave)
            printf 'aur-helper'
            ;;
        powershell|xampp|vscode|arduino|burpsuite|ffuf)
            printf 'script-release'
            ;;
        *)
            printf 'system'
            ;;
    esac
}

program_id_for_package() {
    local searched_package="$1"
    local program_id=""
    local package=""
    local -a packages=()

    for program_id in "${PROGRAM_IDS[@]}"; do
        packages=()

        mapfile -t packages < <(
            program_version_packages "$program_id"
        ) || continue

        for package in "${packages[@]}"; do
            if [[ "$package" == "$searched_package" ]]; then
                printf '%s\n' "$program_id"
                return 0
            fi
        done
    done

    return 1
}

collect_official_update_preview() {
    local temporary_directory=""
    local output_file=""
    local error_file=""
    local result=0
    local line=""
    local package_name=""
    local program_id=""
    local error_output=""

    OFFICIAL_UPDATE_LINES=()
    MANAGED_SYSTEM_UPDATE_LINES=()
    OTHER_SYSTEM_UPDATE_LINES=()
    OFFICIAL_UPDATE_STATUS="nicht geprüft"

    if ! command -v checkupdates >/dev/null 2>&1; then
        OFFICIAL_UPDATE_STATUS="nicht verfügbar"
        UPDATE_PREVIEW_WARNINGS+=(
            "checkupdates fehlt; offizielle Updates konnten nicht geprüft werden."
        )
        return 0
    fi

    if ! command -v timeout >/dev/null 2>&1; then
        OFFICIAL_UPDATE_STATUS="nicht verfügbar"
        UPDATE_PREVIEW_WARNINGS+=(
            "timeout fehlt; offizielle Updates wurden aus Sicherheitsgründen nicht geprüft."
        )
        return 0
    fi

    temporary_directory="$(
        mktemp -d "$STATE_DIR/update-preview-official.XXXXXXXX"
    )"
    output_file="$temporary_directory/updates.log"
    error_file="$temporary_directory/errors.log"

    set +e
    timeout 90s         checkupdates         --nocolor         >"$output_file"         2>"$error_file"
    result=$?
    set -e

    case "$result" in
        0)
            while IFS= read -r line; do
                [[ -n "$line" ]] || continue

                OFFICIAL_UPDATE_LINES+=("$line")
                package_name="${line%% *}"
                program_id="$(
                    program_id_for_package "$package_name" ||
                        true
                )"

                if [[ -n "$program_id" ]] &&
                   [[ "$(program_update_policy "$program_id")" == "system" ]]; then
                    MANAGED_SYSTEM_UPDATE_LINES+=(
                        "${PROGRAM_LABELS[$program_id]} – $line"
                    )
                else
                    OTHER_SYSTEM_UPDATE_LINES+=("$line")
                fi
            done <"$output_file"

            if ((${#OFFICIAL_UPDATE_LINES[@]} > 0)); then
                OFFICIAL_UPDATE_STATUS="erfolgreich"
            else
                OFFICIAL_UPDATE_STATUS="keine Updates"
            fi
            ;;

        2)
            OFFICIAL_UPDATE_STATUS="keine Updates"
            ;;

        124)
            OFFICIAL_UPDATE_STATUS="Zeitlimit erreicht"
            UPDATE_PREVIEW_WARNINGS+=(
                "Die Prüfung offizieller Updates erreichte nach 90 Sekunden das Zeitlimit."
            )
            ;;

        *)
            OFFICIAL_UPDATE_STATUS="fehlgeschlagen – Exit-Code $result"
            error_output="$(head -n 1 "$error_file" 2>/dev/null || true)"
            UPDATE_PREVIEW_WARNINGS+=(
                "Offizielle Updateprüfung fehlgeschlagen – Exit-Code $result${error_output:+: $error_output}"
            )
            ;;
    esac

    rm -rf -- "$temporary_directory"
    return 0
}

collect_aur_update_preview() {
    local temporary_directory=""
    local output_file=""
    local error_file=""
    local result=0
    local line=""
    local package_name=""
    local program_id=""
    local policy=""
    local error_output=""

    AUR_UPDATE_LINES=()
    MANAGED_AUR_UPDATE_LINES=()
    PINNED_AUR_UPDATE_LINES=()
    OTHER_AUR_UPDATE_LINES=()
    AUR_UPDATE_STATUS="nicht geprüft"
    UPDATE_AUR_HELPER=""

    if command -v yay >/dev/null 2>&1; then
        UPDATE_AUR_HELPER="$(command -v yay)"
    else
        AUR_UPDATE_STATUS="nicht verfügbar"
        UPDATE_PREVIEW_WARNINGS+=(
            "Yay fehlt; AUR-Updates konnten nicht geprüft werden."
        )
        return 0
    fi

    if ! command -v timeout >/dev/null 2>&1; then
        AUR_UPDATE_STATUS="nicht verfügbar"
        UPDATE_PREVIEW_WARNINGS+=(
            "timeout fehlt; AUR-Updates wurden aus Sicherheitsgründen nicht geprüft."
        )
        return 0
    fi

    temporary_directory="$(
        mktemp -d "$STATE_DIR/update-preview-aur.XXXXXXXX"
    )"
    output_file="$temporary_directory/updates.log"
    error_file="$temporary_directory/errors.log"

    set +e
    timeout 90s         "$UPDATE_AUR_HELPER"         -Qua         --aur         --color never         >"$output_file"         2>"$error_file"
    result=$?
    set -e

    if (( result == 0 )); then
        while IFS= read -r line; do
            [[ -n "$line" ]] || continue

            AUR_UPDATE_LINES+=("$line")
            package_name="${line%% *}"
            program_id="$(
                program_id_for_package "$package_name" ||
                    true
            )"

            if [[ -z "$program_id" ]]; then
                OTHER_AUR_UPDATE_LINES+=("$line")
                continue
            fi

            policy="$(program_update_policy "$program_id")"

            case "$policy" in
                aur-helper)
                    MANAGED_AUR_UPDATE_LINES+=(
                        "${PROGRAM_LABELS[$program_id]} – $line"
                    )
                    ;;
                script-release)
                    PINNED_AUR_UPDATE_LINES+=(
                        "${PROGRAM_LABELS[$program_id]} – $line"
                    )
                    ;;
                *)
                    OTHER_AUR_UPDATE_LINES+=("$line")
                    ;;
            esac
        done <"$output_file"

        if ((${#AUR_UPDATE_LINES[@]} > 0)); then
            AUR_UPDATE_STATUS="erfolgreich"
        else
            AUR_UPDATE_STATUS="keine Updates"
        fi
    elif (( result == 124 )); then
        AUR_UPDATE_STATUS="Zeitlimit erreicht"
        UPDATE_PREVIEW_WARNINGS+=(
            "Die AUR-Updateprüfung erreichte nach 90 Sekunden das Zeitlimit."
        )
    else
        AUR_UPDATE_STATUS="fehlgeschlagen – Exit-Code $result"
        error_output="$(head -n 1 "$error_file" 2>/dev/null || true)"
        UPDATE_PREVIEW_WARNINGS+=(
            "AUR-Updateprüfung fehlgeschlagen – Exit-Code $result${error_output:+: $error_output}"
        )
    fi

    rm -rf -- "$temporary_directory"
    return 0
}

collect_pinned_update_programs() {
    local program_id=""

    PINNED_UPDATE_PROGRAMS=()

    for program_id in         powershell         xampp         vscode         arduino         burpsuite         ffuf
    do
        if program_is_installed "$program_id"; then
            PINNED_UPDATE_PROGRAMS+=(
                "${PROGRAM_LABELS[$program_id]} – $(program_version_text "$program_id") – Update erst nach neuer geprüfter Skriptfreigabe"
            )
        fi
    done
}

show_update_preview() {
    UPDATE_PREVIEW_WARNINGS=()

    printf 'Optionale Programme – Updatevorschau\n'
    printf '=====================================\n\n'

    info "Prüfe offizielle Arch-Updates mit getrennter checkupdates-Datenbank."
    collect_official_update_preview

    info "Prüfe AUR-Updates ausschließlich über Yay im Abfragemodus."
    collect_aur_update_preview

    collect_pinned_update_programs

    printf '\nUpdatevorschau – Zusammenfassung\n'
    printf '================================\n'
    printf 'Offizielle Prüfung:                 %s\n' "$OFFICIAL_UPDATE_STATUS"
    printf 'Offizielle Paketupdates gesamt:     %s\n' "${#OFFICIAL_UPDATE_LINES[@]}"
    printf 'Davon verwaltete Programme:         %s\n' "${#MANAGED_SYSTEM_UPDATE_LINES[@]}"
    printf 'Andere offizielle Systempakete:     %s\n' "${#OTHER_SYSTEM_UPDATE_LINES[@]}"
    printf 'AUR-Prüfung:                        %s\n' "$AUR_UPDATE_STATUS"
    printf 'AUR-Paketupdates gesamt:            %s\n' "${#AUR_UPDATE_LINES[@]}"
    printf 'Sicher einzeln verwaltbare Updates: %s\n' "${#MANAGED_AUR_UPDATE_LINES[@]}"
    printf 'Durch Skriptfreigabe geschützte:    %s\n' "${#PINNED_AUR_UPDATE_LINES[@]}"
    printf 'Andere AUR-Pakete:                  %s\n' "${#OTHER_AUR_UPDATE_LINES[@]}"
    printf 'Installierte festgelegte Programme: %s\n' "${#PINNED_UPDATE_PROGRAMS[@]}"

    print_named_list         "Verwaltete Programme im vollständigen Systemupdate"         "${MANAGED_SYSTEM_UPDATE_LINES[@]}"

    print_named_list         "Sicher einzeln aktualisierbare verwaltete AUR-Programme"         "${MANAGED_AUR_UPDATE_LINES[@]}"

    print_named_list         "Erkannte AUR-Updates mit neuer Skriptfreigabe als Voraussetzung"         "${PINNED_AUR_UPDATE_LINES[@]}"

    print_named_list         "Installierte Programme mit festgelegtem geprüftem Stand"         "${PINNED_UPDATE_PROGRAMS[@]}"

    print_named_list         "Weitere offizielle Pakete im vollständigen Systemupdate"         "${OTHER_SYSTEM_UPDATE_LINES[@]}"

    print_named_list         "Weitere nicht vom Programmkatalog verwaltete AUR-Updates"         "${OTHER_AUR_UPDATE_LINES[@]}"

    print_named_list         "Warnungen und offene Prüfungen"         "${UPDATE_PREVIEW_WARNINGS[@]}"

    printf '\n'
    info "Diese Vorschau hat keine Updates installiert."
    info "Offizielle Pakete werden später ausschließlich gemeinsam aktualisiert."
    info "Festgelegte Downloads und geprüfte AUR-Stände werden nicht ungeprüft ersetzt."
}

append_update_candidate() {
    local program_id="$1"
    local existing_id=""

    for existing_id in "${AVAILABLE_UPDATE_PROGRAM_IDS[@]}"; do
        [[ "$existing_id" != "$program_id" ]] || return 0
    done

    AVAILABLE_UPDATE_PROGRAM_IDS+=("$program_id")
}

prepare_managed_update_candidates() {
    local line=""
    local package_name=""
    local program_id=""
    local policy=""

    AVAILABLE_UPDATE_PROGRAM_IDS=()
    SELECTED_UPDATE_PROGRAM_IDS=()

    for line in "${OFFICIAL_UPDATE_LINES[@]}"; do
        package_name="${line%% *}"
        program_id="$(
            program_id_for_package "$package_name" ||
                true
        )"

        [[ -n "$program_id" ]] || continue
        policy="$(program_update_policy "$program_id")"

        if [[ "$policy" == "system" ]]; then
            append_update_candidate "$program_id"
        fi
    done

    for line in "${AUR_UPDATE_LINES[@]}"; do
        package_name="${line%% *}"
        program_id="$(
            program_id_for_package "$package_name" ||
                true
        )"

        [[ -n "$program_id" ]] || continue
        policy="$(program_update_policy "$program_id")"

        if [[ "$policy" == "aur-helper" ]]; then
            append_update_candidate "$program_id"
        fi
    done
}

is_available_update_candidate() {
    local searched_id="$1"
    local candidate_id=""

    for candidate_id in "${AVAILABLE_UPDATE_PROGRAM_IDS[@]}"; do
        [[ "$candidate_id" != "$searched_id" ]] || return 0
    done

    return 1
}

is_selected_update_program() {
    local searched_id="$1"
    local selected_id=""

    for selected_id in "${SELECTED_UPDATE_PROGRAM_IDS[@]}"; do
        [[ "$selected_id" != "$searched_id" ]] || return 0
    done

    return 1
}

program_update_method_text() {
    case "$(program_update_policy "$1")" in
        system)
            printf 'vollständiges Systemupdate'
            ;;
        aur-helper)
            printf 'einzeln über Yay'
            ;;
        script-release)
            printf 'erst nach neuer geprüfter Skriptfreigabe'
            ;;
        *)
            printf 'unbekannter Updateweg'
            ;;
    esac
}

print_pending_lines_for_program() {
    local searched_id="$1"
    local line=""
    local package_name=""
    local program_id=""

    for line in         "${OFFICIAL_UPDATE_LINES[@]}"         "${AUR_UPDATE_LINES[@]}"
    do
        [[ -n "$line" ]] || continue

        package_name="${line%% *}"
        program_id="$(
            program_id_for_package "$package_name" ||
                true
        )"

        if [[ "$program_id" == "$searched_id" ]]; then
            printf '      %s\n' "$line"
        fi
    done
}

show_managed_update_candidates() {
    local program_id=""

    printf '\nBetroffene verwaltete Programme\n'
    printf '================================\n'

    if ((${#AVAILABLE_UPDATE_PROGRAM_IDS[@]} == 0)); then
        printf '  Keine verwalteten Programme benötigen derzeit ein Update.\n'
        return 0
    fi

    for program_id in "${AVAILABLE_UPDATE_PROGRAM_IDS[@]}"; do
        printf '\n  %-18s %s\n'             "$program_id"             "${PROGRAM_LABELS[$program_id]}"
        printf '      Updateweg: %s\n'             "$(program_update_method_text "$program_id")"
        print_pending_lines_for_program "$program_id"
    done
}

select_update_scope() {
    local answer=""
    local program_id=""
    local -a requested_ids=()

    SELECTED_UPDATE_PROGRAM_IDS=()

    show_managed_update_candidates

    if ((${#AVAILABLE_UPDATE_PROGRAM_IDS[@]} == 0)); then
        return 1
    fi

    printf '\nUpdateauswahl:\n'
    printf '  1) Alle angezeigten verwalteten Programme\n'
    printf '  2) Nur bestimmte Programme\n'
    printf '  0) Abbrechen\n'

    while true; do
        read -r -p 'Auswahl [0-2]: ' answer || return 1

        case "$answer" in
            1)
                SELECTED_UPDATE_PROGRAM_IDS=(
                    "${AVAILABLE_UPDATE_PROGRAM_IDS[@]}"
                )
                return 0
                ;;

            2)
                printf '\nMehrere Programm-IDs mit Leerzeichen trennen.\n'
                read -r -p 'Programm-IDs, leer zum Abbrechen: ' answer ||
                    return 1
                [[ -n "$answer" ]] || return 1

                IFS=' ' read -r -a requested_ids <<<"$answer"

                for program_id in "${requested_ids[@]}"; do
                    if ! is_available_update_candidate "$program_id"; then
                        warn "Programm ist nicht in der aktuellen Updateauswahl: $program_id"
                        SELECTED_UPDATE_PROGRAM_IDS=()
                        return 1
                    fi

                    if ! is_selected_update_program "$program_id"; then
                        SELECTED_UPDATE_PROGRAM_IDS+=("$program_id")
                    fi
                done

                ((${#SELECTED_UPDATE_PROGRAM_IDS[@]} > 0)) || return 1
                return 0
                ;;

            0|"")
                return 1
                ;;

            *)
                printf 'Bitte 0, 1 oder 2 eingeben.\n'
                ;;
        esac
    done
}

confirm_update_selection() {
    local answer=""
    local program_id=""

    printf '\nAusgewählte Programmupdates\n'
    printf '============================\n'

    for program_id in "${SELECTED_UPDATE_PROGRAM_IDS[@]}"; do
        printf '\n  - %s\n' "${PROGRAM_LABELS[$program_id]}"
        printf '    Updateweg: %s\n'             "$(program_update_method_text "$program_id")"
        print_pending_lines_for_program "$program_id"

        if [[ "$(program_update_policy "$program_id")" == "system" ]]; then
            printf '      Hinweis: Das vollständige Systemupdate aktualisiert zusätzlich alle anderen offiziellen Pakete.\n'
        fi
    done

    printf '\n'

    while true; do
        read -r -p             'Diese Programmupdate-Auswahl weiter bearbeiten? [y/N]: '             answer ||
            answer=""

        case "${answer,,}" in
            y|yes)
                return 0
                ;;
            ""|n|no)
                return 1
                ;;
            *)
                printf 'Bitte y/yes oder n/no eingeben.\n'
                ;;
        esac
    done
}

run_program_update_action() {
    local program_id="$1"
    local yay_command=""

    case "$program_id" in
        brave)
            yay_command="$(command -v yay 2>/dev/null)" || {
                warn "Yay wurde für das Brave-Update nicht gefunden."
                return 127
            }

            "$yay_command"                 --sync                 --aur                 --needed                 brave-bin
            ;;

        *)
            warn "Kein sicherer einzelner Updateweg für ${PROGRAM_LABELS[$program_id]} vorhanden."
            return 2
            ;;
    esac
}

run_selected_aur_update() {
    local program_id="$1"
    local label="${PROGRAM_LABELS[$program_id]}"
    local version_before=""
    local version_after=""
    local result=0
    local started="$SECONDS"
    local duration=0
    local log_file=""

    version_before="$(program_version_text "$program_id")"

    log_file="$(
        mktemp "$LOG_DIR/update-${program_id}-$(date -u +'%Y%m%dT%H%M%SZ').XXXXXXXX.log"
    )"

    printf '\nProgrammupdate: %s\n' "$label"
    printf '===============================\n'
    info "Installierte Version: $version_before"
    info "Updateweg: $(program_update_method_text "$program_id")"

    set +e
    run_program_action         run_program_update_action         "$program_id"         2>&1 |
        tee -a "$log_file"
    result="${PIPESTATUS[0]}"
    set -e

    duration=$((SECONDS - started))
    version_after="$(program_version_text "$program_id")"
    PROGRAM_UPDATE_LOGS+=("$label – $log_file")

    if (( result == 0 )); then
        if [[ "$version_after" != "$version_before" ]]; then
            UPDATED_PROGRAMS+=(
                "$label – $version_before → $version_after"
            )
            TOOL_OVERVIEW_REQUIRED=1
            info "$label wurde erfolgreich aktualisiert."
        else
            ALREADY_CURRENT_UPDATE_PROGRAMS+=(
                "$label – $version_after"
            )
            info "$label ist bereits auf dem aktuellen verfügbaren Stand."
        fi
    else
        FAILED_UPDATE_PROGRAMS+=(
            "$label – Exit-Code $result – $log_file"
        )
        warn "$label wurde abgebrochen oder konnte nicht aktualisiert werden."
        warn "Der Ablauf fährt mit dem nächsten Programm fort."
        warn "Protokoll: $log_file"
    fi

    printf '[INFO] Updatedauer für %s: %s Minute(n) und %s Sekunde(n).\n'         "$label"         "$((duration / 60))"         "$((duration % 60))"

    return 0
}

selected_updates_include_policy() {
    local searched_policy="$1"
    local program_id=""

    for program_id in "${SELECTED_UPDATE_PROGRAM_IDS[@]}"; do
        if [[ "$(program_update_policy "$program_id")" == "$searched_policy" ]]; then
            return 0
        fi
    done

    return 1
}

capture_selected_system_versions() {
    local program_id=""

    for program_id in "${SELECTED_UPDATE_PROGRAM_IDS[@]}"; do
        [[ "$(program_update_policy "$program_id")" == "system" ]] ||
            continue

        printf '%s|%s\n'             "$program_id"             "$(program_version_text "$program_id")"
    done
}

record_selected_system_results() {
    local captured_versions="$1"
    local program_id=""
    local version_before=""
    local version_after=""

    while IFS='|' read -r program_id version_before; do
        [[ -n "$program_id" ]] || continue

        version_after="$(program_version_text "$program_id")"

        if [[ "$version_after" != "$version_before" ]]; then
            UPDATED_PROGRAMS+=(
                "${PROGRAM_LABELS[$program_id]} – $version_before → $version_after"
            )
            TOOL_OVERVIEW_REQUIRED=1
            continue
        fi

        case "$SYSTEM_UPDATE_STATUS" in
            "nicht erforderlich – System ist aktuell")
                ALREADY_CURRENT_UPDATE_PROGRAMS+=(
                    "${PROGRAM_LABELS[$program_id]} – $version_after"
                )
                ;;
            *)
                DEFERRED_UPDATE_PROGRAMS+=(
                    "${PROGRAM_LABELS[$program_id]} – Systemupdate: $SYSTEM_UPDATE_STATUS"
                )
                ;;
        esac
    done <<<"$captured_versions"
}

defer_selected_aur_updates() {
    local reason="$1"
    local program_id=""

    for program_id in "${SELECTED_UPDATE_PROGRAM_IDS[@]}"; do
        [[ "$(program_update_policy "$program_id")" == "aur-helper" ]] ||
            continue

        DEFERRED_UPDATE_PROGRAMS+=(
            "${PROGRAM_LABELS[$program_id]} – $reason"
        )
    done
}

process_selected_program_updates() {
    local program_id=""
    local captured_system_versions=""
    local system_step_needed=0
    local selected_aur_present=0

    if selected_updates_include_policy system; then
        system_step_needed=1
    fi

    if selected_updates_include_policy aur-helper; then
        selected_aur_present=1

        if ((${#OFFICIAL_UPDATE_LINES[@]} > 0)); then
            system_step_needed=1
        fi
    fi

    if (( system_step_needed != 0 )); then
        captured_system_versions="$(capture_selected_system_versions)"
        offer_full_system_update
        record_selected_system_results "$captured_system_versions"
    fi

    if (( selected_aur_present == 0 )); then
        return 0
    fi

    if ((${#OFFICIAL_UPDATE_LINES[@]} > 0)) &&
       [[ "$SYSTEM_UPDATE_STATUS" != "erfolgreich" ]] &&
       [[ "$SYSTEM_UPDATE_STATUS" !=           "nicht erforderlich – System ist aktuell" ]]; then
        warn "Die notwendigen offiziellen Systemupdates wurden nicht abgeschlossen."
        warn "AUR-Updates werden deshalb aus Sicherheitsgründen zurückgestellt."
        defer_selected_aur_updates             "zurückgestellt – vollständiges Systemupdate nicht abgeschlossen"
        return 0
    fi

    for program_id in "${SELECTED_UPDATE_PROGRAM_IDS[@]}"; do
        [[ "$(program_update_policy "$program_id")" == "aur-helper" ]] ||
            continue

        run_selected_aur_update "$program_id"
    done

    return 0
}

print_program_update_report() {
    printf '\nProgrammupdates – Zusammenfassung\n'
    printf '==================================\n'
    printf 'Erfolgreich aktualisiert: %s\n' "${#UPDATED_PROGRAMS[@]}"
    printf 'Bereits aktuell:          %s\n' "${#ALREADY_CURRENT_UPDATE_PROGRAMS[@]}"
    printf 'Zurückgestellt:           %s\n' "${#DEFERRED_UPDATE_PROGRAMS[@]}"
    printf 'Fehlgeschlagen/offen:     %s\n' "${#FAILED_UPDATE_PROGRAMS[@]}"
    printf 'Systemupdate:             %s\n' "$SYSTEM_UPDATE_STATUS"
    printf 'Werkzeugübersicht:        %s\n' "$TOOL_OVERVIEW_STATUS"

    print_named_list         "Erfolgreich aktualisiert"         "${UPDATED_PROGRAMS[@]}"

    print_named_list         "Bereits auf aktuellem Stand"         "${ALREADY_CURRENT_UPDATE_PROGRAMS[@]}"

    print_named_list         "Zurückgestellt und später erneut auswählbar"         "${DEFERRED_UPDATE_PROGRAMS[@]}"

    print_named_list         "Fehlgeschlagen und später erneut auswählbar"         "${FAILED_UPDATE_PROGRAMS[@]}"

    print_named_list         "Programmupdate-Protokolle"         "${PROGRAM_UPDATE_LOGS[@]}"

    if (( SYSTEM_RESTART_RECOMMENDED != 0 )); then
        printf '\n[WARNUNG] Ein späterer manueller Neustart wird empfohlen.\n'
        printf '[WARNUNG] Das Skript startet den Rechner nicht automatisch neu.\n'
    fi
}

run_program_update_mode() {
    local started="$SECONDS"
    local duration=0

    UPDATED_PROGRAMS=()
    ALREADY_CURRENT_UPDATE_PROGRAMS=()
    FAILED_UPDATE_PROGRAMS=()
    DEFERRED_UPDATE_PROGRAMS=()
    PROGRAM_UPDATE_LOGS=()
    TOOL_OVERVIEW_REQUIRED=0
    TOOL_OVERVIEW_STATUS="nicht erforderlich"

    show_update_preview
    prepare_managed_update_candidates

    if ((${#AVAILABLE_UPDATE_PROGRAM_IDS[@]} == 0)); then
        printf '\n'
        info "Für die verwalteten Programme sind derzeit keine direkt bearbeitbaren Updates vorhanden."
        info "Weitere System- und AUR-Updates wurden in der Vorschau angezeigt."
        return 0
    fi

    if ! select_update_scope; then
        info "Die Programmupdate-Auswahl wurde abgebrochen."
        return 0
    fi

    if ! confirm_update_selection; then
        info "Die geprüfte Programmupdate-Auswahl wurde nicht bestätigt."
        return 0
    fi

    process_selected_program_updates
    refresh_tool_overview_after_changes

    duration=$((SECONDS - started))
    print_program_update_report

    printf '\n[INFO] Gesamtdauer der Programmupdates: %s Minute(n) und %s Sekunde(n).\n'         "$((duration / 60))"         "$((duration % 60))"

    return 0
}

confirm_full_system_update() {
    local answer=""

    while true; do
        read -r -p             'Vollständiges Systemupdate jetzt durchführen? [y/N]: '             answer ||
            answer=""

        case "${answer,,}" in
            y|yes)
                return 0
                ;;
            ""|n|no)
                return 1
                ;;
            *)
                printf 'Bitte y/yes oder n/no eingeben.\n'
                ;;
        esac
    done
}

run_full_system_update_action() {
    sudo pacman         --sync         --refresh         --sysupgrade
}

detect_restart_recommendation() {
    local line=""
    local package_name=""

    SYSTEM_RESTART_RECOMMENDED=0

    for line in "${OFFICIAL_UPDATE_LINES[@]}"; do
        package_name="${line%% *}"

        case "$package_name" in
            linux|linux-lts|linux-zen|linux-hardened|systemd|glibc)
                SYSTEM_RESTART_RECOMMENDED=1
                return 0
                ;;
        esac
    done
}

offer_full_system_update() {
    local result=0
    local started="$SECONDS"

    SYSTEM_UPDATE_STATUS="nicht angeboten"
    SYSTEM_UPDATE_LOG=""
    SYSTEM_UPDATE_DURATION=0
    SYSTEM_RESTART_RECOMMENDED=0
    UPDATE_PREVIEW_WARNINGS=()

    printf '\nVollständiges Systemupdate prüfen\n'
    printf '=================================\n'

    collect_official_update_preview

    case "$OFFICIAL_UPDATE_STATUS" in
        erfolgreich)
            ;;
        "keine Updates")
            SYSTEM_UPDATE_STATUS="nicht erforderlich – System ist aktuell"
            info "Für die offiziellen Arch-Pakete sind keine Updates verfügbar."
            return 0
            ;;
        *)
            SYSTEM_UPDATE_STATUS="nicht angeboten – Updatevorschau fehlgeschlagen"
            warn "Das Systemupdate wird ohne zuverlässige Vorschau nicht angeboten."
            print_named_list                 "Warnungen der Updatevorschau"                 "${UPDATE_PREVIEW_WARNINGS[@]}"
            return 0
            ;;
    esac

    if ((${#OFFICIAL_UPDATE_LINES[@]} == 0)); then
        SYSTEM_UPDATE_STATUS="nicht erforderlich – System ist aktuell"
        info "Für die offiziellen Arch-Pakete sind keine Updates verfügbar."
        return 0
    fi

    printf '\nBetroffene Pakete des vollständigen Systemupdates: %s\n'         "${#OFFICIAL_UPDATE_LINES[@]}"
    printf '%s\n'         '---------------------------------------------------'
    printf '  - %s\n' "${OFFICIAL_UPDATE_LINES[@]}"

    printf '\n'
    info "Bei Zustimmung werden alle oben aufgeführten offiziellen Pakete gemeinsam aktualisiert."
    info "Pacman zeigt die endgültige Transaktion und fragt nochmals nach Bestätigung."
    info "SSH, NetworkManager und Firewall werden vom Custom-Linux-Skript nicht neu gestartet."
    info "Ein Neustart des Rechners wird niemals automatisch durchgeführt."

    if ! confirm_full_system_update; then
        SYSTEM_UPDATE_STATUS="übersprungen"
        info "Das vollständige Systemupdate wurde übersprungen."
        return 0
    fi

    SYSTEM_UPDATE_LOG="$(
        mktemp "$LOG_DIR/system-update-$(date -u +'%Y%m%dT%H%M%SZ').XXXXXXXX.log"
    )"

    printf '\nVollständiges Systemupdate ausführen\n'
    printf '====================================\n'
    info "Starte das vollständige Pacman-Systemupdate."
    info "Die aktive SSH-Sitzung wird vom Skript nicht beendet."

    set +e
    run_full_system_update_action 2>&1 |
        tee -a "$SYSTEM_UPDATE_LOG"
    result="${PIPESTATUS[0]}"
    set -e

    SYSTEM_UPDATE_DURATION=$((SECONDS - started))

    if (( result == 0 )); then
        SYSTEM_UPDATE_STATUS="erfolgreich"
        detect_restart_recommendation
        info "Das vollständige Systemupdate wurde erfolgreich abgeschlossen."
    else
        SYSTEM_UPDATE_STATUS="abgebrochen oder fehlgeschlagen – Exit-Code $result"
        warn "Das Systemupdate wurde nicht vollständig abgeschlossen."
        warn "Der Programminstallationsablauf bleibt trotzdem abgeschlossen."
        warn "Protokoll: $SYSTEM_UPDATE_LOG"
    fi

    printf '[INFO] Dauer des Systemupdates: %s Minute(n) und %s Sekunde(n).\n'         "$((SYSTEM_UPDATE_DURATION / 60))"         "$((SYSTEM_UPDATE_DURATION % 60))"

    if (( SYSTEM_RESTART_RECOMMENDED != 0 )); then
        warn "Mindestens ein Kernel- oder zentrales Systempaket wurde aktualisiert."
        warn "Ein späterer manueller Neustart wird empfohlen."
        warn "Der Rechner wird nicht automatisch neu gestartet."
    fi

    return 0
}

print_combined_completion_report() {
    printf '\nGesamtablauf – Abschluss\n'
    printf '=========================\n'
    printf 'Neu installierte Programme: %s\n' "${#INSTALLED_PROGRAMS[@]}"
    printf 'Offene Programmfehler:       %s\n' "${#FAILED_PROGRAMS[@]}"
    printf 'Werkzeugübersicht:           %s\n' "$TOOL_OVERVIEW_STATUS"
    printf 'Vollständiges Systemupdate:  %s\n' "$SYSTEM_UPDATE_STATUS"

    if [[ -n "$SYSTEM_UPDATE_LOG" ]]; then
        printf 'Systemupdate-Protokoll:       %s\n' "$SYSTEM_UPDATE_LOG"
    fi

    if (( SYSTEM_UPDATE_DURATION > 0 )); then
        printf 'Systemupdate-Dauer:           %s Minute(n) und %s Sekunde(n)\n'             "$((SYSTEM_UPDATE_DURATION / 60))"             "$((SYSTEM_UPDATE_DURATION % 60))"
    fi

    print_named_list         "Weiterhin fehlgeschlagene oder offene Programme"         "${FAILED_PROGRAMS[@]}"

    if (( SYSTEM_RESTART_RECOMMENDED != 0 )); then
        printf '\n[WARNUNG] Ein späterer manueller Neustart wird empfohlen.\n'
        printf '[WARNUNG] Es wurde kein automatischer Neustart ausgeführt.\n'
    fi
}

show_status() {
    local program_id=""

    printf 'Optionale Programme – Status\n'
    printf '============================\n\n'

    for program_id in "${PROGRAM_IDS[@]}"; do
        printf '%-30s %s\n' \
            "${PROGRAM_LABELS[$program_id]}" \
            "$(program_status_text "$program_id")"
    done
}

check_environment() {
    (( EUID != 0 )) || fail "Dieses Skript als normaler Benutzer und nicht mit sudo starten."
    command -v pacman >/dev/null 2>&1 || fail "pacman wurde nicht gefunden."
    command -v sudo >/dev/null 2>&1 || fail "sudo wurde nicht gefunden."

    if [[ ! -f "$HOME/.local/state/custom-linux/postinstall-setup.ok" ]]; then
        warn "Das Grundsystem-Setup ist noch nicht vollständig abgeschlossen."
        warn "Die Programmauswahl bleibt trotzdem verfügbar."
        warn "Programme mit fehlenden Voraussetzungen können fehlschlagen und später erneut ausgewählt werden."
    fi
}

test_error_catalog() (
    local temporary_directory=""
    local program_id=""
    local result=""
    local test_message=""
    local log_file=""
    local source_id=""
    local source_label=""
    local phase=""
    local meaning=""
    local recommendation=""
    local test_case=""
    local -a test_cases=(
        'obsidian|1|error: target not found: obsidian'
        'powershell|6|curl: (6) Could not resolve host: github.com'
        'vscode|128|fatal: unable to access repository: Connection timed out'
        'arduino|1|==> ERROR: A failure occurred in build().'
        'xampp|1|Die SHA-256-Prüfsumme des XAMPP-Installers stimmt nicht.'
        'obsidian|97|[TESTSPERRE] sudo wurde blockiert: pacman --sync obsidian'
        'discord|127|Benötigter Befehl wurde nicht gefunden.'
        'docker|137|Der Prozess wurde beendet.'
    )

    temporary_directory="$(
        mktemp -d -t custom-linux-error-catalog.XXXXXXXX
    )"

    trap 'rm -rf -- "$temporary_directory"' EXIT

    printf 'Fehlercode-Katalog – sicherer Test\n'
    printf '=================================\n'

    for test_case in "${test_cases[@]}"; do
        IFS='|' read -r \
            program_id \
            result \
            test_message \
            <<<"$test_case"

        log_file="$temporary_directory/$program_id-$result.log"
        printf '%s\n' "$test_message" >"$log_file"

        source_id="$(
            detect_failure_source \
                "$program_id" \
                "$result" \
                "$log_file" \
                0
        )"
        source_label="$(failure_source_label "$source_id")"
        phase="$(failure_phase_text "$source_id")"
        meaning="$(failure_meaning "$source_id" "$result" "$log_file")"
        recommendation="$(
            failure_recommendation \
                "$source_id" \
                "$result" \
                "$log_file"
        )"

        printf '\nProgramm:   %s\n' "${PROGRAM_LABELS[$program_id]}"
        printf 'Exit-Code:  %s\n' "$result"
        printf 'Quelle:     %s\n' "$source_label"
        printf 'Phase:      %s\n' "$phase"
        printf 'Bedeutung:  %s\n' "$meaning"
        printf 'Abhilfe:    %s\n' "$recommendation"
    done

    printf '\n'
    info "Der Fehlerkatalog-Test ist abgeschlossen."
    info "Es wurden keine Programme und keine Statusdateien verändert."
)

main() {
    local program_id=""
    local stop_requested=0

    if [[ "${1:-}" == "--status" ]]; then
        show_status
        return 0
    fi

    if [[ "${1:-}" == "--versions" ]]; then
        show_versions
        return 0
    fi

    if [[ "${1:-}" == "--update-preview" ]]; then
        check_environment
        mkdir -p "$STATE_DIR" "$LOG_DIR"
        show_update_preview
        return 0
    fi

    if [[ "${1:-}" == "--updates" ]]; then
        check_environment
        mkdir -p "$STATE_DIR" "$LOG_DIR"
        run_program_update_mode
        return 0
    fi

    if [[ "${1:-}" == "--test-error-catalog" ]]; then
        test_error_catalog
        return 0
    fi

    if [[ "${1:-}" == "--test-countdown" ]]; then
        printf 'Visueller Timer-Test\n'
        printf '====================\n'

        if confirm_continue_without_program "Testprogramm"; then
            info "Testergebnis: ohne Testprogramm fortfahren."
        else
            info "Testergebnis: Ablauf anhalten."
        fi

        return 0
    fi

    check_environment
    mkdir -p "$STATE_DIR" "$LOG_DIR"

    printf 'Custom-Linux – optionale Programme\n'
    printf '==================================\n'

    if ! select_programs; then
        info "Die Auswahl wurde abgebrochen. Es wird nichts installiert."
        return 0
    fi

    if ((${#SELECTED_PROGRAMS[@]} == 0)); then
        info "Es wurde kein Programm ausgewählt. Es wird nichts installiert."
        return 0
    fi

    precheck_selected_programs
    collect_not_selected_programs

    if ((${#SELECTED_PROGRAMS[@]} == 0)); then
        warn "Keines der ausgewählten Programme ist derzeit installierbar."
        warn "Es wird nichts installiert."
        print_final_report
        return 0
    fi

    if ! confirm_selection; then
        info "Die geprüfte Auswahl wurde nicht bestätigt. Es wird nichts installiert."
        return 0
    fi

    for program_id in "${SELECTED_PROGRAMS[@]}"; do
        if ! run_selected_program "$program_id"; then
            warn "Der Ablauf wurde auf Wunsch nach '${PROGRAM_LABELS[$program_id]}' angehalten."
            stop_requested=1
            break
        fi
    done

    refresh_tool_overview_after_changes
    print_final_report

    if (( stop_requested != 0 )); then
        return 1
    fi

    offer_full_system_update
    print_combined_completion_report
}

main "$@"
