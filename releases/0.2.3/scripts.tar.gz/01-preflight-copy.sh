#!/usr/bin/env bash

# 01-preflight-copy.sh
#
# Aufgabe:
# - Wird NACH Archinstall, aber VOR dem Neustart ausgeführt.
# - Prüft zuerst das Live-System, die Installer-Dateien und das Zielsystem.
# - Verändert ohne --copy noch nichts.
# - Mit --copy werden die Dateien nach /opt/custom-linux-installer kopiert.
#
# Benötigte Rechte:
# - Root, weil in das neu installierte System geschrieben wird.
#
# Betroffene Bereiche:
# - Quelle: Verzeichnis der aktuell laufenden Script-Version
# - Ziel:   /mnt/archinstall/opt/custom-linux-installer
#           oder als Fallback /mnt/opt/custom-linux-installer

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_PATH="$(
    readlink -f -- "${BASH_SOURCE[0]}"
)"

SCRIPT_DIR="$(
    cd -- "$(dirname -- "$SCRIPT_PATH")"
    pwd
)"
SOURCE="$SCRIPT_DIR"
UPDATER_SOURCE="/usr/lib/custom-linux/custom-update.sh"
LAUNCHER_SOURCE="/usr/local/bin/custom-linux"
ALLOWED_SIGNERS_SOURCE="/usr/share/custom-linux/update-keys/allowed_signers"
SYSTEM_MANIFEST_SOURCE="/usr/share/custom-linux/system-manifest.json"
BUNDLED_DIR="/root/custom-linux"
CURRENT_LINK="/run/custom-linux/script-updates/current"

TEST_MODE="${CUSTOM_PREFLIGHT_TEST_MODE:-0}"
TEST_ROOT=""

ACTIVE_SCRIPT_VERSION=""
TARGET=""
DESTINATION_RELATIVE="/opt/custom-linux-installer"
MODE="check"

handle_error() {
    local rc="$1"
    local line="$2"
    local command="$3"

    printf '\n[FEHLER] Zeile %s: %s\n' "$line" "$command" >&2
    printf '[FEHLER] Abbruch mit Exit-Code %s.\n' "$rc" >&2
    exit "$rc"
}

trap 'handle_error "$?" "$LINENO" "$BASH_COMMAND"' ERR

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

usage() {
    cat <<'EOF'
Verwendung:

  01-preflight-copy.sh
      Führt nur die Prüfungen aus und verändert nichts.

  01-preflight-copy.sh --copy
      Führt alle Prüfungen aus und kopiert anschließend den Installer.

Optionen:

  --target PFAD
      Installationsziel manuell angeben.
      Beispiel: --target /mnt/archinstall

  --source PFAD
      Quellverzeichnis manuell angeben.
      Standard: Verzeichnis der aktuell laufenden Script-Version

  --copy
      Nach erfolgreicher Prüfung tatsächlich kopieren.

  --help
      Diese Hilfe anzeigen.
EOF
}

require_command() {
    local command_name="$1"

    command -v "$command_name" >/dev/null 2>&1 ||
        fail "Benötigter Befehl fehlt: $command_name"
}

path_within_test_root() {
    local candidate="$1"
    local resolved=""

    [[ "$candidate" == /* ]] || return 1

    resolved="$(realpath -m -- "$candidate")" ||
        return 1

    case "$resolved/" in
        "$TEST_ROOT/"*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}


configure_runtime_environment() {
    case "$TEST_MODE" in
        0)
            (( EUID == 0 )) ||
                fail "Dieses Skript muss im Live-System als Root ausgeführt werden."
            ;;

        1)
            (( EUID != 0 )) ||
                fail "Der interne Preflight-Testmodus darf nicht als Root ausgeführt werden."

            [[ -n "${CUSTOM_PREFLIGHT_TEST_ROOT:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_ROOT."

            TEST_ROOT="$(
                realpath -e -- "$CUSTOM_PREFLIGHT_TEST_ROOT"
            )"

            [[ -d "$TEST_ROOT" && "$TEST_ROOT" != "/" ]] ||
                fail "Ungültiges Test-Root: $TEST_ROOT"

            [[ -n "${CUSTOM_PREFLIGHT_TEST_UPDATER:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_UPDATER."

            [[ -n "${CUSTOM_PREFLIGHT_TEST_LAUNCHER:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_LAUNCHER."

            [[ -n "${CUSTOM_PREFLIGHT_TEST_ALLOWED_SIGNERS:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_ALLOWED_SIGNERS."

            [[ -n "${CUSTOM_PREFLIGHT_TEST_SYSTEM_MANIFEST:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_SYSTEM_MANIFEST."

            [[ -n "${CUSTOM_PREFLIGHT_TEST_BUNDLED_DIR:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_BUNDLED_DIR."

            [[ -n "${CUSTOM_PREFLIGHT_TEST_CURRENT_LINK:-}" ]] ||
                fail "Im Testmodus fehlt CUSTOM_PREFLIGHT_TEST_CURRENT_LINK."

            UPDATER_SOURCE="$CUSTOM_PREFLIGHT_TEST_UPDATER"
            LAUNCHER_SOURCE="$CUSTOM_PREFLIGHT_TEST_LAUNCHER"
            ALLOWED_SIGNERS_SOURCE="$CUSTOM_PREFLIGHT_TEST_ALLOWED_SIGNERS"
            SYSTEM_MANIFEST_SOURCE="$CUSTOM_PREFLIGHT_TEST_SYSTEM_MANIFEST"
            BUNDLED_DIR="$CUSTOM_PREFLIGHT_TEST_BUNDLED_DIR"
            CURRENT_LINK="$CUSTOM_PREFLIGHT_TEST_CURRENT_LINK"

            [[ -n "$TARGET" ]] ||
                fail "Im Testmodus muss --target ausdrücklich angegeben werden."

            for test_path in \
                "$SOURCE" \
                "$TARGET" \
                "$UPDATER_SOURCE" \
                "$LAUNCHER_SOURCE" \
                "$ALLOWED_SIGNERS_SOURCE" \
                "$SYSTEM_MANIFEST_SOURCE" \
                "$BUNDLED_DIR" \
                "$CURRENT_LINK"
            do
                path_within_test_root "$test_path" ||
                    fail \
"Testpfad liegt außerhalb von CUSTOM_PREFLIGHT_TEST_ROOT:
  $test_path"
            done

            info "Interner isolierter Preflight-Testmodus ist aktiv."
            info "Test-Root: $TEST_ROOT"
            ;;

        *)
            fail \
"Ungültiger Wert für CUSTOM_PREFLIGHT_TEST_MODE: $TEST_MODE
Erlaubt sind 0 oder 1."
            ;;
    esac
}

is_exact_mountpoint() {
    local path="$1"

    findmnt \
        --kernel \
        --raw \
        --noheadings \
        --first-only \
        --mountpoint "$path" \
        --output TARGET \
        >/dev/null 2>&1
}

detect_target() {
    local candidate

    if [[ -n "$TARGET" ]]; then
        [[ -d "$TARGET" ]] ||
            fail "Der angegebene Zielpfad existiert nicht: $TARGET"

        is_exact_mountpoint "$TARGET" ||
            fail "Der angegebene Zielpfad ist kein eigener Mountpunkt: $TARGET"

        return
    fi

    for candidate in /mnt/archinstall /mnt; do
        if [[ -d "$candidate" ]] && is_exact_mountpoint "$candidate"; then
            TARGET="$candidate"
            return
        fi
    done

    fail \
"Kein installiertes System gefunden.

Archinstall muss zuerst abgeschlossen sein.

Geprüfte Mountpunkte:
  /mnt/archinstall
  /mnt

Du kannst einen anderen Mountpunkt angeben:
  $0 --target /dein/pfad"
}

check_source() {
    local script
    local script_count=0

    [[ -d "$SOURCE" ]] ||
        fail "Quellverzeichnis nicht gefunden: $SOURCE"

    SOURCE="$(realpath -e -- "$SOURCE")"

    [[ -f "$SOURCE/01-preflight-copy.sh" ]] ||
        fail "01-preflight-copy.sh fehlt im Quellverzeichnis."

    [[ -f "$SOURCE/02-postinstall-test.sh" ]] ||
        fail "02-postinstall-test.sh fehlt im Quellverzeichnis."

    info "Prüfe Shellskripte auf Syntaxfehler."

    while IFS= read -r -d '' script; do
        script_count=$((script_count + 1))

        bash -n "$script" ||
            fail "Syntaxfehler in: $script"

        if LC_ALL=C grep -q $'\r' "$script"; then
            fail \
"Windows-Zeilenumbrüche gefunden in:
  $script

Die Datei muss Unix-Zeilenumbrüche verwenden."
        fi
    done < <(
        find "$SOURCE" \
            -type f \
            -name '*.sh' \
            -print0
    )

    (( script_count > 0 )) ||
        fail "Im Quellverzeichnis wurden keine Shellskripte gefunden."

    info "$script_count Shellskript(e) erfolgreich geprüft."
}

check_update_bootstrap() {
    [[ -x "$UPDATER_SOURCE" ]] ||
        fail "Bootstrap-Updater fehlt oder ist nicht ausführbar: $UPDATER_SOURCE"

    [[ -x "$LAUNCHER_SOURCE" ]] ||
        fail "Stabiler Launcher fehlt oder ist nicht ausführbar: $LAUNCHER_SOURCE"

    [[ -s "$ALLOWED_SIGNERS_SOURCE" ]] ||
        fail "allowed_signers fehlt oder ist leer: $ALLOWED_SIGNERS_SOURCE"

    if grep -q 'PRIVATE KEY' "$ALLOWED_SIGNERS_SOURCE"; then
        fail "allowed_signers enthält unerwartet private Schlüsseldaten."
    fi

    awk '
        NF >= 3 &&
        $1 == "custom-arch-release" &&
        $2 ~ /^ssh-/ {
            found = 1
        }

        END {
            exit !found
        }
    ' "$ALLOWED_SIGNERS_SOURCE" ||
        fail "allowed_signers enthält keinen gültigen Release-Verifizierer."

    info "Updater-Bootstrap und öffentlicher Verifizierschlüssel sind vorhanden."
}

validate_script_version() {
    [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9]+)*$ ]]
}

validate_relative_path() {
    local path="$1"

    [[ -n "$path" ]] || return 1
    [[ "$path" != /* ]] || return 1
    [[ "$path" != *"://"* ]] || return 1
    [[ "$path" != *"//"* ]] || return 1
    [[ "$path" != "." && "$path" != ./* &&
       "$path" != */./* && "$path" != */. ]] || return 1
    [[ "$path" != ".." ]] || return 1
    [[ "$path" != ../* ]] || return 1
    [[ "$path" != */../* ]] || return 1
    [[ "$path" != */.. ]] || return 1
    [[ "$path" != */ ]] || return 1
    [[ "$path" != *$'\n'* ]] || return 1
    [[ "$path" =~ ^[A-Za-z0-9._/-]+$ ]]
}


verify_release_source_files() {
    local manifest="$1"
    local path=""
    local hash=""
    local mode=""
    local actual_hash=""
    local actual_mode=""
    local unsafe_entry=""
    local expected_files=""
    local actual_files=""

    jq -e '
        (.files | type == "array")
        and (.files | length > 0)
        and all(
            .files[];
            (.path | type == "string")
            and (.sha256 | type == "string")
            and (.mode | type == "string")
        )
    ' "$manifest" >/dev/null ||
        fail "Dateiliste im signierten Release-Manifest ist ungültig."

    unsafe_entry="$(
        find "$SOURCE" \
            -mindepth 1 \
            ! -type f \
            ! -type d \
            -print \
            -quit
    )"

    [[ -z "$unsafe_entry" ]] ||
        fail \
"Nicht erlaubter Symlink oder Spezialdateityp im Release gefunden:
  $unsafe_entry"

    while IFS=$'\t' read -r path hash mode; do
        validate_relative_path "$path" ||
            fail "Unsicherer Dateipfad im Release-Manifest: $path"

        [[ "$hash" =~ ^[0-9a-fA-F]{64}$ ]] ||
            fail "Ungültiger SHA-256-Wert für Release-Datei: $path"

        [[ "$mode" == "0644" || "$mode" == "0755" ]] ||
            fail "Ungültiger Dateimodus für Release-Datei $path: $mode"

        [[ -f "$SOURCE/$path" && ! -L "$SOURCE/$path" ]] ||
            fail "Signierte Release-Datei fehlt oder ist kein regulärer Dateityp: $path"

        actual_hash="$(
            sha256sum -- "$SOURCE/$path" |
            awk '{print $1}'
        )"

        [[ "${actual_hash,,}" == "${hash,,}" ]] ||
            fail "SHA-256-Prüfung fehlgeschlagen für Release-Datei: $path"

        actual_mode="$(stat -c '%a' "$SOURCE/$path")"

        [[ "$actual_mode" == "${mode#0}" ]] ||
            fail \
"Dateimodus stimmt nicht mit dem signierten Release-Manifest überein:
  Datei: $path
  Erwartet: $mode
  Tatsächlich: $actual_mode"
    done < <(
        jq -r \
            '.files[] | [.path, .sha256, .mode] | @tsv' \
            "$manifest"
    )

    expected_files="$(
        {
            jq -r '.files[].path' "$manifest"
            printf '%s\n' \
                release-manifest.json \
                release-manifest.json.sig
        } |
        LC_ALL=C sort
    )"

    actual_files="$(
        find "$SOURCE" \
            -type f \
            -printf '%P\n' |
        LC_ALL=C sort
    )"

    [[ "$actual_files" == "$expected_files" ]] ||
        fail \
"Dateibestand der aktiven Release-Version stimmt nicht exakt mit dem signierten Manifest überein."

    info "Alle Dateien der aktiven Release-Version stimmen mit dem signierten Manifest überein."
}

resolve_source_script_version() {
    local release_manifest="$SOURCE/release-manifest.json"
    local release_signature="$SOURCE/release-manifest.json.sig"
    local bundled_source=""
    local active_release=""
    local version=""

    [[ -s "$SYSTEM_MANIFEST_SOURCE" ]] ||
        fail "Systemmanifest fehlt oder ist leer: $SYSTEM_MANIFEST_SOURCE"

    jq -e '
        (.manifest_schema == 1)
        and (.system_version | type == "string")
        and (.build_id | type == "string")
        and (.git_commit | type == "string")
        and (.git_dirty | type == "boolean")
        and (.architecture | type == "string")
        and (.bootstrap_version | type == "string")
        and (.update_api | type == "number")
        and (.config_schema | type == "number")
        and (.bundled_script_version | type == "string")
        and (.capabilities | type == "array")
        and all(.capabilities[]; type == "string")
    ' "$SYSTEM_MANIFEST_SOURCE" >/dev/null ||
        fail "Systemmanifest im Live-System ist ungültig."

    if [[ -e "$release_manifest" || -e "$release_signature" ]]; then
        [[ -s "$release_manifest" ]] ||
            fail "Release-Manifest fehlt oder ist leer: $release_manifest"

        [[ -s "$release_signature" ]] ||
            fail "Signatur des Release-Manifests fehlt: $release_signature"

        if ! ssh-keygen -Y verify \
            -f "$ALLOWED_SIGNERS_SOURCE" \
            -I custom-arch-release \
            -n custom-arch-update-release \
            -s "$release_signature" \
            < "$release_manifest" \
            >/dev/null 2>&1
        then
            fail "Signatur der aktiven Script-Version ist ungültig."
        fi

        jq -e '
            (.manifest_schema == 1)
            and (.script_version | type == "string")
        ' "$release_manifest" >/dev/null ||
            fail "Release-Manifest der aktiven Script-Version ist ungültig."

        version="$(jq -r '.script_version' "$release_manifest")"

        validate_script_version "$version" ||
            fail "Ungültige aktive Script-Version: $version"

        active_release="$(
            readlink -f -- "$CURRENT_LINK" \
                2>/dev/null ||
            true
        )"

        [[ -n "$active_release" ]] ||
            fail "Keine vom Live-Updater aktivierte Script-Version gefunden."

        [[ "$SOURCE" == "$active_release" ]] ||
            fail \
"Signierte Script-Quelle ist nicht die vom Live-Updater aktivierte Version:
  Quelle: $SOURCE
  Aktiv:  $active_release"

        verify_release_source_files "$release_manifest"

        info "Aktive signierte Script-Version: $version"
    else
        bundled_source="$(
            realpath -e -- "$BUNDLED_DIR" 2>/dev/null ||
            true
        )"

        [[ -n "$bundled_source" && "$SOURCE" == "$bundled_source" ]] ||
            fail \
"Quellverzeichnis besitzt kein signiertes Release-Manifest und ist nicht die gebündelte ISO-Basis:
  $SOURCE"

        version="$(
            jq -r '.bundled_script_version' \
                "$SYSTEM_MANIFEST_SOURCE"
        )"

        validate_script_version "$version" ||
            fail "Ungültige gebündelte Script-Version: $version"

        info "Aktive gebündelte ISO-Script-Version: $version"
    fi

    ACTIVE_SCRIPT_VERSION="$version"
}

check_target_system() {
    local os_id
    local mount_options
    local available_bytes
    local minimum_bytes=$((50 * 1024 * 1024))

    TARGET="$(realpath -e -- "$TARGET")"

    [[ "$TARGET" != "/" ]] ||
        fail "Das Live-System selbst darf nicht als Ziel verwendet werden."

    case "$TARGET/" in
        "$SOURCE/"*)
            fail "Das Ziel darf nicht innerhalb des Quellverzeichnisses liegen."
            ;;
    esac

    case "$SOURCE/" in
        "$TARGET/"*)
            fail "Das Quellverzeichnis darf nicht innerhalb des Zielsystems liegen."
            ;;
    esac

    [[ -f "$TARGET/etc/os-release" ]] ||
        fail "Im Ziel fehlt /etc/os-release."

    os_id="$(
        awk -F= '
            $1 == "ID" {
                gsub(/^"|"$/, "", $2)
                print $2
                exit
            }
        ' "$TARGET/etc/os-release"
    )"

    [[ "$os_id" == "arch" ]] ||
        fail "Das Ziel scheint kein Arch-Linux-System zu sein. ID=$os_id"

    [[ -x "$TARGET/usr/bin/pacman" ]] ||
        fail "Pacman wurde im Zielsystem nicht gefunden."

    [[ -f "$TARGET/etc/passwd" ]] ||
        fail "Im Ziel fehlt /etc/passwd."

    [[ -s "$TARGET/etc/fstab" ]] ||
        fail "Im Ziel fehlt eine verwendbare /etc/fstab."

    mount_options="$(
        findmnt \
            --kernel \
            --raw \
            --noheadings \
            --first-only \
            --mountpoint "$TARGET" \
            --output VFS-OPTIONS
    )"

    case ",$mount_options," in
        *,rw,*)
            ;;
        *)
            fail "Das Zielsystem ist nicht schreibbar: $mount_options"
            ;;
    esac

    available_bytes="$(
        df \
            --block-size=1 \
            --output=avail \
            "$TARGET" |
        awk 'NR == 2 { print $1 }'
    )"

    [[ "$available_bytes" =~ ^[0-9]+$ ]] ||
        fail "Freier Speicherplatz konnte nicht ermittelt werden."

    (( available_bytes >= minimum_bytes )) ||
        fail "Im Zielsystem sind weniger als 50 MiB frei."

    info "Installiertes Arch-System erfolgreich erkannt."

    findmnt \
        --kernel \
        --raw \
        --noheadings \
        --first-only \
        --mountpoint "$TARGET" \
        --output SOURCE,FSTYPE,TARGET,OPTIONS
}

copy_installer() {
    local destination="$TARGET$DESTINATION_RELATIVE"
    local timestamp
    local backup=""

    timestamp="$(date -u +'%Y%m%dT%H%M%SZ')"

    if [[ -e "$destination" ]]; then
        backup="${destination}.backup-${timestamp}"

        [[ ! -e "$backup" ]] ||
            fail "Backup-Ziel existiert bereits: $backup"

        warn "Vorhandener Installer wird gesichert nach:"
        warn "$backup"

        mv -- "$destination" "$backup"
    fi

    install \
        --directory \
        --mode 0755 \
        "$destination"

    info "Kopiere Installer nach:"
    info "$destination"

    cp \
        --archive \
        -- "$SOURCE/." "$destination/"

    chown \
        --recursive \
        root:root \
        "$destination"

    chmod 0755 "$destination"

    find "$destination" \
        -type f \
        -name '*.sh' \
        -exec chmod 0755 {} +

    cat >"$destination/COPY_INFO.txt" <<EOF
Custom-Linux-Installer

Kopiert am:
  $timestamp UTC

Quelle im Live-System:
  $SOURCE

Kopierte Script-Version:
  $ACTIVE_SCRIPT_VERSION

Installiertes System:
  $TARGET

Ziel im installierten System:
  $DESTINATION_RELATIVE
EOF

    info "Erzeuge SHA-256-Prüfsummen."

    (
        cd "$destination"

        while IFS= read -r -d '' file; do
            sha256sum -- "$file"
        done < <(
            find . \
                -type f \
                ! -name 'SHA256SUMS' \
                -print0 |
            LC_ALL=C sort -z
        ) >SHA256SUMS

        sha256sum --check SHA256SUMS
    )

    sync

    info "Kopieren und Prüfsummenkontrolle erfolgreich."
    printf '\n'
    printf 'Nach dem Neustart ausführen:\n\n'
    printf '  cd %s\n' "$DESTINATION_RELATIVE"
    printf '  ./02-postinstall-test.sh\n'
}

enable_target_services() {
    info "Stelle Netzwerk-, Bluetooth- und Updater-Basispakete im Zielsystem sicher."

    arch-chroot "$TARGET" \
        pacman -S --needed --noconfirm \
        bluez \
        bluez-utils \
        curl \
        jq \
        networkmanager \
        openssh

    printf '\n'
    info "Aktiviere NetworkManager im installierten System."

    arch-chroot "$TARGET" \
        systemctl enable NetworkManager.service

    printf '\n'
    info "Aktiviere Bluetooth im installierten System."

    arch-chroot "$TARGET" \
        systemctl enable bluetooth.service

    printf '\n'
    info "Prüfe aktivierte Dienste."

    arch-chroot "$TARGET" \
        systemctl is-enabled NetworkManager.service

    arch-chroot "$TARGET" \
        systemctl is-enabled bluetooth.service
}

install_target_update_bootstrap() {
    local target_updater="$TARGET/usr/lib/custom-linux/custom-update.sh"
    local target_launcher="$TARGET/usr/local/bin/custom-linux"
    local target_signers="$TARGET/usr/share/custom-linux/update-keys/allowed_signers"
    local target_manifest="$TARGET/usr/share/custom-linux/system-manifest.json"
    local target_manifest_tmp="${target_manifest}.tmp.$$"

    info "Installiere stabilen Script-Updater und Launcher im Zielsystem."

    rm -f -- "$target_launcher"

    install \
        --directory \
        --mode 0755 \
        "$TARGET/usr/lib/custom-linux" \
        "$TARGET/usr/local/bin" \
        "$TARGET/usr/share/custom-linux/update-keys"

    install \
        --mode 0755 \
        "$UPDATER_SOURCE" \
        "$target_updater"

    install \
        --mode 0755 \
        "$LAUNCHER_SOURCE" \
        "$target_launcher"


    install \
        --mode 0644 \
        "$ALLOWED_SIGNERS_SOURCE" \
        "$target_signers"

    rm -f -- "$target_manifest_tmp"

    if ! jq \
        --arg bundled_script_version "$ACTIVE_SCRIPT_VERSION" \
        '.bundled_script_version = $bundled_script_version' \
        "$SYSTEM_MANIFEST_SOURCE" \
        >"$target_manifest_tmp"
    then
        rm -f -- "$target_manifest_tmp"
        fail "Systemmanifest für das Zielsystem konnte nicht erzeugt werden."
    fi

    if ! jq empty "$target_manifest_tmp"; then
        rm -f -- "$target_manifest_tmp"
        fail "Erzeugtes Ziel-Systemmanifest ist ungültiges JSON."
    fi

    install \
        --mode 0644 \
        "$target_manifest_tmp" \
        "$target_manifest"

    rm -f -- "$target_manifest_tmp"

    chown root:root \
        "$target_updater" \
        "$target_launcher" \
        "$target_signers" \
        "$target_manifest"

    cmp -s "$UPDATER_SOURCE" "$target_updater" ||
        fail "Bootstrap-Updater wurde nicht korrekt kopiert."

    cmp -s "$LAUNCHER_SOURCE" "$target_launcher" ||
        fail "Launcher wurde nicht korrekt kopiert."

    cmp -s "$ALLOWED_SIGNERS_SOURCE" "$target_signers" ||
        fail "allowed_signers wurde nicht korrekt kopiert."

    [[ "$(
        jq -r '.bundled_script_version' "$target_manifest"
    )" == "$ACTIVE_SCRIPT_VERSION" ]] ||
        fail "bundled_script_version im Ziel-Systemmanifest ist falsch."

    [[ "$(
        jq -S -c 'del(.bundled_script_version)' \
            "$SYSTEM_MANIFEST_SOURCE"
    )" == "$(
        jq -S -c 'del(.bundled_script_version)' \
            "$target_manifest"
    )" ]] ||
        fail "Andere Systemmanifest-Felder wurden unerwartet verändert."

    info "Updater-Bootstrap, Launcher, allowed_signers und Systemmanifest wurden geprüft."
}


configure_tpm_boot_workaround() {
    local grub_defaults="$TARGET/etc/default/grub"
    local kernel_cmdline="$TARGET/etc/kernel/cmdline"
    local tpm_parameters="systemd.tpm2_wait=false systemd.tpm2_measured_os=false"
    local configuration_found=0

    info "Konfiguriere TPM-Boot-Workaround im installierten System."

    if [[ -f "$grub_defaults" ]]; then
        configuration_found=1
        info "GRUB-Konfiguration erkannt."

        if grep -q '^GRUB_CMDLINE_LINUX_DEFAULT=' "$grub_defaults"; then
            if ! grep -q 'systemd.tpm2_wait=false' "$grub_defaults"; then
                sed -i \
                    '/^GRUB_CMDLINE_LINUX_DEFAULT=/ s/"$/ systemd.tpm2_wait=false systemd.tpm2_measured_os=false"/' \
                    "$grub_defaults"
            else
                info "TPM-Boot-Parameter sind bereits in GRUB vorhanden."
            fi
        else
            printf '\nGRUB_CMDLINE_LINUX_DEFAULT="%s"\n' \
                "$tpm_parameters" >> "$grub_defaults"
        fi

        info "Erzeuge GRUB-Konfiguration neu."

        arch-chroot "$TARGET" \
            grub-mkconfig -o /boot/grub/grub.cfg

        info "TPM-Boot-Workaround für GRUB eingerichtet."
    fi

    if [[ -f "$kernel_cmdline" ]]; then
        configuration_found=1
        info "/etc/kernel/cmdline erkannt."

        if ! grep -q 'systemd.tpm2_wait=false' "$kernel_cmdline"; then
            if [[ -s "$kernel_cmdline" ]]; then
                sed -i \
                    "1 s|[[:space:]]*$| $tpm_parameters|" \
                    "$kernel_cmdline"
            else
                printf '%s\n' "$tpm_parameters" > "$kernel_cmdline"
            fi
        else
            info "TPM-Boot-Parameter sind bereits in /etc/kernel/cmdline vorhanden."
        fi

        info "Erzeuge Initramfs/UKI neu."

        arch-chroot "$TARGET" \
            mkinitcpio -P

        info "TPM-Boot-Workaround für /etc/kernel/cmdline eingerichtet."
    fi

    if (( configuration_found == 0 )); then
        warn "Keine unterstützte Bootloader-Konfiguration für den TPM-Workaround gefunden."
        warn "TPM-Boot-Parameter wurden deshalb nicht automatisch eingetragen."
    fi
}

while (( $# > 0 )); do
    case "$1" in
        --copy)
            MODE="copy"
            shift
            ;;

        --target)
            (( $# >= 2 )) ||
                fail "Nach --target fehlt der Pfad."

            TARGET="$2"
            shift 2
            ;;

        --source)
            (( $# >= 2 )) ||
                fail "Nach --source fehlt der Pfad."

            SOURCE="$2"
            shift 2
            ;;

        --help|-h)
            usage
            exit 0
            ;;

        *)
            fail "Unbekannte Option: $1"
            ;;
    esac
done

configure_runtime_environment

for required_command in \
    arch-chroot \
    awk \
    bash \
    chmod \
    chown \
    cmp \
    cp \
    date \
    df \
    find \
    findmnt \
    grep \
    install \
    jq \
    mv \
    readlink \
    realpath \
    rm \
    sed \
    sha256sum \
    sort \
    ssh-keygen \
    stat \
    sync
do
    require_command "$required_command"
done

info "Starte Vorprüfung."

check_source
check_update_bootstrap
resolve_source_script_version
detect_target
check_target_system
printf '\n'
info "Alle Vorprüfungen waren erfolgreich."

if [[ "$MODE" == "copy" ]]; then
    copy_installer
    install_target_update_bootstrap
    enable_target_services
    configure_tpm_boot_workaround
else
    printf '\n'
    printf 'Es wurde noch nichts verändert.\n'
    printf 'Zum Prüfen und anschließenden Kopieren ausführen:\n\n'
    printf '  %s --copy\n' "$0"
fi

