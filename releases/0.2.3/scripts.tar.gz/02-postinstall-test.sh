#!/usr/bin/env bash

# 02-postinstall-test.sh
#
# Aufgabe:
# - Wird NACH dem ersten Neustart ausgeführt.
# - Prüft, ob der Installer korrekt kopiert wurde.
# - Prüft Arch Linux, Benutzerkonto, sudo, DNS und Internet.
# - Kontrolliert die SHA-256-Prüfsummen.
# - Führt einen echten Pacman-Test durch.
# - Installiert dabei das kleine und später nützliche Paket fastfetch.
# - Erstellt ein ausführliches Protokoll und eine Erfolgsmarkierung.
#
# Benötigte Rechte:
# - Das Skript wird als normaler Benutzer gestartet.
# - Für Pacman und Systemdateien fragt es über sudo nach Rechten.
#
# Betroffene Bereiche:
# - ~/.local/state/custom-linux/
# - /var/log/custom-linux/
# - /var/lib/custom-linux/
# - Pacman-Paketbestand

set -Eeuo pipefail
IFS=$'\n\t'

for bootstrap_command in date dirname mkdir tee; do
    command -v "$bootstrap_command" >/dev/null 2>&1 || {
        printf '[FEHLER] Benötigter Basisbefehl fehlt: %s\n' "$bootstrap_command" >&2
        exit 1
    }
done

EXPECTED_DIRECTORY="/opt/custom-linux-installer"
TEST_PACKAGE="fastfetch"

[[ -n "${HOME:-}" ]] || {
    printf '[FEHLER] HOME ist nicht gesetzt.\n' >&2
    exit 1
}

[[ -d "$HOME" ]] || {
    printf '[FEHLER] Benutzerverzeichnis fehlt: %s\n' "$HOME" >&2
    exit 1
}

TIMESTAMP="$(date -u +'%Y%m%dT%H%M%SZ')"
USER_STATE_DIRECTORY="$HOME/.local/state/custom-linux"
USER_LOG_FILE="$USER_STATE_DIRECTORY/postinstall-test-$TIMESTAMP.log"

mkdir -p "$USER_STATE_DIRECTORY"

exec > >(tee -a "$USER_LOG_FILE") 2>&1

trap '
    rc=$?
    printf "\n[FEHLER] Zeile %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2
    printf "[FEHLER] Der Test wurde mit Exit-Code %s beendet.\n" "$rc" >&2
    printf "[FEHLER] Benutzerprotokoll: %s\n" "$USER_LOG_FILE" >&2
    exit "$rc"
' ERR

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

require_command() {
    local command_name="$1"

    command -v "$command_name" >/dev/null 2>&1 ||
        fail "Benötigter Befehl fehlt: $command_name"
}

read_os_id() {
    awk -F= '
        $1 == "ID" {
            gsub(/^"|"$/, "", $2)
            print $2
            exit
        }
    ' /etc/os-release
}

check_installed_system() {
    local os_id
    local root_source
    local root_options

    [[ ! -e /run/archiso ]] ||
        fail "Dieses Skript läuft noch im Arch-ISO-Live-System."

    os_id="$(read_os_id)"

    [[ "$os_id" == "arch" ]] ||
        fail "Das laufende System ist kein Arch Linux. ID=$os_id"

    root_source="$(
        findmnt \
            --kernel \
            --raw \
            --noheadings \
            --first-only \
            --mountpoint / \
            --output SOURCE
    )"

    [[ "$root_source" != *airootfs* ]] ||
        fail "Das Root-Dateisystem gehört noch zum Live-System."

    root_options="$(
        findmnt \
            --kernel \
            --raw \
            --noheadings \
            --first-only \
            --mountpoint / \
            --output VFS-OPTIONS
    )"

    case ",$root_options," in
        *,rw,*)
            ;;
        *)
            fail "Das Root-Dateisystem ist nicht schreibbar: $root_options"
            ;;
    esac

    info "Installiertes Arch-Linux-System erkannt."
    info "Root-Dateisystem: $root_source"
}

check_user_environment() {
    local write_test

    (( EUID != 0 )) ||
        fail \
"Dieses Skript soll als normaler Benutzer gestartet werden.

Nicht verwenden:
  sudo ./02-postinstall-test.sh

Richtig:
  ./02-postinstall-test.sh"

    write_test="$USER_STATE_DIRECTORY/write-test"

    printf 'test\n' >"$write_test"
    rm -- "$write_test"

    info "Benutzerumgebung und Schreibzugriff funktionieren."
}

check_installer_copy() {
    local script
    local script_count=0

    [[ "$SCRIPT_DIR" == "$EXPECTED_DIRECTORY" ]] ||
        fail \
"Das Skript läuft nicht aus dem erwarteten Verzeichnis.

Erwartet:
  $EXPECTED_DIRECTORY

Tatsächlich:
  $SCRIPT_DIR"

    [[ -s "$SCRIPT_DIR/SHA256SUMS" ]] ||
        fail "SHA256SUMS fehlt oder ist leer."

    info "Prüfe kopierte Dateien anhand ihrer SHA-256-Prüfsummen."

    (
        cd "$SCRIPT_DIR"
        sha256sum --check SHA256SUMS
    )

    info "Prüfe erneut die Syntax aller Shellskripte."

    while IFS= read -r -d '' script; do
        script_count=$((script_count + 1))
        bash -n "$script"
    done < <(
        find "$SCRIPT_DIR" \
            -type f \
            -name '*.sh' \
            -print0
    )

    (( script_count > 0 )) ||
        fail "Keine Shellskripte gefunden."

    info "$script_count Shellskript(e) erfolgreich kontrolliert."
}

check_network() {
    command -v nm-online >/dev/null 2>&1 ||
        fail "NetworkManager ist installiert, aber der Befehl nm-online fehlt."

    info "Warte auf NetworkManager (maximal 30 Sekunden)."

    if nm-online --quiet --timeout=30; then
        info "NetworkManager hat den Verbindungsaufbau abgeschlossen."
    else
        fail "NetworkManager konnte den Verbindungsaufbau innerhalb von 30 Sekunden nicht abschließen."
    fi

    printf '\n'
    info "Prüfe DNS-Auflösung."

    getent ahosts archlinux.org >/dev/null ||
        fail "DNS-Auflösung von archlinux.org ist fehlgeschlagen."

    info "Prüfe HTTPS-Verbindung."

    curl \
        --fail \
        --silent \
        --show-error \
        --location \
        --max-time 20 \
        https://archlinux.org/ \
        --output /dev/null ||
        fail "HTTPS-Verbindung zu archlinux.org ist fehlgeschlagen."

    info "DNS und Internetverbindung funktionieren."
}

check_time() {
    local synchronized

    synchronized="$(
        timedatectl \
            show \
            --property=NTPSynchronized \
            --value \
            2>/dev/null ||
        true
    )"

    if [[ "$synchronized" == "yes" ]]; then
        info "Systemzeit ist per NTP synchronisiert."
    else
        warn "NTP-Synchronisierung wurde nicht bestätigt: ${synchronized:-unbekannt}"
        warn "Der Test wird fortgesetzt, weil dies nicht zwingend ein Fehler sein muss."
    fi
}

test_sudo() {
    info "Prüfe sudo-Berechtigung."

    sudo --validate

    info "sudo funktioniert."
}

test_pacman() {
    [[ ! -e /var/lib/pacman/db.lck ]] ||
        fail \
"Pacman ist gesperrt.

Gefundene Datei:
  /var/lib/pacman/db.lck

Möglicherweise läuft bereits ein Update oder eine Paketinstallation."

    printf '\n'
    printf 'Der nächste Schritt führt ein vollständiges Systemupdate aus\n'
    printf 'und installiert das Testpaket "%s".\n' "$TEST_PACKAGE"
    printf '\n'

    read -r -p 'Fortfahren? [y/N] ' answer

	case "$answer" in
            y|Y|yes|YES|Yes)
            ;;
        *)
            fail "Pacman-Test wurde vom Benutzer abgebrochen."
            ;;
    esac

    sudo pacman \
        --sync \
        --refresh \
        --sysupgrade \
        --needed \
        "$TEST_PACKAGE"

    pacman --query "$TEST_PACKAGE" >/dev/null

    command -v "$TEST_PACKAGE" >/dev/null 2>&1 ||
        fail "$TEST_PACKAGE wurde installiert, aber der Befehl wurde nicht gefunden."

    "$TEST_PACKAGE" --version

    info "Pacman-Test erfolgreich."
}

check_base_services() {
    local system_state

    system_state="$(
        systemctl is-system-running 2>/dev/null ||
        true
    )"

    info "Systemd-Systemzustand: ${system_state:-unbekannt}"

    printf '\n'
    info "Prüfe NetworkManager."

    pacman -Q networkmanager >/dev/null 2>&1 ||
        fail "Pflichtpaket fehlt: networkmanager"

    systemctl is-enabled NetworkManager.service >/dev/null 2>&1 ||
        fail "NetworkManager.service ist nicht aktiviert."

    systemctl is-active NetworkManager.service >/dev/null 2>&1 ||
        fail "NetworkManager.service ist nicht aktiv."

    info "NetworkManager: installiert, aktiviert und aktiv."

    printf '\n'
    info "Prüfe Bluetooth."

    pacman -Q bluez >/dev/null 2>&1 ||
        fail "Pflichtpaket fehlt: bluez"

    pacman -Q bluez-utils >/dev/null 2>&1 ||
        fail "Pflichtpaket fehlt: bluez-utils"

    systemctl is-enabled bluetooth.service >/dev/null 2>&1 ||
        fail "bluetooth.service ist nicht aktiviert."

    systemctl is-active bluetooth.service >/dev/null 2>&1 ||
        fail "bluetooth.service ist nicht aktiv."

    info "Bluetooth: bluez und bluez-utils installiert; Dienst aktiviert und aktiv."
}

write_success_marker() {
    local root_log_directory="/var/log/custom-linux"
    local root_state_directory="/var/lib/custom-linux"
    local root_log_file="$root_log_directory/postinstall-test-$TIMESTAMP.log"
    local marker_file="$root_state_directory/postinstall-test.ok"

    sudo install \
        --directory \
        --mode 0755 \
        "$root_log_directory" \
        "$root_state_directory"

    {
        printf 'Custom-Linux-Postinstall-Test erfolgreich\n'
        printf 'Zeit: %s UTC\n' "$TIMESTAMP"
        printf 'Benutzer: %s\n' "${USER:-unbekannt}"
        printf 'Testpaket: %s\n' "$TEST_PACKAGE"
        printf 'Installer: %s\n' "$SCRIPT_DIR"
    } |
        sudo tee "$marker_file" >/dev/null

    sudo chmod 0644 "$marker_file"

    info "Alle Testschritte waren erfolgreich."
    info "Systemprotokoll wird gespeichert unter:"
    info "$root_log_file"
    info "Erfolgsmarkierung:"
    info "$marker_file"

    sudo cp \
        -- "$USER_LOG_FILE" \
        "$root_log_file"

    sudo chmod 0644 "$root_log_file"

    sync
}

SCRIPT_DIR="$(
    cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
    pwd -P
)"

for required_command in \
    awk \
    bash \
    chmod \
    cp \
    curl \
    date \
    dirname \
    find \
    findmnt \
    getent \
    install \
    mkdir \
    nm-online \
    pacman \
    rm \
    sha256sum \
    sudo \
    sync \
    systemctl \
    tee \
    timedatectl
do
    require_command "$required_command"
done

printf 'Custom-Linux-Postinstall-Funktionstest\n'
printf '=====================================\n'
printf 'Zeit: %s UTC\n' "$TIMESTAMP"
printf 'Benutzer: %s\n' "${USER:-unbekannt}"
printf 'Installer: %s\n\n' "$SCRIPT_DIR"

check_user_environment
check_installed_system
check_installer_copy
test_sudo
check_time
check_base_services
check_network
test_pacman
write_success_marker

printf '\n'
printf 'Der erste ISO- und Postinstall-Test war erfolgreich.\n'
