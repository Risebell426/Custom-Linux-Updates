#!/usr/bin/env bash

# 03-postinstall-setup.sh
#
# Aufgabe:
# - Wird nach erfolgreichem 02-postinstall-test.sh ausgeführt.
# - Installiert die dauerhaft benötigten Schul- und Basisprogramme.
# - Installiert anschließend iNiR über dessen offizielles Setup.
#
# Dieses Skript soll als NORMALER Benutzer gestartet werden.
# Root-Rechte werden nur bei Bedarf über sudo angefordert.

set -Eeuo pipefail
IFS=$'\n\t'

TIMESTAMP="$(date -u +'%Y%m%dT%H%M%SZ')"

STATE_DIR="$HOME/.local/state/custom-linux"
LOG_FILE="$STATE_DIR/postinstall-setup-$TIMESTAMP.log"

INIR_REPOSITORY="https://github.com/snowarch/inir.git"
INIR_DIRECTORY="$HOME/Projects/inir"

PACMAN_PACKAGES=(
    git
    base-devel
    curl
    wget
    jq
    fuse2
    
    firefox
    obsidian
    element-desktop
    prismlauncher
    mysql-workbench

    docker
    docker-compose
)

mkdir -p "$STATE_DIR"

exec > >(tee -a "$LOG_FILE") 2>&1

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

trap '
rc=$?
printf "\n[FEHLER] Zeile %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2
printf "[FEHLER] Abbruch mit Exit-Code %s.\n" "$rc" >&2
printf "[FEHLER] Protokoll: %s\n" "$LOG_FILE" >&2
exit "$rc"
' ERR

check_environment() {
    (( EUID != 0 )) ||
        fail "Dieses Skript nicht mit sudo starten.

Richtig:
./03-postinstall-setup.sh"

    [[ -f /var/lib/custom-linux/postinstall-test.ok ]] ||
        fail "Der erfolgreiche Postinstall-Test wurde nicht gefunden.

Zuerst ausführen:
./02-postinstall-test.sh"

    command -v sudo >/dev/null 2>&1 ||
        fail "sudo wurde nicht gefunden."

    command -v pacman >/dev/null 2>&1 ||
        fail "pacman wurde nicht gefunden."

    info "Grundsystem und Postinstall-Test erkannt."
}

update_system() {
    info "Aktualisiere das System."

    sudo pacman \
        --sync \
        --refresh \
        --sysupgrade \
        --needed \
        --noconfirm
}

install_pacman_packages() {
    info "Installiere Schul- und Basisprogramme."

    sudo pacman \
        --sync \
        --needed \
        --noconfirm \
        "${PACMAN_PACKAGES[@]}"

    info "Pacman-Pakete wurden installiert."
}

configure_docker() {
    info "Aktiviere Docker."

    sudo systemctl enable --now docker.service

    if ! id -nG "$USER" | grep -qw docker; then
        info "Füge Benutzer '$USER' zur Docker-Gruppe hinzu."

        sudo usermod -aG docker "$USER"

        warn "Die neue Docker-Gruppenmitgliedschaft wird erst nach erneutem Login vollständig aktiv."
    fi

    systemctl is-enabled docker.service >/dev/null
    systemctl is-active docker.service >/dev/null

    info "Docker ist aktiviert."
}

install_inir() {
    info "Bereite iNiR vor."

    mkdir -p "$HOME/Projects"

    if [[ -d "$INIR_DIRECTORY/.git" ]]; then
        info "iNiR existiert bereits. Aktualisiere Repository."

        git -C "$INIR_DIRECTORY" pull --ff-only
    elif [[ -e "$INIR_DIRECTORY" ]]; then
        fail "Der Pfad existiert bereits, ist aber kein Git-Repository:
$INIR_DIRECTORY"
    else
        info "Klone iNiR."

        git clone \
            "$INIR_REPOSITORY" \
            "$INIR_DIRECTORY"
    fi

    info "Starte automatische iNiR-Installation."

    cd "$INIR_DIRECTORY"

    ./setup install -y

    info "iNiR-Installation abgeschlossen."
}

install_brave() {
    info "Installiere Brave über das offizielle Linux-Installationsskript."

    curl -fsS https://dl.brave.com/install.sh \
        -o /tmp/brave-install.sh

    bash /tmp/brave-install.sh

    rm -f /tmp/brave-install.sh

    info "Brave-Installationsschritt abgeschlossen."
}

install_vscode() {
    local download_file="/tmp/vscode-linux-x64.tar.gz"
    local install_directory="/opt/visual-studio-code"

    info "Installiere Microsoft Visual Studio Code."

    curl \
        --fail \
        --location \
        --show-error \
        "https://code.visualstudio.com/sha/download?build=stable&os=linux-x64" \
        --output "$download_file"

    sudo rm -rf "$install_directory"

    sudo install \
        --directory \
        --mode 0755 \
        "$install_directory"

    sudo tar \
        --extract \
        --gzip \
        --file "$download_file" \
        --directory "$install_directory" \
        --strip-components=1

    sudo ln -sf \
        "$install_directory/bin/code" \
        /usr/local/bin/code

    rm -f "$download_file"

    command -v code >/dev/null 2>&1 ||
        fail "Visual Studio Code wurde installiert, aber 'code' wurde nicht gefunden."

    info "Visual Studio Code wurde installiert."
}

install_arduino_ide() {
    local api_url="https://api.github.com/repos/arduino/arduino-ide/releases/latest"
    local download_url
    local download_file="/tmp/arduino-ide.AppImage"
    local install_directory="/opt/arduino-ide"

    info "Ermittle aktuelle Arduino IDE."

    download_url="$(
        curl \
            --fail \
            --silent \
            --show-error \
            "$api_url" |
        jq -r '
            .assets[]
            | select(.name | test("Linux_64bit\\.AppImage$"))
            | .browser_download_url
        ' |
        head -n 1
    )"

    [[ -n "$download_url" && "$download_url" != "null" ]] ||
        fail "Arduino-IDE-AppImage konnte nicht gefunden werden."

    info "Lade Arduino IDE herunter."

    curl \
        --fail \
        --location \
        --show-error \
        "$download_url" \
        --output "$download_file"

    sudo install \
        --directory \
        --mode 0755 \
        "$install_directory"

    sudo install \
        --mode 0755 \
        "$download_file" \
        "$install_directory/arduino-ide.AppImage"

    sudo ln -sf \
        "$install_directory/arduino-ide.AppImage" \
        /usr/local/bin/arduino-ide

    rm -f "$download_file"

    command -v arduino-ide >/dev/null 2>&1 ||
        fail "Arduino IDE wurde installiert, aber der Starter wurde nicht gefunden."

    info "Arduino IDE wurde installiert."
}

configure_arduino_udev() {
    local udev_script="/tmp/arduino-udev-setup.sh"

    info "Installiere Arduino-udev-Regeln."

    curl \
        --fail \
        --location \
        --show-error \
        "https://content.arduino.cc/assets/arduino-udev-setup.sh" \
        --output "$udev_script"

    sudo bash "$udev_script"

    rm -f "$udev_script"

    info "Arduino-udev-Regeln wurden eingerichtet."
}

install_xampp() {
    local download_page="https://www.apachefriends.org/download.html"
    local download_page_content=""
    local download_url=""
    local installer="/tmp/xampp-linux-installer.run"

    info "Ermittle aktuellen XAMPP-Linux-Installer."

    download_page_content="$(
        curl \
            --fail \
            --silent \
            --show-error \
            --location \
            "$download_page"
    )" || fail "XAMPP-Downloadseite konnte nicht geladen werden."

    download_url="$(
        grep -oE \
            'https?[^"]*xampp-linux-x64-[^"]*-installer\.run(/download)?' \
            <<< "$download_page_content" |
	sort -V |
	tail -n 1
    )"

    [[ -n "$download_url" ]] ||
        fail "XAMPP-Linux-Download konnte auf der offiziellen Downloadseite nicht gefunden werden."

    if [[ "$download_url" != */download ]]; then
        download_url="${download_url}/download"
    fi

    info "Gefundener XAMPP-Download:"
    info "$download_url"

    info "Lade XAMPP herunter."

    curl \
        --fail \
        --location \
        --show-error \
        "$download_url" \
        --output "$installer"

    chmod 0755 "$installer"

    printf '\n'
    printf 'Der offizielle XAMPP-Installer wird jetzt gestartet.\n'
    printf 'Nach Abschluss kehrt das Custom-Linux-Setup automatisch zurück.\n'
    printf '\n'

    sudo "$installer"

    rm -f "$installer"

    [[ -x /opt/lampp/lampp ]] ||
        fail "XAMPP wurde nach dem Installer nicht unter /opt/lampp gefunden."

    info "XAMPP wurde installiert."
}

final_check() {
    info "Prüfe installierte Programme."

    local commands=(
        git
        firefox
        brave-browser
        obsidian
        element-desktop
        prismlauncher
        mysql-workbench
        docker
        code
        arduino-ide
    )

    local command_name
    local errors=0

    for command_name in "${commands[@]}"; do
        if command -v "$command_name" >/dev/null 2>&1; then
            info "Gefunden: $command_name"
        else
            warn "Nicht gefunden: $command_name"
            errors=$((errors + 1))
        fi
    done

    if [[ -x /opt/lampp/lampp ]]; then
        info "Gefunden: XAMPP (/opt/lampp/lampp)"
    else
        warn "Nicht gefunden: XAMPP (/opt/lampp/lampp)"
        errors=$((errors + 1))
    fi

    if [[ -d "$INIR_DIRECTORY/.git" ]]; then
        info "Gefunden: iNiR ($INIR_DIRECTORY)"
    else
        warn "Nicht gefunden: iNiR ($INIR_DIRECTORY)"
        errors=$((errors + 1))
    fi

    printf '\n'

    if (( errors == 0 )); then
        info "Alle vorgesehenen Programme wurden gefunden."
    else
        warn "$errors vorgesehene Installation(en) konnten nicht bestätigt werden."
    fi

    info "Postinstall-Setup abgeschlossen."
    info "Protokoll:"
    info "$LOG_FILE"
}

printf 'Custom-Linux Postinstall-Setup\n'
printf '==============================\n\n'

check_environment
update_system
install_pacman_packages
configure_docker
install_inir
install_brave
install_vscode
install_arduino_ide
configure_arduino_udev
install_xampp
final_check
