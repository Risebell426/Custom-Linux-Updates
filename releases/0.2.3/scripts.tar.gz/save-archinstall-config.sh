#!/usr/bin/env bash

# save-archinstall-config.sh
#
# Aufgabe:
# - Wird im Custom-Linux-Live-System ausgeführt.
# - Sucht die Ventoy-Datenpartition anhand des Labels "Ventoy SSK".
# - Mountet Ventoy schreibbar.
# - Sucht die von Archinstall erzeugten Konfigurationsdateien.
# - Kopiert nur die nicht sensiblen Konfigurationen nach:
#
#   Ventoy SSK/custom-linux/archinstall/
#
# Sicherheit:
# - user_credentials.json wird NICHT kopiert.
# - Das Skript formatiert oder partitioniert keine Datenträger.
# - Vorhandene Konfigurationen werden vor dem Überschreiben gesichert.
# - Nach dem Kopieren wird sync ausgeführt.
#
# Benötigte Rechte:
# - Root im Arch-Live-System.
#
# Betroffene Bereiche:
# - /var/log/archinstall/
# - /mnt/ventoy/
# - Ventoy SSK/custom-linux/archinstall/

set -Eeuo pipefail
IFS=$'\n\t'

VENTOY_LABEL="Ventoy SSK"
MOUNT_POINT="/mnt/ventoy"
DESTINATION_RELATIVE="custom-linux/archinstall"
ARCHINSTALL_LOG_DIRECTORY="/var/log/archinstall"

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

trap '
rc=$?
printf "\n[FEHLER] Zeile %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2
printf "[FEHLER] Abbruch mit Exit-Code %s.\n" "$rc" >&2
exit "$rc"
' ERR

(( EUID == 0 )) ||
    fail "Dieses Skript muss im Arch-Live-System als Root ausgeführt werden."

for required_command in \
    blkid \
    cp \
    date \
    findmnt \
    mkdir \
    mount \
    mountpoint \
    sync
do
    command -v "$required_command" >/dev/null 2>&1 ||
        fail "Benötigter Befehl fehlt: $required_command"
done

[[ -d "$ARCHINSTALL_LOG_DIRECTORY" ]] ||
    fail "Archinstall-Konfigurationsverzeichnis wurde nicht gefunden:
$ARCHINSTALL_LOG_DIRECTORY

Archinstall muss zuerst gestartet und die Konfiguration gespeichert worden sein."

info "Suche Ventoy-Datenpartition mit Label: $VENTOY_LABEL"

VENTOY_DEVICE="$(
    blkid \
        -L "$VENTOY_LABEL" \
        2>/dev/null ||
    true
)"

[[ -n "$VENTOY_DEVICE" ]] ||
    fail "Die Ventoy-Datenpartition '$VENTOY_LABEL' wurde nicht gefunden."

[[ -b "$VENTOY_DEVICE" ]] ||
    fail "Gefundenes Ventoy-Gerät ist kein Blockgerät: $VENTOY_DEVICE"

info "Ventoy-Partition gefunden: $VENTOY_DEVICE"

VENTOY_DEVICE_NAME="${VENTOY_DEVICE##*/}"
VENTOY_MAPPER_DEVICE="/dev/mapper/$VENTOY_DEVICE_NAME"
VENTOY_MOUNT_DEVICE="$VENTOY_DEVICE"

if [[ ! -b "$VENTOY_MAPPER_DEVICE" ]]; then
    if command -v udevadm >/dev/null 2>&1; then
        info "Ventoy-Mapper wurde noch nicht gefunden. Aktualisiere udev."

        udevadm trigger
        udevadm settle
    fi
fi

if [[ -b "$VENTOY_MAPPER_DEVICE" ]]; then
    VENTOY_MOUNT_DEVICE="$VENTOY_MAPPER_DEVICE"

    info "Ventoy-Mapper erkannt:"
    info "$VENTOY_MOUNT_DEVICE"
else
    warn "Kein Ventoy-Mapper gefunden."
    warn "Versuche direktes Gerät: $VENTOY_DEVICE"
fi

mkdir -p "$MOUNT_POINT"

if mountpoint -q "$MOUNT_POINT"; then
    info "Ventoy ist bereits unter $MOUNT_POINT eingehängt."
    info "Stelle sicher, dass der Mount schreibbar ist."

    mount \
        --options remount,rw \
        "$MOUNT_POINT"
else
    info "Hänge Ventoy schreibbar unter $MOUNT_POINT ein."

    mount \
        --options rw \
        "$VENTOY_MOUNT_DEVICE" \
        "$MOUNT_POINT"
fi

MOUNT_OPTIONS="$(
    findmnt \
        --kernel \
        --raw \
        --noheadings \
        --first-only \
        --mountpoint "$MOUNT_POINT" \
        --output VFS-OPTIONS
)"

case ",$MOUNT_OPTIONS," in
    *,rw,*)
        info "Ventoy ist schreibbar eingehängt."
        ;;
    *)
        fail "Ventoy ist nicht schreibbar eingehängt: $MOUNT_OPTIONS"
        ;;
esac

DESTINATION="$MOUNT_POINT/$DESTINATION_RELATIVE"

mkdir -p "$DESTINATION"

TIMESTAMP="$(date -u +'%Y%m%dT%H%M%SZ')"

FILES_FOUND=0

for filename in \
    user_configuration.json \
    user_disk_layouts.json
do
    SOURCE_FILE="$ARCHINSTALL_LOG_DIRECTORY/$filename"
    DESTINATION_FILE="$DESTINATION/$filename"

    if [[ ! -f "$SOURCE_FILE" ]]; then
        warn "Nicht gefunden und deshalb übersprungen: $SOURCE_FILE"
        continue
    fi

    FILES_FOUND=$((FILES_FOUND + 1))

    if [[ -f "$DESTINATION_FILE" ]]; then
        BACKUP_FILE="${DESTINATION_FILE}.backup-${TIMESTAMP}"

        info "Sichere vorhandene Datei:"
        info "$DESTINATION_FILE"
        info "nach:"
        info "$BACKUP_FILE"

        cp \
            --preserve=timestamps \
            -- "$DESTINATION_FILE" "$BACKUP_FILE"
    fi

    info "Kopiere:"
    info "$SOURCE_FILE"
    info "nach:"
    info "$DESTINATION_FILE"

    cp \
        --preserve=timestamps \
        -- "$SOURCE_FILE" "$DESTINATION_FILE"
done

(( FILES_FOUND > 0 )) ||
    fail "Keine unterstützten Archinstall-Konfigurationsdateien wurden gefunden."

if [[ -f "$ARCHINSTALL_LOG_DIRECTORY/user_credentials.json" ]]; then
    warn "user_credentials.json wurde gefunden."
    warn "Diese Datei wird aus Sicherheitsgründen NICHT auf Ventoy kopiert."
fi

sync

printf '\n'
info "Archinstall-Konfiguration erfolgreich gespeichert."
info "Speicherort:"
info "$DESTINATION"

printf '\n'
printf 'Gespeicherte Dateien:\n'

ls -lah "$DESTINATION"

printf '\n'
printf 'Die Ventoy-Partition bleibt momentan eingehängt.\n'
printf 'Vor dem Entfernen des USB-Sticks ausführen:\n\n'
printf '  umount %s\n' "$MOUNT_POINT"
