#!/usr/bin/env bash

# start-archinstall.sh
#
# Aufgabe:
# - Wird im Custom-Linux-Live-System ausgeführt.
# - Sucht die Ventoy-Datenpartition anhand des Labels "Ventoy SSK".
# - Liest eine gespeicherte Archinstall-Konfiguration, sofern vorhanden.
# - Entfernt gespeicherte Datenträger- und Partitionierungsvorgaben.
# - Setzt Deutsch als Sprache für das installierte System.
# - Hängt Ventoy vor dem Start von Archinstall wieder aus.
# - Datenträger und Partitionen werden immer manuell in Archinstall gewählt.
#
# Die Archinstall-Konfiguration bleibt außerhalb der ISO:
#
#   Ventoy SSK/
#   └── custom-linux/
#       └── archinstall/
#           └── user_configuration.json
#
# Sicherheit:
# - Das Skript formatiert selbst keine Datenträger.
# - Es speichert keine Passwörter.
# - user_credentials.json wird absichtlich nicht automatisch verwendet.
# - Fehlt die Konfiguration, wird Archinstall normal gestartet.
# - Die bereinigte Laufzeitkonfiguration ist nur für Root lesbar.
#
# Benötigte Rechte:
# - Root im Arch-Live-System.
#
# Betroffene Bereiche:
# - /mnt/ventoy
# - /run/custom-linux/archinstall/
# - Ventoy-Datenpartition wird nur zum Lesen der Konfiguration eingehängt.
#
# Die eigentliche Installation wird weiterhin von Archinstall durchgeführt.

set -Eeuo pipefail
IFS=$'\n\t'

VENTOY_LABEL="Ventoy SSK"
MOUNT_POINT="/mnt/ventoy"
CONFIG_RELATIVE="custom-linux/archinstall/user_configuration.json"
RUNTIME_DIRECTORY="/run/custom-linux/archinstall"

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

handle_error() {
    local exit_code="$1"
    local failed_line="$2"
    local failed_command="$3"

    printf '\n[FEHLER] Zeile %s: %s\n' \
        "$failed_line" \
        "$failed_command" >&2

    printf '[FEHLER] Abbruch mit Exit-Code %s.\n' \
        "$exit_code" >&2

    exit "$exit_code"
}

trap 'handle_error "$?" "$LINENO" "$BASH_COMMAND"' ERR

(( EUID == 0 )) ||
    fail "Dieses Skript muss im Arch-Live-System als Root ausgeführt werden."

for required_command in \
    archinstall \
    blkid \
    findmnt \
    install \
    jq \
    mkdir \
    mktemp \
    mount \
    mountpoint \
    readlink \
    sync \
    umount
do
    command -v "$required_command" >/dev/null 2>&1 ||
        fail "Benötigter Befehl fehlt: $required_command"
done

info "Suche Ventoy-Datenpartition mit Label: $VENTOY_LABEL"

VENTOY_DEVICE="$(
    blkid \
        -L "$VENTOY_LABEL" \
        2>/dev/null ||
    true
)"

[[ -n "$VENTOY_DEVICE" ]] ||
    fail "Die Ventoy-Datenpartition '$VENTOY_LABEL' wurde nicht gefunden."

[[ -b "$VENTOY_DEVICE" ]] ||
    fail "Gefundenes Ventoy-Gerät ist kein Blockgerät: $VENTOY_DEVICE"

info "Ventoy-Partition gefunden: $VENTOY_DEVICE"

VENTOY_DEVICE_NAME="${VENTOY_DEVICE##*/}"
VENTOY_MAPPER_DEVICE="/dev/mapper/$VENTOY_DEVICE_NAME"
VENTOY_MOUNT_DEVICE="$VENTOY_DEVICE"

if [[ ! -b "$VENTOY_MAPPER_DEVICE" ]]; then
    if command -v udevadm >/dev/null 2>&1; then
        info "Ventoy-Mapper wurde noch nicht gefunden. Aktualisiere udev."

        udevadm trigger
        udevadm settle
    fi
fi

if [[ -b "$VENTOY_MAPPER_DEVICE" ]]; then
    VENTOY_MOUNT_DEVICE="$VENTOY_MAPPER_DEVICE"

    info "Ventoy-Mapper erkannt:"
    info "$VENTOY_MOUNT_DEVICE"
else
    warn "Kein Ventoy-Mapper gefunden."
    warn "Versuche direktes Gerät: $VENTOY_DEVICE"
fi

mkdir -p "$MOUNT_POINT"

if mountpoint -q "$MOUNT_POINT"; then
    info "Ventoy-Mountpunkt ist bereits eingehängt."

    MOUNTED_SOURCE="$(
        findmnt \
            --noheadings \
            --output SOURCE \
            --target "$MOUNT_POINT"
    )"

    [[ -n "$MOUNTED_SOURCE" ]] ||
        fail "Quelle des vorhandenen Ventoy-Mounts konnte nicht ermittelt werden."

    RESOLVED_MOUNTED_SOURCE="$(readlink -f -- "$MOUNTED_SOURCE")"
    RESOLVED_VENTOY_SOURCE="$(readlink -f -- "$VENTOY_MOUNT_DEVICE")"
    RESOLVED_VENTOY_DEVICE="$(readlink -f -- "$VENTOY_DEVICE")"

    [[ "$RESOLVED_MOUNTED_SOURCE" == "$RESOLVED_VENTOY_SOURCE" ||
       "$RESOLVED_MOUNTED_SOURCE" == "$RESOLVED_VENTOY_DEVICE" ]] ||
        fail "Unter $MOUNT_POINT ist ein anderes Gerät eingehängt: $MOUNTED_SOURCE"

    info "Vorhandener Mount gehört zum erwarteten Ventoy-Datenträger."
    info "Binde Ventoy für das Lesen der Konfiguration schreibgeschützt ein."

    mount \
        --options remount,ro \
        "$MOUNT_POINT"
else
    info "Hänge Ventoy schreibgeschützt unter $MOUNT_POINT ein."

    mount \
        --options ro \
        "$VENTOY_MOUNT_DEVICE" \
        "$MOUNT_POINT"
fi

CONFIG_FILE="$MOUNT_POINT/$CONFIG_RELATIVE"
RUNTIME_CONFIG=""

if [[ -f "$CONFIG_FILE" ]]; then
    info "Archinstall-Konfiguration gefunden:"
    info "$CONFIG_FILE"

    install \
        -d \
        -m 0700 \
        "$RUNTIME_DIRECTORY"

    RUNTIME_CONFIG="$(
        mktemp "$RUNTIME_DIRECTORY/user_configuration.XXXXXXXX.json"
    )"

    jq '
        del(.disk_config, .disk_layouts, .blockdevices) |
        .locale_config.sys_lang = "de_DE.UTF-8" |
        .locale_config.sys_enc = "UTF-8"
    ' "$CONFIG_FILE" > "$RUNTIME_CONFIG"

    jq -e '
        (has("disk_config") | not) and
        (has("disk_layouts") | not) and
        (has("blockdevices") | not) and
        .locale_config.sys_lang == "de_DE.UTF-8" and
        .locale_config.sys_enc == "UTF-8"
    ' "$RUNTIME_CONFIG" >/dev/null

    info "Gespeicherte Datenträger- und Partitionierungsvorgaben wurden entfernt."
    info "Datenträger und Partitionen werden manuell in Archinstall ausgewählt."
    info "Systemsprache für die Installation: de_DE.UTF-8"
else
    warn "Keine gespeicherte Archinstall-Konfiguration gefunden:"
    warn "$CONFIG_FILE"
fi

info "Schließe Schreibvorgänge ab und hänge Ventoy aus."

sync

if mountpoint -q "$MOUNT_POINT"; then
    umount "$MOUNT_POINT" ||
        fail "Ventoy konnte nicht sicher ausgehängt werden: $MOUNT_POINT"
fi

info "Ventoy wurde vor dem Installerstart sauber ausgehängt."

printf '\n'

if [[ -n "$RUNTIME_CONFIG" ]]; then
    printf 'Archinstall startet mit bereinigter Konfiguration.\n'
    printf 'Datenträger und Partitionierung bitte manuell auswählen.\n'
    printf '\n'

    exec archinstall \
        --config "$RUNTIME_CONFIG"
fi

printf 'Archinstall wird ohne gespeicherte Konfiguration gestartet.\n'
printf '\n'

exec archinstall
