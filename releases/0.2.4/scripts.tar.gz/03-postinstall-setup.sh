#!/usr/bin/env bash

# 03-postinstall-setup.sh
#
# Aufgabe:
# - Wird nach erfolgreichem 02-postinstall-test.sh ausgeführt.
# - Installiert die dauerhaft benötigten Schul- und Basisprogramme.
# - Richtet KDE Plasma mit frei veränderbaren Einstellungen ein.
# - iNiR kann später bewusst als separater Test aktiviert werden.
#
# Dieses Skript soll als NORMALER Benutzer gestartet werden.
# Root-Rechte werden nur bei Bedarf über sudo angefordert.

set -Eeuo pipefail
IFS=$'\n\t'

TIMESTAMP="$(date -u +'%Y%m%dT%H%M%SZ')"

STATE_DIR="$HOME/.local/state/custom-linux"
LOG_FILE="$STATE_DIR/postinstall-setup-$TIMESTAMP.log"
STEP_STATE_DIR="$STATE_DIR/postinstall-steps"
POSTINSTALL_COMPLETE_MARKER="$STATE_DIR/postinstall-setup.ok"

declare -a COMPLETED_STEPS=()
declare -a ALREADY_COMPLETE_STEPS=()
declare -a OPEN_STEPS=()

INIR_REPOSITORY="https://github.com/snowarch/inir.git"
INIR_DIRECTORY="$HOME/Projects/inir"
INSTALL_INIR="${CUSTOM_LINUX_INSTALL_INIR:-0}"

YAY_AUR_REPOSITORY="https://aur.archlinux.org/yay-bin.git"
YAY_AUR_COMMIT="13e0a4754d106a9252b7479bf1b370fbe454fc48"
YAY_PKGBUILD_SHA256="50599630b591adde54221c5961432f8580188615a223c7ef0ee210cdadcd343e"
YAY_SRCINFO_SHA256="c9d52fb99ae60dbbc9962fbfcd251525c177f0a3fc13ee470df8957281dfdee4"

POWERSHELL_VERSION="7.6.5"
POWERSHELL_ARCHIVE="powershell-${POWERSHELL_VERSION}-linux-x64.tar.gz"
POWERSHELL_URL="https://github.com/PowerShell/PowerShell/releases/download/v${POWERSHELL_VERSION}/${POWERSHELL_ARCHIVE}"
POWERSHELL_SHA256="b34ab3b19acac1d3d4d0d3cfdb02acf62f457b0b6a962ff008132033f7566844"
POWERSHELL_INSTALL_DIRECTORY="/opt/microsoft/powershell/$POWERSHELL_VERSION"
POWERSHELL_LINK="/usr/local/bin/pwsh"
POWERSHELL_VERSION_QUERY="\$PSVersionTable.PSVersion.ToString()"

XAMPP_VERSION="8.2.12-0"
XAMPP_URL="https://sourceforge.net/projects/xampp/files/XAMPP%20Linux/8.2.12/xampp-linux-x64-8.2.12-0-installer.run/download"
XAMPP_SHA256="df0774e7a6d0d0754a5f0132015411234b5f953df2365b693d3758fc35a30374"

VSCODE_AUR_REPOSITORY="https://aur.archlinux.org/visual-studio-code-bin.git"
VSCODE_AUR_COMMIT="69b361eca02a84aa97c43c885e23d463eec96770"
VSCODE_PKGBUILD_SHA256="5126484b61d9a5aea86ab4f028d0ab973f2250c9cb5db5c820ae603a012d6898"
VSCODE_SRCINFO_SHA256="ea5b46738af95b1281f7e76a4ab215beb6a2ee7d07c62d2f3cd5d2fe6baf75cb"

ARDUINO_IDE_AUR_REPOSITORY="https://aur.archlinux.org/arduino-ide-bin.git"
ARDUINO_IDE_AUR_COMMIT="78ca53e1cd1b9fd1ce73b3d8b246a6900fd5ac50"
ARDUINO_IDE_PKGBUILD_SHA256="0ba571f25f0ace1f7f29552af9b85f46415b60cd0dc770a82b2c61965d5540b1"
ARDUINO_IDE_SRCINFO_SHA256="5161a6fec4309781484ac6c85279a253e0a4363b12eba7a8048a91ffbe3707f5"

ARDUINO_UDEV_RULES_FILE="/etc/udev/rules.d/60-custom-linux-arduino.rules"
ARDUINO_UDEV_RULES_SHA256="4b5f40892e81f8c2107c7a449e97f7eea0420d5a87ac6614492dfa152d48373f"

PACMAN_PACKAGES=(
    git
    base-devel
    curl
    wget
    jq
    dialog
    fuse2

    plasma-meta
    sddm
    sddm-kcm
    dolphin
    konsole
    kitty
    plasma-firewall

    firefox
    obsidian
    element-desktop
    discord
    prismlauncher
    mysql-workbench

    docker
    docker-compose
    firewalld
)

mkdir -p "$STATE_DIR" "$STEP_STATE_DIR"

exec > >(tee -a "$LOG_FILE") 2>&1

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

rc=0
trap '
rc=$?
printf "\n[FEHLER] Zeile %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2
printf "[FEHLER] Abbruch mit Exit-Code %s.\n" "$rc" >&2
printf "[FEHLER] Protokoll: %s\n" "$LOG_FILE" >&2
exit "$rc"
' ERR

check_environment() {
    case "$INSTALL_INIR" in
        0|1)
            ;;
        *)
            fail "CUSTOM_LINUX_INSTALL_INIR muss den Wert 0 oder 1 haben."
            ;;
    esac

    (( EUID != 0 )) ||
        fail "Dieses Skript nicht mit sudo starten.

Richtig:
./03-postinstall-setup.sh"

    [[ -f /var/lib/custom-linux/postinstall-test.ok ]] ||
        fail "Der erfolgreiche Postinstall-Test wurde nicht gefunden.

Zuerst ausführen:
./02-postinstall-test.sh"

    command -v sudo >/dev/null 2>&1 ||
        fail "sudo wurde nicht gefunden."

    command -v pacman >/dev/null 2>&1 ||
        fail "pacman wurde nicht gefunden."

    info "Grundsystem und Postinstall-Test erkannt."
}

confirm_continue_without_step() {
    local label="$1"
    local answer=""

    printf '\n'
    warn "Der Schritt '$label' ist fehlgeschlagen."

    while true; do
        read -r -p \
            "Ohne diesen Teil fortfahren? [y/N] " \
            answer || return 1

        case "${answer,,}" in
            y|yes)
                return 0
                ;;
            ""|n|no)
                return 1
                ;;
            *)
                printf 'Bitte y/yes oder n/no eingeben.\n'
                ;;
        esac
    done
}

# Jeder Installationsschritt läuft in einer eigenen Subshell.
# Dadurch kann ein einzelner Fehler abgefangen werden, ohne dass
# set -e den gesamten Postinstall-Ablauf sofort beendet.
run_step_action() (
    local step_result=0

    trap '
    step_result=$?
    printf "\n[FEHLER] Schrittbefehl in Zeile %s: %s\n" \
        "$LINENO" \
        "$BASH_COMMAND" >&2
    printf "[FEHLER] Exit-Code: %s\n" "$step_result" >&2
    exit "$step_result"
    ' ERR

    set -Eeuo pipefail
    "$@"
)

run_resumable_step() {
    local step_id="$1"
    local label="$2"
    local check_function="$3"
    local action_function="$4"
    local marker="$STEP_STATE_DIR/$step_id.ok"
    local started="$SECONDS"
    local duration=0
    local result=0

    printf '\n'
    info "Prüfe Schritt: $label"

    if "$check_function"; then
        : > "$marker"

        info "Bereits vollständig vorhanden."
        info "Dieser Schritt wird übersprungen."

        ALREADY_COMPLETE_STEPS+=("$label")
        return 0
    fi

    rm -f -- "$marker"

    info "Noch nicht vollständig vorhanden."
    info "Führe diesen Schritt jetzt aus."

    set +e
    run_step_action "$action_function"
    result=$?
    set -e

    duration=$((SECONDS - started))

    if (( result == 0 )); then
        # Statusbasierte Prüfungen dürfen den Marker nach einem
        # erfolgreichen Funktionsaufruf als Nachweis verwenden.
        : > "$marker"

        if "$check_function"; then
            COMPLETED_STEPS+=("$label")

            info "Schritt erfolgreich abgeschlossen."
            printf '[INFO] Schrittzeit: %s Minute(n) und %s Sekunde(n).\n' \
                "$((duration / 60))" \
                "$((duration % 60))"

            return 0
        fi

        rm -f -- "$marker"
        result=1

        warn "Der Befehl endete ohne Fehler, aber die Abschlussprüfung schlug fehl."
    else
        warn "Der Schritt endete mit Exit-Code $result."
    fi

    rm -f -- "$marker"
    OPEN_STEPS+=("$label")

    printf '[WARNUNG] Schrittzeit bis zum Fehler: %s Minute(n) und %s Sekunde(n).\n' \
        "$((duration / 60))" \
        "$((duration % 60))"

    if confirm_continue_without_step "$label"; then
        warn "Das Setup wird ohne '$label' fortgesetzt."
        warn "Beim nächsten Start wird dieser offene Schritt erneut versucht."
        return 0
    fi

    fail "Postinstall-Setup wurde nach '$label' beendet."
}

update_system() {
    info "Aktualisiere das System."

    sudo pacman \
        --sync \
        --refresh \
        --sysupgrade \
        --needed \
        --noconfirm
}

install_pacman_packages() {
    info "Installiere Schul- und Basisprogramme."

    sudo pacman \
        --sync \
        --needed \
        --noconfirm \
        "${PACMAN_PACKAGES[@]}"

    info "Pacman-Pakete wurden installiert."
}

configure_plasma_desktop() {
    local default_target=""

    info "Richte KDE Plasma als grafische Desktop-Basis ein."

    command -v plasmashell >/dev/null 2>&1 ||
        fail "Plasma Shell wurde nicht gefunden."

    command -v systemsettings >/dev/null 2>&1 ||
        fail "Die grafischen Plasma-Systemeinstellungen wurden nicht gefunden."

    command -v kscreen-doctor >/dev/null 2>&1 ||
        fail "Die Plasma-Bildschirmverwaltung KScreen wurde nicht gefunden."

    command -v sddm >/dev/null 2>&1 ||
        fail "Der grafische Anmeldedienst SDDM wurde nicht gefunden."

    # Auflösung, Skalierung, Bildwiederholrate und Monitoranordnung
    # werden bewusst nicht vorgegeben. Plasma speichert die später
    # grafisch gewählten Werte passend zum Benutzer und Monitor.
    sudo systemctl set-default graphical.target

    # SDDM ersetzt einen eventuell zuvor ausgewählten Display-Manager,
    # wird während dieses laufenden Setups aber noch nicht gestartet.
    sudo systemctl enable --force sddm.service

    default_target="$(systemctl get-default)"

    [[ "$default_target" == "graphical.target" ]] ||
        fail "Der grafische Systemstart wurde nicht als Standard gesetzt."

    systemctl is-enabled sddm.service >/dev/null ||
        fail "SDDM konnte nicht aktiviert werden."

    info "Plasma und SDDM sind für den nächsten Neustart eingerichtet."
    info "Alle Bildschirm- und Designeinstellungen bleiben frei veränderbar."
}

configure_firewall() {
    info "Aktiviere firewalld."

    sudo systemctl enable --now firewalld.service
    sudo firewall-cmd --set-default-zone=public

    systemctl is-enabled firewalld.service >/dev/null
    systemctl is-active firewalld.service >/dev/null

    info "firewalld ist mit der Standardzone public aktiviert."
}

configure_docker() {
    info "Aktiviere Docker."

    sudo systemctl enable --now docker.service

    if ! id -nG "$USER" | grep -qw docker; then
        info "Füge Benutzer '$USER' zur Docker-Gruppe hinzu."

        sudo usermod -aG docker "$USER"

        warn "Die neue Docker-Gruppenmitgliedschaft wird erst nach erneutem Login vollständig aktiv."
    fi

    systemctl is-enabled docker.service >/dev/null
    systemctl is-active docker.service >/dev/null

    info "Docker ist aktiviert."
}

install_inir() {
    info "Bereite iNiR vor."

    mkdir -p "$HOME/Projects"

    if [[ -d "$INIR_DIRECTORY/.git" ]]; then
        info "iNiR existiert bereits. Aktualisiere Repository."

        git -C "$INIR_DIRECTORY" pull --ff-only
    elif [[ -e "$INIR_DIRECTORY" ]]; then
        fail "Der Pfad existiert bereits, ist aber kein Git-Repository:
$INIR_DIRECTORY"
    else
        info "Klone iNiR."

        git clone \
            "$INIR_REPOSITORY" \
            "$INIR_DIRECTORY"
    fi

    info "Starte automatische iNiR-Installation."

    cd "$INIR_DIRECTORY"

    ./setup install -y

    # iNiR deaktiviert standardmäßig die eigenen Fensterknöpfe
    # der Anwendungen. Custom Linux lässt diese Knöpfe sichtbar.
    niri_config="$HOME/.config/niri/config.kdl"

    if [[ -f "$niri_config" ]]; then
        sed -i \
            's/^[[:space:]]*prefer-no-csd[[:space:]]*$/\/\/ prefer-no-csd/' \
            "$niri_config"

        if grep -Eq \
            '^[[:space:]]*prefer-no-csd[[:space:]]*$' \
            "$niri_config"; then
            fail "Fensterdekoration konnte nicht aktiviert werden."
        fi

        niri validate

        info "Fensterknöpfe für iNiR wurden aktiviert."
    else
        warn "Niri-Konfiguration wurde nicht gefunden: $niri_config"
    fi

    info "iNiR-Installation abgeschlossen."
}

find_aur_helper() {
    local helper=""

    for helper in paru pikaur yay; do
        if command -v "$helper" >/dev/null 2>&1; then
            printf '%s\n' "$helper"
            return 0
        fi
    done

    return 1
}

install_aur_helper() {
    local existing_helper=""
    local source_directory=""
    local actual_commit=""
    local actual_pkgbuild_hash=""
    local actual_srcinfo_hash=""

    if existing_helper="$(find_aur_helper)"; then
        info "AUR-Helfer ist bereits vorhanden: $existing_helper"
        return 0
    fi

    info "Kein AUR-Helfer gefunden."
    info "Installiere den festgelegten Stand von yay-bin."

    (
        source_directory="$(
            mktemp -d "$STATE_DIR/yay-bin-build.XXXXXX"
        )"

        trap 'rm -rf -- "$source_directory"' EXIT

        git clone \
            "$YAY_AUR_REPOSITORY" \
            "$source_directory"

        git -C "$source_directory" \
            checkout \
            --detach \
            "$YAY_AUR_COMMIT"

        actual_commit="$(
            git -C "$source_directory" rev-parse HEAD
        )"

        [[ "$actual_commit" == "$YAY_AUR_COMMIT" ]] ||
            fail "Der ausgecheckte yay-bin-Commit stimmt nicht.

Erwartet: $YAY_AUR_COMMIT
Gefunden: $actual_commit"

        actual_pkgbuild_hash="$(
            sha256sum "$source_directory/PKGBUILD" |
                awk '{print $1}'
        )"

        [[ "$actual_pkgbuild_hash" == "$YAY_PKGBUILD_SHA256" ]] ||
            fail "Die Prüfsumme des yay-bin-PKGBUILD stimmt nicht.

Erwartet: $YAY_PKGBUILD_SHA256
Gefunden: $actual_pkgbuild_hash"

        actual_srcinfo_hash="$(
            sha256sum "$source_directory/.SRCINFO" |
                awk '{print $1}'
        )"

        [[ "$actual_srcinfo_hash" == "$YAY_SRCINFO_SHA256" ]] ||
            fail "Die Prüfsumme der yay-bin-.SRCINFO stimmt nicht.

Erwartet: $YAY_SRCINFO_SHA256
Gefunden: $actual_srcinfo_hash"

        info "Commit und Paketdefinition von yay-bin wurden geprüft."

        cd "$source_directory"

        makepkg \
            --syncdeps \
            --install \
            --needed \
            --noconfirm
    )

    command -v yay >/dev/null 2>&1 ||
        fail "yay-bin wurde gebaut, aber der Befehl yay fehlt."

    info "yay wurde erfolgreich installiert."
}

install_brave() {
    local aur_helper=""

    aur_helper="$(find_aur_helper)" ||
        fail "Brave benötigt unter Arch einen AUR-Helfer."

    info "Installiere brave-bin mit dem vorhandenen AUR-Helfer: $aur_helper"

    "$aur_helper" \
        --sync \
        --needed \
        --noconfirm \
        brave-bin

    check_brave_complete ||
        fail "brave-bin wurde installiert, aber Brave wurde nicht gefunden."

    info "Brave-Installationsschritt abgeschlossen."
}

install_powershell() {
    local archive_file=""
    local extraction_directory=""
    local actual_hash=""
    local installed_version=""

    [[ "$(uname -m)" == "x86_64" ]] ||
        fail "Das vorbereitete PowerShell-Archiv unterstützt nur x86_64."

    if check_powershell_complete; then
        info "PowerShell $POWERSHELL_VERSION ist bereits vollständig vorhanden."
        return 0
    fi

    if [[ -x "$POWERSHELL_INSTALL_DIRECTORY/pwsh" ]]; then
        installed_version="$(
            "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
                -NoLogo \
                -NoProfile \
                -Command "$POWERSHELL_VERSION_QUERY" 2>/dev/null ||
                true
        )"

        if [[ "$installed_version" == "$POWERSHELL_VERSION" ]]; then
            if [[ -e "$POWERSHELL_LINK" && ! -L "$POWERSHELL_LINK" ]]; then
                fail "Der PowerShell-Linkpfad ist durch eine normale Datei belegt:
$POWERSHELL_LINK"
            fi

            sudo ln -sfn \
                "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
                "$POWERSHELL_LINK"

            info "Vorhandene PowerShell-Installation wurde wieder verknüpft."
            return 0
        fi
    fi

    archive_file="$(
        mktemp "$STATE_DIR/powershell-${POWERSHELL_VERSION}.XXXXXX.tar.gz"
    )"

    extraction_directory="$(
        mktemp -d "$STATE_DIR/powershell-extract.XXXXXX"
    )"

    (
        trap 'rm -f -- "$archive_file"; rm -rf -- "$extraction_directory"' EXIT

        info "Lade das offizielle PowerShell-$POWERSHELL_VERSION-Archiv."

        curl \
            --fail \
            --location \
            --show-error \
            --output "$archive_file" \
            "$POWERSHELL_URL"

        actual_hash="$(
            sha256sum "$archive_file" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$POWERSHELL_SHA256" ]] ||
            fail "Die PowerShell-Prüfsumme stimmt nicht.

Erwartet: $POWERSHELL_SHA256
Gefunden: $actual_hash"

        info "PowerShell-Archiv wurde erfolgreich per SHA-256 geprüft."

        tar \
            --extract \
            --gzip \
            --file "$archive_file" \
            --directory "$extraction_directory"

        [[ -f "$extraction_directory/pwsh" ]] ||
            fail "Das PowerShell-Archiv enthält keine pwsh-Datei."

        if [[ -e "$POWERSHELL_INSTALL_DIRECTORY" &&
              ! -d "$POWERSHELL_INSTALL_DIRECTORY" ]]; then
            fail "Der PowerShell-Zielpfad ist kein Verzeichnis:
$POWERSHELL_INSTALL_DIRECTORY"
        fi

        info "Ersetze ausschließlich das Ziel dieser PowerShell-Version:"
        info "$POWERSHELL_INSTALL_DIRECTORY"

        sudo rm -rf -- "$POWERSHELL_INSTALL_DIRECTORY"

        sudo install \
            -d \
            -m 0755 \
            "$POWERSHELL_INSTALL_DIRECTORY"

        sudo cp -a \
            "$extraction_directory/." \
            "$POWERSHELL_INSTALL_DIRECTORY/"

        sudo chmod 0755 "$POWERSHELL_INSTALL_DIRECTORY/pwsh"

        if [[ -e "$POWERSHELL_LINK" && ! -L "$POWERSHELL_LINK" ]]; then
            fail "Der PowerShell-Linkpfad ist durch eine normale Datei belegt:
$POWERSHELL_LINK"
        fi

        sudo ln -sfn \
            "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
            "$POWERSHELL_LINK"
    )

    check_powershell_complete ||
        fail "PowerShell wurde installiert, aber Version $POWERSHELL_VERSION konnte nicht bestätigt werden."

    installed_version="$(
        pwsh \
            -NoLogo \
            -NoProfile \
            -Command "$POWERSHELL_VERSION_QUERY"
    )"

    info "PowerShell wurde erfolgreich installiert: $installed_version"
}

configure_browser_bookmarks() {
    # Die Browser sind zu diesem Zeitpunkt bereits installiert.
    #
    # Firefox verwendet genau eine systemweite policies.json innerhalb
    # seines Installationsverzeichnisses. Brave liest einzelne JSON-Dateien
    # aus /etc/brave/policies/managed/.
    #
    # Der Ordner "Custom Linux" gilt für alle bestehenden und später
    # angelegten Browserprofile. Eigene zusätzliche Lesezeichen bleiben
    # weiterhin möglich. Die hier eingetragenen Links selbst werden durch
    # die Browser als verwaltet angezeigt und können nicht gelöscht werden.
    local firefox_policy="/usr/lib/firefox/distribution/policies.json"
    local brave_policy="/etc/brave/policies/managed/custom-linux-bookmarks.json"

    info "Richte vorbereitete Lesezeichen für Firefox und Brave ein."

    sudo install -d -m 0755 \
        /usr/lib/firefox/distribution \
        /etc/brave/policies/managed

    sudo tee "$firefox_policy" >/dev/null <<'FIREFOX_POLICY_JSON'
{
  "policies": {
    "ManagedBookmarks": [
      {
        "toplevel_name": "Custom Linux"
      },
      {
        "name": "CardCluster",
        "url": "https://cardcluster.com/"
      },
      {
        "name": "AniWorld",
        "url": "https://aniworld.to/"
      },
      {
        "name": "MangaKakalot – Lesezeichen",
        "url": "https://www.mangakakalot.gg/bookmark"
      },
      {
        "name": "Microsoft 365 Search",
        "url": "https://m365.cloud.microsoft/search"
      },
      {
        "name": "WebUntis – Stundenplan",
        "url": "https://bsh.webuntis.com/WebUntis/?school=bsh#/basic/timetablePublic/class?date=2026-08-24&entityId=11371"
      },
      {
        "name": "TSBW – IT-Ausbildung",
        "url": "https://it.ausbildung.tsbw.de/"
      },
      {
        "name": "iNiR – Originalprojekt",
        "url": "https://github.com/snowarch/iNiR"
      },
      {
        "name": "iNiR426 – Eigener Fork",
        "url": "https://github.com/Risebell426/iNiR426"
      },
      {
        "name": "IHK Flensburg – Ausbildungsportal",
        "url": "https://bildung.ihk-flensburg.de/tibrosBB/BB_auszubildende.jsp?old_url=https://bildung.ihk-flensburg.de/tibrosBB/azubiVtrg.jsp"
      },
      {
        "name": "Arch Linux",
        "url": "https://archlinux.org/"
      },
      {
        "name": "Quickshell",
        "url": "https://quickshell.org/"
      },
      {
        "name": "GIMP",
        "url": "https://www.gimp.org/"
      },
      {
        "name": "Neal.fun",
        "url": "https://neal.fun/"
      }
    ]
  }
}
FIREFOX_POLICY_JSON

    sudo tee "$brave_policy" >/dev/null <<'BRAVE_POLICY_JSON'
{
  "ManagedBookmarks": [
    {
      "toplevel_name": "Custom Linux"
    },
    {
      "name": "CardCluster",
      "url": "https://cardcluster.com/"
    },
    {
      "name": "AniWorld",
      "url": "https://aniworld.to/"
    },
    {
      "name": "MangaKakalot – Lesezeichen",
      "url": "https://www.mangakakalot.gg/bookmark"
    },
    {
      "name": "Microsoft 365 Search",
      "url": "https://m365.cloud.microsoft/search"
    },
    {
      "name": "WebUntis – Stundenplan",
      "url": "https://bsh.webuntis.com/WebUntis/?school=bsh#/basic/timetablePublic/class?date=2026-08-24&entityId=11371"
    },
    {
      "name": "TSBW – IT-Ausbildung",
      "url": "https://it.ausbildung.tsbw.de/"
    },
    {
      "name": "iNiR – Originalprojekt",
      "url": "https://github.com/snowarch/iNiR"
    },
    {
      "name": "iNiR426 – Eigener Fork",
      "url": "https://github.com/Risebell426/iNiR426"
    },
    {
      "name": "IHK Flensburg – Ausbildungsportal",
      "url": "https://bildung.ihk-flensburg.de/tibrosBB/BB_auszubildende.jsp?old_url=https://bildung.ihk-flensburg.de/tibrosBB/azubiVtrg.jsp"
    },
    {
      "name": "Arch Linux",
      "url": "https://archlinux.org/"
    },
    {
      "name": "Quickshell",
      "url": "https://quickshell.org/"
    },
    {
      "name": "GIMP",
      "url": "https://www.gimp.org/"
    },
    {
      "name": "Neal.fun",
      "url": "https://neal.fun/"
    }
  ]
}
BRAVE_POLICY_JSON

    sudo chown root:root \
        "$firefox_policy" \
        "$brave_policy"

    sudo chmod 0644 \
        "$firefox_policy" \
        "$brave_policy"

    info "Browser-Lesezeichen wurden systemweit eingerichtet."
}

install_pinned_aur_package() {
    local label="$1"
    local package_name="$2"
    local repository_url="$3"
    local expected_commit="$4"
    local expected_pkgbuild_hash="$5"
    local expected_srcinfo_hash="$6"
    local source_directory=""
    local actual_commit=""
    local actual_pkgbuild_hash=""
    local actual_srcinfo_hash=""

    if pacman -Q "$package_name" >/dev/null 2>&1; then
        info "$label ist bereits als Paket installiert: $package_name"
        return 0
    fi

    source_directory="$(
        mktemp -d "$STATE_DIR/${package_name}-build.XXXXXX"
    )"

    (
        trap 'rm -rf -- "$source_directory"' EXIT

        info "Lade die festgelegte AUR-Paketdefinition: $package_name"

        git clone \
            "$repository_url" \
            "$source_directory"

        git -C "$source_directory" \
            checkout \
            --detach \
            "$expected_commit"

        actual_commit="$(
            git -C "$source_directory" rev-parse HEAD
        )"

        [[ "$actual_commit" == "$expected_commit" ]] ||
            fail "Der AUR-Commit für $package_name stimmt nicht.

Erwartet: $expected_commit
Gefunden: $actual_commit"

        actual_pkgbuild_hash="$(
            sha256sum "$source_directory/PKGBUILD" |
                awk '{print $1}'
        )"

        [[ "$actual_pkgbuild_hash" == "$expected_pkgbuild_hash" ]] ||
            fail "Die PKGBUILD-Prüfsumme für $package_name stimmt nicht.

Erwartet: $expected_pkgbuild_hash
Gefunden: $actual_pkgbuild_hash"

        actual_srcinfo_hash="$(
            sha256sum "$source_directory/.SRCINFO" |
                awk '{print $1}'
        )"

        [[ "$actual_srcinfo_hash" == "$expected_srcinfo_hash" ]] ||
            fail "Die .SRCINFO-Prüfsumme für $package_name stimmt nicht.

Erwartet: $expected_srcinfo_hash
Gefunden: $actual_srcinfo_hash"

        info "AUR-Commit und Paketdefinition wurden geprüft."

        cd "$source_directory"

        makepkg \
            --syncdeps \
            --install \
            --needed \
            --noconfirm
    )

    pacman -Q "$package_name" >/dev/null 2>&1 ||
        fail "$label wurde nicht als Paket installiert: $package_name"

    info "$label wurde erfolgreich installiert."
}

install_vscode() {
    install_pinned_aur_package \
        "Microsoft Visual Studio Code" \
        visual-studio-code-bin \
        "$VSCODE_AUR_REPOSITORY" \
        "$VSCODE_AUR_COMMIT" \
        "$VSCODE_PKGBUILD_SHA256" \
        "$VSCODE_SRCINFO_SHA256"

    check_vscode_complete ||
        fail "Microsoft Visual Studio Code wurde installiert, aber 'code' fehlt."
}

install_arduino_ide() {
    install_pinned_aur_package \
        "Arduino IDE" \
        arduino-ide-bin \
        "$ARDUINO_IDE_AUR_REPOSITORY" \
        "$ARDUINO_IDE_AUR_COMMIT" \
        "$ARDUINO_IDE_PKGBUILD_SHA256" \
        "$ARDUINO_IDE_SRCINFO_SHA256"

    check_arduino_ide_complete ||
        fail "Arduino IDE wurde installiert, aber 'arduino-ide' fehlt."
}

configure_arduino_udev() {
    local temporary_rules=""
    local actual_hash=""

    command -v udevadm >/dev/null 2>&1 ||
        fail "udevadm wurde nicht gefunden."

    temporary_rules="$(
        mktemp "$STATE_DIR/arduino-udev-rules.XXXXXX"
    )"

    (
        trap 'rm -f -- "$temporary_rules"' EXIT

        cat > "$temporary_rules" <<'ARDUINO_UDEV_RULES'
# Custom Linux - Arduino udev rules
# Based on the official Arduino unified rules retrieved on 2026-09-02.

SUBSYSTEMS=="usb", ATTRS{idVendor}=="2341", MODE="0660", TAG+="uaccess"
SUBSYSTEMS=="tty", ENV{ID_REVISION}=="03eb", ENV{ID_MODEL_ID}=="2145", MODE="0660", TAG+="uaccess", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_CANDIDATE}="0"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="03eb", ATTRS{idProduct}=="2145", MODE="0660", TAG+="uaccess", ENV{ID_MM_DEVICE_IGNORE}="1"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="05c6", ATTRS{idProduct}=="9008", MODE="0660", TAG+="uaccess"
ACTION!="add|change", GOTO="custom_linux_openocd_rules_end"
SUBSYSTEM!="usb|tty|hidraw", GOTO="custom_linux_openocd_rules_end"
ATTRS{product}=="*CMSIS-DAP*", MODE="0660", TAG+="uaccess"
LABEL="custom_linux_openocd_rules_end"
ARDUINO_UDEV_RULES

        actual_hash="$(
            sha256sum "$temporary_rules" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$ARDUINO_UDEV_RULES_SHA256" ]] ||
            fail "Die erzeugten Arduino-udev-Regeln stimmen nicht.

Erwartet: $ARDUINO_UDEV_RULES_SHA256
Gefunden: $actual_hash"

        info "Die eingebetteten Arduino-udev-Regeln wurden per SHA-256 geprüft."
        info "Installiere ausschließlich die verwaltete Custom-Linux-Regeldatei:"
        info "$ARDUINO_UDEV_RULES_FILE"

        sudo install \
            --directory \
            --mode 0755 \
            /etc/udev/rules.d

        sudo install \
            --mode 0644 \
            --owner root \
            --group root \
            -- \
            "$temporary_rules" \
            "$ARDUINO_UDEV_RULES_FILE"

        sudo udevadm control --reload-rules
    )

    check_arduino_udev_complete ||
        fail "Die verwalteten Arduino-udev-Regeln konnten nicht bestätigt werden."

    info "Arduino-udev-Regeln wurden eingerichtet."
    info "Ein angeschlossenes Arduino-Board bitte einmal aus- und wieder einstecken."
}

install_xampp() {
    local installer=""
    local actual_hash=""

    if check_xampp_complete; then
        info "Eine vorhandene XAMPP-Installation wurde erkannt."
        info "XAMPP wird nicht erneut installiert."
        return 0
    fi

    installer="$(
        mktemp "$STATE_DIR/xampp-${XAMPP_VERSION}.XXXXXX.run"
    )"

    (
        trap 'rm -f -- "$installer"' EXIT

        info "Lade XAMPP $XAMPP_VERSION vom festgelegten offiziellen Download."

        curl \
            --fail \
            --location \
            --show-error \
            --output "$installer" \
            "$XAMPP_URL"

        actual_hash="$(
            sha256sum "$installer" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$XAMPP_SHA256" ]] ||
            fail "Die SHA-256-Prüfsumme des XAMPP-Installers stimmt nicht.

Erwartet: $XAMPP_SHA256
Gefunden: $actual_hash"

        info "Der XAMPP-Installer wurde erfolgreich per SHA-256 geprüft."

        chmod 0755 "$installer"

        info "Installiere XAMPP ohne zusätzliche Installationsdialoge."

        sudo "$installer" \
            --mode unattended \
            --unattendedmodeui none \
            --installer-language de
    )

    check_xampp_complete ||
        fail "XAMPP wurde ausgeführt, aber /opt/lampp/lampp wurde nicht gefunden."

    info "XAMPP $XAMPP_VERSION wurde erfolgreich installiert."
}
# Jede Prüfung kontrolliert nach Möglichkeit den tatsächlichen
# Systemzustand. Statusdateien werden nur für Schritte verwendet,
# deren Ergebnis nicht zuverlässig über Pakete oder Dateien ermittelt
# werden kann.
step_marker_exists() {
    local step_id="$1"

    [[ -f "$STEP_STATE_DIR/$step_id.ok" ]]
}

check_system_update_complete() {
    local log_file=""

    if step_marker_exists system-update; then
        return 0
    fi

    # Übernahme eines erfolgreichen Laufs der bisherigen Script-Version:
    # Wenn die Paketinstallation erreicht wurde, war das davor ausgeführte
    # vollständige Systemupdate ebenfalls erfolgreich.
    for log_file in "$STATE_DIR"/postinstall-setup-*.log; do
        [[ -f "$log_file" ]] || continue

        if grep -Fq \
            '[INFO] Pacman-Pakete wurden installiert.' \
            "$log_file"; then
            return 0
        fi
    done

    return 1
}

check_pacman_packages_complete() {
    local package=""

    for package in "${PACMAN_PACKAGES[@]}"; do
        pacman -Q "$package" >/dev/null 2>&1 || return 1
    done

    return 0
}

check_plasma_complete() {
    command -v plasmashell >/dev/null 2>&1 &&
        command -v systemsettings >/dev/null 2>&1 &&
        command -v kscreen-doctor >/dev/null 2>&1 &&
        command -v sddm >/dev/null 2>&1 &&
        [[ "$(systemctl get-default 2>/dev/null)" == "graphical.target" ]] &&
        systemctl is-enabled sddm.service >/dev/null 2>&1
}

check_firewall_complete() {
    command -v firewall-cmd >/dev/null 2>&1 &&
        systemctl is-enabled firewalld.service >/dev/null 2>&1 &&
        systemctl is-active firewalld.service >/dev/null 2>&1 &&
        [[ "$(firewall-cmd --get-default-zone 2>/dev/null)" == "public" ]]
}

check_docker_complete() {
    command -v docker >/dev/null 2>&1 &&
        systemctl is-enabled docker.service >/dev/null 2>&1 &&
        systemctl is-active docker.service >/dev/null 2>&1 &&
        id -nG "$USER" 2>/dev/null |
            tr ' ' '\n' |
            grep -qx docker
}

check_inir_complete() {
    [[ -d "$INIR_DIRECTORY/.git" ]] &&
        [[ -f "$HOME/.config/niri/config.kdl" ]] &&
        command -v niri >/dev/null 2>&1
}

check_aur_helper_complete() {
    find_aur_helper >/dev/null
}

check_brave_complete() {
    command -v brave-browser >/dev/null 2>&1 ||
        command -v brave >/dev/null 2>&1
}

check_powershell_complete() {
    local command_path=""
    local installed_version=""

    command_path="$(command -v pwsh 2>/dev/null)" ||
        return 1

    installed_version="$(
        "$command_path" \
            -NoLogo \
            -NoProfile \
            -Command "$POWERSHELL_VERSION_QUERY" 2>/dev/null
    )" || return 1

    [[ "$installed_version" == "$POWERSHELL_VERSION" ]]
}

check_browser_bookmarks_complete() {
    local firefox_policy="/usr/lib/firefox/distribution/policies.json"
    local brave_policy="/etc/brave/policies/managed/custom-linux-bookmarks.json"

    command -v jq >/dev/null 2>&1 &&
        [[ -s "$firefox_policy" ]] &&
        [[ -s "$brave_policy" ]] &&
        jq -e \
            '.policies.ManagedBookmarks | length > 0' \
            "$firefox_policy" >/dev/null 2>&1 &&
        jq -e \
            '.ManagedBookmarks | length > 0' \
            "$brave_policy" >/dev/null 2>&1
}

check_vscode_complete() {
    pacman -Q visual-studio-code-bin >/dev/null 2>&1 &&
        command -v code >/dev/null 2>&1
}

check_arduino_ide_complete() {
    pacman -Q arduino-ide-bin >/dev/null 2>&1 &&
        command -v arduino-ide >/dev/null 2>&1
}

check_arduino_udev_complete() {
    local actual_hash=""
    local ownership_and_mode=""

    [[ -f "$ARDUINO_UDEV_RULES_FILE" ]] ||
        return 1

    actual_hash="$(
        sha256sum "$ARDUINO_UDEV_RULES_FILE" 2>/dev/null |
            awk '{print $1}'
    )"

    [[ "$actual_hash" == "$ARDUINO_UDEV_RULES_SHA256" ]] ||
        return 1

    ownership_and_mode="$(
        stat \
            --format='%U:%G:%a' \
            "$ARDUINO_UDEV_RULES_FILE" \
            2>/dev/null
    )"

    [[ "$ownership_and_mode" == "root:root:644" ]]
}

check_xampp_complete() {
    [[ -x /opt/lampp/lampp ]]
}

final_check() {
    info "Prüfe installierte Programme."

    local commands=(
        git
        plasmashell
        systemsettings
        kscreen-doctor
        dolphin
        konsole
        sddm
        firefox
        firewall-cmd
        obsidian
        element-desktop
        prismlauncher
        mysql-workbench
        docker
        code
        arduino-ide
    )

    local command_name
    local errors=0

    for command_name in "${commands[@]}"; do
        if command -v "$command_name" >/dev/null 2>&1; then
            info "Gefunden: $command_name"
        else
            warn "Nicht gefunden: $command_name"
            errors=$((errors + 1))
        fi
    done

    if check_brave_complete; then
        info "Gefunden: Brave Browser"
    else
        warn "Nicht gefunden: Brave Browser"
        errors=$((errors + 1))
    fi

    if check_powershell_complete; then
        info "Gefunden: PowerShell $POWERSHELL_VERSION"
    else
        warn "Nicht gefunden: PowerShell $POWERSHELL_VERSION"
        errors=$((errors + 1))
    fi

    if [[ -x /opt/lampp/lampp ]]; then
        info "Gefunden: XAMPP (/opt/lampp/lampp)"
    else
        warn "Nicht gefunden: XAMPP (/opt/lampp/lampp)"
        errors=$((errors + 1))
    fi

    if [[ "$INSTALL_INIR" == "1" ]]; then
        if [[ -d "$INIR_DIRECTORY/.git" ]]; then
            info "Gefunden: iNiR ($INIR_DIRECTORY)"
        else
            warn "Nicht gefunden: iNiR ($INIR_DIRECTORY)"
            errors=$((errors + 1))
        fi
    else
        info "iNiR wurde für den separaten späteren Test übersprungen."
    fi

    printf '\n'

    if (( errors == 0 )); then
        info "Alle vorgesehenen Programme wurden gefunden."
    else
        warn "$errors vorgesehene Installation(en) konnten nicht bestätigt werden."
    fi

    info "Postinstall-Setup abgeschlossen."
    info "Protokoll:"
    info "$LOG_FILE"
}

printf 'Custom-Linux Postinstall-Setup\n'
printf '==============================\n\n'

setup_started="$SECONDS"

check_environment

if [[ "$INSTALL_INIR" == "1" ]]; then
    info "Separater iNiR-Modus wurde gestartet."
    info "Der Abschlussstatus des normalen Postinstall-Setups bleibt unverändert."

    run_resumable_step \
        inir \
        "iNiR" \
        check_inir_complete \
        install_inir

    setup_duration=$((SECONDS - setup_started))

    printf '\n'
    printf 'iNiR-Zusammenfassung\n'
    printf '===================\n'
    printf 'Neu abgeschlossen: %s\n' "${#COMPLETED_STEPS[@]}"
    printf 'Bereits vorhanden: %s\n' "${#ALREADY_COMPLETE_STEPS[@]}"
    printf 'Offen und übersprungen: %s\n' "${#OPEN_STEPS[@]}"

    if ((${#OPEN_STEPS[@]} > 0)); then
        printf '\n'
        warn "iNiR ist weiterhin offen."
        warn "Das normale Postinstall-Setup bleibt trotzdem abgeschlossen."
    else
        printf '\n'
        info "iNiR ist vollständig vorhanden."
    fi

    printf '\n[INFO] iNiR-Dauer: %s Minute(n) und %s Sekunde(n).\n' \
        "$((setup_duration / 60))" \
        "$((setup_duration % 60))"

    exit 0
fi

# Ein bestehender Gesamtabschluss wird während einer erneuten Prüfung
# vorübergehend entfernt und erst am erfolgreichen Ende neu gesetzt.
rm -f -- "$POSTINSTALL_COMPLETE_MARKER"

run_resumable_step \
    system-update \
    "System aktualisieren" \
    check_system_update_complete \
    update_system

run_resumable_step \
    pacman-packages \
    "Schul- und Basisprogramme" \
    check_pacman_packages_complete \
    install_pacman_packages

run_resumable_step \
    plasma \
    "KDE Plasma und SDDM" \
    check_plasma_complete \
    configure_plasma_desktop

run_resumable_step \
    firewall \
    "Firewalld" \
    check_firewall_complete \
    configure_firewall

run_resumable_step \
    docker \
    "Docker" \
    check_docker_complete \
    configure_docker

info "iNiR wird unabhängig über den eigenen Menüpunkt verwaltet."

run_resumable_step \
    aur-helper \
    "AUR-Helfer" \
    check_aur_helper_complete \
    install_aur_helper

run_resumable_step \
    brave \
    "Brave Browser" \
    check_brave_complete \
    install_brave

run_resumable_step \
    powershell \
    "PowerShell $POWERSHELL_VERSION" \
    check_powershell_complete \
    install_powershell

run_resumable_step \
    browser-bookmarks \
    "Browser-Lesezeichen" \
    check_browser_bookmarks_complete \
    configure_browser_bookmarks

run_resumable_step \
    vscode \
    "Visual Studio Code" \
    check_vscode_complete \
    install_vscode

run_resumable_step \
    arduino-ide \
    "Arduino IDE" \
    check_arduino_ide_complete \
    install_arduino_ide

run_resumable_step \
    arduino-udev \
    "Arduino-udev-Regeln" \
    check_arduino_udev_complete \
    configure_arduino_udev

run_resumable_step \
    xampp \
    "XAMPP" \
    check_xampp_complete \
    install_xampp

final_check

setup_duration=$((SECONDS - setup_started))

printf '\n'
printf 'Postinstall-Zusammenfassung\n'
printf '===========================\n'
printf 'Neu abgeschlossen: %s\n' "${#COMPLETED_STEPS[@]}"
printf 'Bereits vorhanden: %s\n' "${#ALREADY_COMPLETE_STEPS[@]}"
printf 'Offen und auf Wunsch übersprungen: %s\n' "${#OPEN_STEPS[@]}"

if ((${#COMPLETED_STEPS[@]} > 0)); then
    printf '\nNeu abgeschlossen:\n'
    printf '  - %s\n' "${COMPLETED_STEPS[@]}"
fi

if ((${#ALREADY_COMPLETE_STEPS[@]} > 0)); then
    printf '\nBereits vorhanden und übersprungen:\n'
    printf '  - %s\n' "${ALREADY_COMPLETE_STEPS[@]}"
fi

if ((${#OPEN_STEPS[@]} > 0)); then
    printf '\nOffene Schritte:\n'
    printf '  - %s\n' "${OPEN_STEPS[@]}"

    printf '\n'
    warn "Das Postinstall-Setup wurde mit offenen Schritten beendet."
    warn "Beim nächsten Start werden diese Schritte erneut versucht."

    rm -f -- "$POSTINSTALL_COMPLETE_MARKER"
else
    : > "$POSTINSTALL_COMPLETE_MARKER"

    printf '\n'
    info "Alle ausgewählten Postinstall-Schritte sind vollständig."
    info "Gesamtabschluss wurde gespeichert:"
    info "$POSTINSTALL_COMPLETE_MARKER"
fi

printf '\n[INFO] Gesamtdauer: %s Minute(n) und %s Sekunde(n).\n' \
    "$((setup_duration / 60))" \
    "$((setup_duration % 60))"
