#!/usr/bin/env bash

# custom-linux-menu.sh
#
# Zentrale Steuerung für das Custom-Linux-Projekt.
#
# Das Skript erkennt automatisch, ob es läuft:
# - auf dem Arch-Bau-System,
# - im Custom-Linux-Live-System,
# - oder im installierten Custom-Linux.
#
# Die eigentliche Arbeit bleibt weiterhin in den einzelnen Skripten.
# Dieses Menü dient nur als gemeinsame, leicht bedienbare Oberfläche.

set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_PATH="$(
    readlink -f -- "${BASH_SOURCE[0]}"
)"

SCRIPT_DIR="$(
    cd -- "$(dirname -- "$SCRIPT_PATH")"
    pwd
)"

PROJECT_ROOT=""
ENVIRONMENT="unknown"
CHECK_ERRORS=0

info() {
    printf '[INFO] %s\n' "$*"
}


warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}


fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}


pause_menu() {
    printf '\n'
    read -r -p 'Enter drücken, um zum Menü zurückzukehren ...' _
}


confirm_action() {
    local answer=""

    printf '\n'
    read -r -p "$1 [y/N]: " answer

    case "$answer" in
        y|Y|yes|YES|Yes)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}


find_project_root_from() {
    local current="$1"

    while [[ "$current" != "/" ]]; do
        if [[ -d "$current/.git" ]] &&
           [[ -d "$current/archiso/releng" ]]; then
            printf '%s\n' "$current"
            return 0
        fi

        current="$(dirname -- "$current")"
    done

    return 1
}


detect_environment() {
    PROJECT_ROOT="$(
        find_project_root_from "$SCRIPT_DIR" 2>/dev/null ||
        true
    )"

    if [[ -z "$PROJECT_ROOT" ]]; then
        PROJECT_ROOT="$(
            find_project_root_from "$PWD" 2>/dev/null ||
            true
        )"
    fi

    if [[ -n "$PROJECT_ROOT" ]]; then
        ENVIRONMENT="build"
        return
    fi

    if [[ -d /root/custom-linux ]] &&
       command -v archinstall >/dev/null 2>&1; then
        ENVIRONMENT="live"
        return
    fi

    if [[ -d /opt/custom-linux-installer ]]; then
        ENVIRONMENT="installed"
        return
    fi

    ENVIRONMENT="unknown"
}


check_project_scripts() {

    local scripts=(
        "01-preflight-copy.sh"
        "02-postinstall-test.sh"
        "03-postinstall-setup.sh"
        "start-archinstall.sh"
        "save-archinstall-config.sh"
        "custom-linux-menu.sh"
        "custom-git.sh"
    )

    local script=""
    local path=""
    local errors=0
    local base="$PROJECT_ROOT/archiso/releng/airootfs/root/custom-linux"

    printf '\n'
    info "Prüfe Bash-Syntax aller Custom-Linux-Skripte."
    printf '\n'

    for script in "${scripts[@]}"; do
        path="$base/$script"

        if [[ ! -f "$path" ]]; then
            printf '[FEHLER] %-32s Datei fehlt\n' "$script"
            errors=$((errors + 1))
            continue
        fi

        if bash -n "$path"; then
            printf '[OK]     %s\n' "$script"
        else
            printf '[FEHLER] %s\n' "$script"
            errors=$((errors + 1))
        fi
    done

    printf '\n'
    info "Prüfe Git-Whitespace."

    if git -C "$PROJECT_ROOT" diff --check; then
        printf '[OK]     git diff --check\n'
    else
        printf '[FEHLER] git diff --check\n'
        errors=$((errors + 1))
    fi

    printf '\n'

    CHECK_ERRORS="$errors"

    if (( errors == 0 )); then
        info "Alle Prüfungen waren erfolgreich."
    else
        warn "$errors Prüfung(en) waren nicht erfolgreich."
    fi
}


show_git_status() {
    printf '\n'
    info "Git-Status:"
    printf '\n'

    git -C "$PROJECT_ROOT" status --short

    printf '\n'
    info "Aktueller Branch:"

    git -C "$PROJECT_ROOT" branch --show-current
}




build_iso() {
    local work_directory="$PROJECT_ROOT/build/work"
    local output_directory="$PROJECT_ROOT/iso"
    local profile_directory="$PROJECT_ROOT/archiso/releng"
    local newest_iso=""

    command -v mkarchiso >/dev/null 2>&1 ||
        fail "mkarchiso wurde auf diesem System nicht gefunden."

    if ! confirm_action "Altes Build-Arbeitsverzeichnis löschen und neue ISO bauen?"; then
        info "ISO-Build abgebrochen."
        return
    fi

    printf '\n'
    info "Prüfe zuerst die Skripte."

    check_project_scripts

if (( CHECK_ERRORS > 0 )); then
    printf '\n'
    warn "ISO-Build wurde abgebrochen."
    warn "Zuerst müssen alle Prüfungsfehler behoben werden."
    return
fi

    printf '\n'
    info "Lösche altes Build-Arbeitsverzeichnis:"
    info "$work_directory"

    sudo rm -rf -- "$work_directory"

    mkdir -p \
        "$PROJECT_ROOT/build" \
        "$output_directory"

    printf '\n'
    info "Starte Archiso-Build."
    printf '\n'

    sudo mkarchiso \
        -v \
        -w "$work_directory" \
        -o "$output_directory" \
        "$profile_directory"

    newest_iso="$(
        find "$output_directory" \
            -maxdepth 1 \
            -type f \
            -name '*.iso' \
            -printf '%T@ %p\n' \
            | sort -nr \
            | head -n 1 \
            | cut -d' ' -f2-
    )"

    if [[ -z "$newest_iso" ]] ||
       [[ ! -f "$newest_iso" ]]; then
        fail "Nach dem Build wurde keine ISO gefunden."
    fi

    printf '\n'
    info "ISO-Build abgeschlossen:"
    info "$newest_iso"

    printf '\n'
    info "SHA256:"
    sha256sum "$newest_iso"
}


run_live_script() {
    local script="$1"
    shift

    local path="$SCRIPT_DIR/$script"

    [[ -x "$path" ]] ||
        fail "Skript fehlt oder ist nicht ausführbar: $path"

    "$path" "$@"
}

run_installed_script() {
    local script="$1"
    shift

    local path="$SCRIPT_DIR/$script"

    [[ -x "$path" ]] ||
        fail "Skript fehlt oder ist nicht ausführbar: $path"

    "$path" "$@"
}

run_updater() {
    local updater=""

    case "$ENVIRONMENT" in
        build)
            updater="$PROJECT_ROOT/archiso/releng/airootfs/usr/lib/custom-linux/custom-update.sh"
            ;;
        live|installed)
            updater="/usr/lib/custom-linux/custom-update.sh"
            ;;
        *)
            fail "Updater ist in dieser Umgebung nicht verfügbar."
            ;;
    esac

    [[ -x "$updater" ]] ||
        fail "Updater fehlt oder ist nicht ausführbar: $updater"

    "$updater" "$@"
}

run_custom_git() {
    local git_menu="$PROJECT_ROOT/archiso/releng/airootfs/root/custom-linux/custom-git.sh"

    [[ -x "$git_menu" ]] ||
        fail "Custom-Git wurde nicht gefunden oder ist nicht ausführbar: $git_menu"

    "$git_menu"
}






show_installed_status() {
    local setup_marker="$HOME/.local/state/custom-linux/postinstall-setup.ok"

    printf '\n'

    if [[ -f /var/lib/custom-linux/postinstall-test.ok ]]; then
        printf '[OK] Postinstall-Test wurde erfolgreich abgeschlossen.\n'
    else
        printf '[OFFEN] Postinstall-Test wurde noch nicht erfolgreich abgeschlossen.\n'
    fi

    if [[ -f "$setup_marker" ]]; then
        printf '[OK] Normales Postinstall-Setup wurde vollständig abgeschlossen.\n'
    else
        printf '[OFFEN] Normales Postinstall-Setup ist noch nicht vollständig.\n'
    fi

    if [[ -d "$HOME/Projects/inir/.git" ]] &&
       [[ -f "$HOME/.config/niri/config.kdl" ]] &&
       command -v niri >/dev/null 2>&1; then
        printf '[OK] iNiR wurde vollständig eingerichtet.\n'
    else
        printf '[OPTIONAL] iNiR wurde noch nicht vollständig eingerichtet.\n'
    fi

    printf '\n'
}




run_self_test() {
    local required_file=""
    local -a required_executables=(
        "01-preflight-copy.sh"
        "02-postinstall-test.sh"
        "03-postinstall-setup.sh"
        "custom-git.sh"
        "custom-linux-menu.sh"
        "save-archinstall-config.sh"
        "start-archinstall.sh"
    )

    [[ "$SCRIPT_DIR" == /* && -d "$SCRIPT_DIR" ]] ||
        fail "Ungültiges Script-Verzeichnis: $SCRIPT_DIR"

    for required_file in "${required_executables[@]}"; do
        [[ -x "$SCRIPT_DIR/$required_file" ]] ||
            fail "Self-Test: Datei fehlt oder ist nicht ausführbar: $required_file"
    done

    [[ -f "$SCRIPT_DIR/custom-dialogrc" ]] ||
        fail "Self-Test: custom-dialogrc fehlt."

    case "$ENVIRONMENT" in
        build|live|installed)
            info "Self-Test-Umgebung: $ENVIRONMENT"
            ;;
        unknown)
            warn "Self-Test läuft außerhalb einer erkannten Custom-Linux-Umgebung."
            ;;
        *)
            fail "Self-Test: Ungültige Umgebung: $ENVIRONMENT"
            ;;
    esac

    printf '[OK] Custom-Linux-Menü-Self-Test erfolgreich.\n'
}




# Aktualisierte Menüoberfläche: zentral, dialog-basiert und fehlertolerant.

export DIALOGRC="$SCRIPT_DIR/custom-dialogrc"

# Dialogfenster ohne sichtbaren Terminal-Cursor.
dialog_no_cursor() (
    trap "tput cnorm 2>/dev/null || true" EXIT INT TERM HUP
    tput civis 2>/dev/null || true
    command dialog "$@"
)


MENU_RETURN_TO_MAIN=0

select_menu_entry() {
    local title="$1"
    local description="$2"
    local choice=""
    local menu_height=28
    local menu_width=90
    local menu_list_height=15
    local terminal_rows=""
    local terminal_columns=""

    shift 2

    if [[ -t 0 && -t 2 && -r "$DIALOGRC" ]] &&
       command -v dialog >/dev/null 2>&1; then
        terminal_rows="$(tput lines 2>/dev/null || true)"
        terminal_columns="$(tput cols 2>/dev/null || true)"

        if [[ "$terminal_rows" =~ ^[0-9]+$ &&
              "$terminal_columns" =~ ^[0-9]+$ ]] &&
           (( terminal_rows >= 16 && terminal_columns >= 50 )); then

            if (( menu_height > terminal_rows - 2 )); then
                menu_height="$(( terminal_rows - 2 ))"
            fi

            if (( menu_width > terminal_columns - 4 )); then
                menu_width="$(( terminal_columns - 4 ))"
            fi

            if (( menu_list_height > menu_height - 10 )); then
                menu_list_height="$(( menu_height - 10 ))"
            fi
        else
            menu_height=0
            menu_width=0
            menu_list_height=0
        fi

        dialog_no_cursor \
            --clear \
            --title "$title" \
            --cancel-label "Zurück" \
            --menu "$description" \
            "$menu_height" "$menu_width" "$menu_list_height" \
            "$@" \
            3>&1 1>&2 2>&3

        return
    fi

    clear >&2 || true

    printf '%s\n%b\n\n' "$title" "$description" >&2

    while (( $# > 0 )); do
        printf '%s) %s\n' "$1" "$2" >&2
        shift 2
    done

    printf '\n' >&2

    read -r -p 'Auswahl: ' choice || return 1

    printf '%s\n' "$choice"
}

show_menu_notice() {
    local message="$1"

    if [[ -t 0 && -t 2 && -r "$DIALOGRC" ]] &&
       command -v dialog >/dev/null 2>&1; then
        dialog_no_cursor \
            --clear \
            --title "Custom Linux" \
            --ok-label "Zurück" \
            --msgbox "$message" \
            0 0 || true

        return 0
    fi

    warn "$message"

    pause_menu || true
}

run_menu_action() {
    local label="$1"
    local started="$SECONDS"
    local duration=0
    local result=0

    shift

    clear || true

    set +e

    (
        set -e
        "$@"
    )

    result="$?"

    set -e

    if (( result != 0 )); then
        warn "$label fehlgeschlagen. Exit-Code: $result"
    fi

    duration="$((SECONDS - started))"

    printf '\n[INFO] Dauer: %s Minute(n) und %s Sekunde(n).\n' \
        "$((duration / 60))" \
        "$((duration % 60))"

    pause_menu || true
}

confirm_menu_action() {
    local question="$1"
    local label="$2"

    shift 2

    clear || true

    if confirm_action "$question"; then
        run_menu_action "$label" "$@"
    else
        info "Vorgang abgebrochen."

        pause_menu || true
    fi
}

run_privileged() {
    if (( EUID == 0 )); then
        "$@"
    elif command -v sudo >/dev/null 2>&1; then
        sudo -- "$@"
    else
        warn "Für diese Aktion werden Root-Rechte und sudo benötigt."
        return 1
    fi
}

show_ipv4_addresses() {
    local addresses=""

    command -v ip >/dev/null 2>&1 || {
        warn "Der Netzwerkbefehl ip ist nicht verfügbar."
        return 1
    }

    addresses="$(ip -4 -br address show scope global)" || return 1

    printf 'IPv4-Adressen\n'
    printf '=============\n'

    printf '%s\n' \
        "${addresses:-Keine aktive IPv4-Adresse vorhanden.}"
}

show_system_overview() {
    local manifest="/usr/share/custom-linux/system-manifest.json"

    if [[ "$ENVIRONMENT" == "build" ]]; then
        manifest="$PROJECT_ROOT/archiso/releng/airootfs/usr/share/custom-linux/system-manifest.json"
    fi

    printf 'Custom Linux - Systemübersicht\n'
    printf '==============================\n\n'

    printf 'Umgebung: %s\n' "$ENVIRONMENT"
    printf 'Kernel: %s\n' "$(uname -r)"

    if [[ -r "$manifest" ]] &&
       command -v jq >/dev/null 2>&1; then
        jq -r '
            "Systemversion: \(.system_version)\nScript-Basis: \(.bundled_script_version)\nBuild-ID: \(.build_id)"
        ' "$manifest"
    fi

    if command -v lscpu >/dev/null 2>&1; then
        printf '\nCPU\n'
        printf '%s\n' '---'

        LC_ALL=C lscpu |
            awk -F: '
                /^Model name:/ {
                    sub(/^[[:space:]]+/, "", $2)
                    print $2
                }
            '
    fi

    if command -v free >/dev/null 2>&1; then
        printf '\nArbeitsspeicher\n'
        printf '%s\n' '---------------'

        free -h
    fi


    if command -v lspci >/dev/null 2>&1; then
        printf '\nGrafikgeräte\n'
        printf '%s\n' '------------'

        lspci |
            grep -Ei 'VGA|3D|Display' || true
    fi

    printf '\n'

    show_ipv4_addresses || true

    if command -v ip >/dev/null 2>&1; then
        printf '\nMAC-Adressen\n'
        printf '%s\n' '------------'

        ip -br link show |
            awk '
                $1 != "lo" {
                    printf "%-16s %s\n", $1, $3
                }
            ' || true
    fi
}

show_ssh_status() {
    local active=""
    local enabled=""
    local address=""
    local login_user="${SUDO_USER:-${USER:-root}}"

    printf 'Custom Linux - SSH-Status\n'
    printf '=========================\n\n'

    if command -v pacman >/dev/null 2>&1 &&
       pacman -Q openssh >/dev/null 2>&1; then
        printf 'OpenSSH-Paket: installiert\n'
    else
        printf 'OpenSSH-Paket: nicht installiert oder nicht prüfbar\n'
    fi

    if command -v systemctl >/dev/null 2>&1; then
        active="$(
            systemctl is-active sshd 2>/dev/null || true
        )"

        enabled="$(
            systemctl is-enabled sshd 2>/dev/null || true
        )"

        printf 'SSH-Dienst: %s\n' \
            "${active:-unbekannt}"

        printf 'Autostart: %s\n' \
            "${enabled:-unbekannt}"
    fi

    printf '\n'

    show_ipv4_addresses || true

    if command -v ip >/dev/null 2>&1; then
        address="$(
            ip -4 -o address show scope global 2>/dev/null |
                awk '
                    NR == 1 {
                        sub(/\/.*/, "", $4)
                        print $4
                    }
                ' || true
        )"
    fi

    if [[ "$ENVIRONMENT" == "live" ]]; then
        login_user="root"
    fi

    if [[ -n "$address" ]]; then
        printf '\nVerbindungsbefehl:\n'
        printf 'ssh %s@%s\n' "$login_user" "$address"
    fi

    if command -v ss >/dev/null 2>&1; then
        printf '\nSSH-Port 22\n'
        printf '%s\n' '-----------'

        ss -ltn 'sport = :22' 2>/dev/null || true
    fi
}

enable_and_start_ssh() {
    command -v pacman >/dev/null 2>&1 || {
        warn "Der Paketmanager pacman wurde nicht gefunden."
        return 1
    }

    command -v systemctl >/dev/null 2>&1 || {
        warn "systemctl ist nicht verfügbar."
        return 1
    }

    if pacman -Q openssh >/dev/null 2>&1; then
        info "OpenSSH ist bereits installiert."
    else
        if ! confirm_action \
            "OpenSSH jetzt über pacman installieren?"; then
            warn "OpenSSH-Installation wurde abgebrochen."
            return 1
        fi

        run_privileged \
            pacman -S --needed openssh || return 1

        pacman -Q openssh >/dev/null 2>&1 || return 1
    fi

    info "Aktiviere und starte den SSH-Dienst."

    run_privileged \
        systemctl enable --now sshd || return 1

    systemctl is-active --quiet sshd || return 1

    info "SSH-Dienst wurde erfolgreich aktiviert und gestartet."

    printf '\n'

    show_ssh_status
}

run_live_menu_script() {
    [[ "$ENVIRONMENT" == "live" ]] || {
        warn "Diese Aktion ist nur im Live-System verfügbar."
        return 1
    }

    run_live_script "$@"
}

run_installed_menu_script() {
    [[ "$ENVIRONMENT" == "installed" ]] || {
        warn "Diese Aktion ist nur im installierten System verfügbar."
        return 1
    }

    run_installed_script "$@"
}

run_installed_inir_setup() {
    local setup_script="$SCRIPT_DIR/03-postinstall-setup.sh"
    local normal_marker="$HOME/.local/state/custom-linux/postinstall-setup.ok"

    [[ "$ENVIRONMENT" == "installed" ]] || {
        warn "iNiR kann nur im installierten System eingerichtet werden."
        return 1
    }

    [[ -f "$normal_marker" ]] || {
        warn "Das normale Postinstall-Setup ist noch nicht vollständig."
        warn "iNiR wird deshalb noch nicht gestartet."
        return 1
    }

    [[ -x "$setup_script" ]] || {
        warn "Postinstall-Skript fehlt oder ist nicht ausführbar:"
        warn "$setup_script"
        return 1
    }

    env CUSTOM_LINUX_INSTALL_INIR=1 "$setup_script"
}

run_safe_updater() {
    [[ "$ENVIRONMENT" == "live" ||
       "$ENVIRONMENT" == "installed" ]] || {
        warn "Script-Updates sind nur im Live-System oder installierten System verfügbar."
        return 1
    }

    run_updater "$@"
}

show_iso_files() {
    local directory="$PROJECT_ROOT/iso"

    [[ -d "$directory" ]] || {
        warn "ISO-Verzeichnis existiert nicht: $directory"
        return 1
    }

    find "$directory" \
        -maxdepth 2 \
        -type f \
        -name '*.iso' \
        -printf '%TY-%Tm-%Td %TH:%TM  %10s Byte  %P\n' |
        sort
}

open_git_menu() {
    local git_script=""

    [[ -n "$PROJECT_ROOT" ]] || {
        warn "Das Git-Menü benötigt ein vorhandenes Custom-Linux-Projekt."
        return 1
    }

    git_script="$PROJECT_ROOT/archiso/releng/airootfs/root/custom-linux/custom-git.sh"

    [[ -x "$git_script" ]] || {
        warn "Das Git-Menü ist nicht vorhanden oder nicht ausführbar."
        return 1
    }

    run_custom_git || return 1

    MENU_RETURN_TO_MAIN=1
}

show_section_menu() {
    local section="$1"
    local title=""
    local description="Umgebung: $ENVIRONMENT\n\nAktion auswählen:"
    local choice=""
    local version=""
    local desired_section=""
    local -a items=()

    if [[ "$section" == "installed" ]]; then
        if [[ ! -f /var/lib/custom-linux/postinstall-test.ok ]]; then
            section="installed-test"
        elif [[ ! -f "$HOME/.local/state/custom-linux/postinstall-setup.ok" ]]; then
            section="installed-setup"
        fi
    fi

    case "$section" in
        main)
            title="Custom Linux - Menüauswahl"

            items=(
                1 "Entwicklungs-/Build-Menü"
                2 "Live-/Installationsmenü"
                3 "Installiertes-System-Menü"
                4 "Script-Updates"
                5 "Git-Menü öffnen"
                6 "Systemübersicht anzeigen"
                7 "IPv4-Adressen anzeigen"
                8 "SSH-Verwaltung öffnen"
                0 "Beenden"
            )
            ;;

        build)
            title="Custom Linux - Entwicklungsmenü"

            items=(
                1 "Alle Skripte prüfen"
                2 "Git-Menü öffnen"
                3 "Git-Status anzeigen"
                4 "Vorhandene ISO-Dateien anzeigen"
                5 "Neue ISO bauen"
                6 "Systemübersicht anzeigen"
                7 "IPv4-Adressen anzeigen"
                8 "SSH-Verwaltung öffnen"
                H "Zurück zur Menüauswahl"
                0 "Zurück"
            )
            ;;

        live)
            title="Custom Linux - Installation"

            items=(
                1 "Archinstall starten"
                2 "Archinstall-Konfiguration auf Ventoy speichern"
                3 "Installation nur vorprüfen"
                4 "Postinstall-Dateien ins Zielsystem kopieren"
                0 "Beenden"
            )
            ;;

        installed-test)
            title="Custom Linux - Postinstall-Test"
            description="Der Postinstall-Test ist noch offen.\n\nAktion auswählen:"

            items=(
                1 "Postinstall-Test starten"
                2 "Installationsstatus anzeigen"
                3 "Script-Updates"
                0 "Beenden"
            )
            ;;

        installed-setup)
            title="Custom Linux - Programme einrichten"
            description="Die Programminstallation ist noch nicht vollständig.\n\nAktion auswählen:"

            items=(
                1 "Programme installieren oder fortsetzen"
                2 "Installationsstatus anzeigen"
                3 "Script-Updates"
                0 "Beenden"
            )
            ;;

        installed)
            title="Custom Linux - Installiertes System"
            description="Die normale Einrichtung ist abgeschlossen.\n\nAktion auswählen:"

            items=(
                1 "Programme prüfen oder ergänzen"
                I "iNiR installieren oder prüfen"
                2 "Installationsstatus anzeigen"
                3 "Script-Updates"
                4 "Systemübersicht anzeigen"
                5 "IPv4-Adressen anzeigen"
                6 "SSH-Verwaltung öffnen"
                G "Git-Menü öffnen"
                0 "Beenden"
            )
            ;;

        update)
            title="Custom Linux - Script-Updates"

            items=(
                1 "Auf Updates prüfen"
                2 "Neueste stabile Script-Version installieren"
                3 "Installierte Versionen anzeigen"
                4 "Andere installierte Version auswählen"
                5 "Rollback auf vorherige Version"
                6 "ISO-/System-Basisversion wiederherstellen"
                H "Zurück zur Menüauswahl"
                0 "Zurück"
            )
            ;;

        ssh)
            title="Custom Linux - SSH-Verwaltung"

            items=(
                1 "SSH-Status und Verbindungsbefehl anzeigen"
                2 "OpenSSH prüfen, SSH aktivieren und starten"
                3 "IPv4-Adressen anzeigen"
                4 "Systemübersicht anzeigen"
                H "Zurück zur Menüauswahl"
                0 "Zurück"
            )
            ;;
    esac

    while true; do
        if [[ "$section" == "main" ]]; then
            MENU_RETURN_TO_MAIN=0
        fi

        if ! choice="$(
            select_menu_entry \
                "$title" \
                "$description" \
                "${items[@]}"
        )"; then
            return 0
        fi

        case "$section:$choice" in
            main:1)
                show_section_menu build
                ;;

            main:2)
                show_section_menu live
                ;;

            main:3)
                show_section_menu installed
                ;;

            main:4|live:5|installed-test:3|installed-setup:3|installed:3)
                show_section_menu update
                ;;

            main:5|build:2|installed:G|installed:g)
                if ! open_git_menu; then
                    show_menu_notice \
                        "Das Git-Menü konnte nicht geöffnet werden."
                fi
                ;;

            main:6|build:6|live:6|installed:4|ssh:4)
                run_menu_action \
                    "Systemübersicht" \
                    show_system_overview
                ;;

            main:7|build:7|live:7|installed:5|ssh:3)
                run_menu_action \
                    "IPv4-Adressen" \
                    show_ipv4_addresses
                ;;

            main:8|build:8|live:8|installed:6)
                show_section_menu ssh
                ;;

            build:1)
                run_menu_action \
                    "Skriptprüfung" \
                    check_project_scripts
                ;;

            build:3)
                run_menu_action \
                    "Git-Status" \
                    show_git_status
                ;;

            build:4)
                run_menu_action \
                    "ISO-Dateien" \
                    show_iso_files
                ;;

            build:5)
                run_menu_action \
                    "ISO-Build" \
                    build_iso
                ;;

            live:1)
                run_menu_action \
                    "Archinstall" \
                    run_live_menu_script \
                    start-archinstall.sh
                ;;

            live:2)
                run_menu_action \
                    "Archinstall-Konfiguration" \
                    run_live_menu_script \
                    save-archinstall-config.sh
                ;;

            live:3)
                run_menu_action \
                    "Installationsvorprüfung" \
                    run_live_menu_script \
                    01-preflight-copy.sh
                ;;

            live:4)
                confirm_menu_action \
                    "Dateien kopieren und Zielsystem konfigurieren?" \
                    "Dateien kopieren" \
                    run_live_menu_script \
                    01-preflight-copy.sh \
                    --copy
                ;;

            installed-test:1)
                run_menu_action \
                    "Postinstall-Test" \
                    run_installed_menu_script \
                    02-postinstall-test.sh
                ;;

            installed-setup:1|installed:1)
                confirm_menu_action \
                    "Fehlende Programme jetzt installieren oder ergänzen?" \
                    "Postinstall-Setup" \
                    run_installed_menu_script \
                    03-postinstall-setup.sh
                ;;

            installed:I|installed:i)
                confirm_menu_action \
                    "iNiR jetzt separat installieren oder prüfen?" \
                    "iNiR" \
                    run_installed_inir_setup
                ;;

            installed-test:2|installed-setup:2|installed:2)
                run_menu_action \
                    "Installationsstatus" \
                    show_installed_status
                ;;

            update:1)
                run_menu_action \
                    "Update-Prüfung" \
                    run_safe_updater \
                    check stable
                ;;

            update:2)
                confirm_menu_action \
                    "Neueste stabile Script-Version installieren?" \
                    "Script-Update" \
                    run_safe_updater \
                    update stable
                ;;

            update:3)
                run_menu_action \
                    "Versionsanzeige" \
                    run_safe_updater \
                    versions
                ;;

            update:4)
                read -r \
                    -p 'Installierte Version eingeben: ' \
                    version || continue

                if [[ -z "$version" ]]; then
                    show_menu_notice \
                        "Keine Version angegeben."
                else
                    confirm_menu_action \
                        "Script-Version $version aktivieren?" \
                        "Versionswechsel" \
                        run_safe_updater \
                        rollback "$version"
                fi
                ;;

            update:5)
                confirm_menu_action \
                    "Auf die vorherige Version zurückrollen?" \
                    "Rollback" \
                    run_safe_updater \
                    rollback
                ;;

            update:6)
                confirm_menu_action \
                    "ISO-/System-Basisversion wiederherstellen?" \
                    "Basiswiederherstellung" \
                    run_safe_updater \
                    restore-bundled
                ;;

            ssh:1)
                run_menu_action \
                    "SSH-Status" \
                    show_ssh_status
                ;;

            ssh:2)
                confirm_menu_action \
                    "OpenSSH prüfen und den SSH-Dienst aktivieren sowie starten?" \
                    "SSH aktivieren" \
                    enable_and_start_ssh
                ;;

            *:H|*:h)
                MENU_RETURN_TO_MAIN=1
                return 0
                ;;

            *:0)
                return 0
                ;;

            *)
                show_menu_notice \
                    "Ungültige Auswahl: $choice"
                ;;
        esac

        if [[ "$ENVIRONMENT" == "installed" &&
              "$section" == installed* ]]; then
            desired_section="installed"

            if [[ ! -f /var/lib/custom-linux/postinstall-test.ok ]]; then
                desired_section="installed-test"
            elif [[ ! -f "$HOME/.local/state/custom-linux/postinstall-setup.ok" ]]; then
                desired_section="installed-setup"
            fi

            if [[ "$desired_section" != "$section" ]]; then
                show_section_menu installed
                return 0
            fi
        fi

        if (( MENU_RETURN_TO_MAIN != 0 )) &&
           [[ "$section" != "main" ]]; then
            return 0
        fi
    done
}

show_update_menu() {
    show_section_menu update
}

show_build_menu() {
    show_section_menu build
}

show_live_menu() {
    show_section_menu live
}

show_installed_menu() {
    show_section_menu installed
}

show_ssh_menu() {
    show_section_menu ssh
}

show_main_menu() {
    case "$ENVIRONMENT" in
        build)
            show_section_menu build
            ;;

        live)
            show_section_menu live
            ;;

        installed)
            show_section_menu installed
            ;;

        *)
            show_section_menu main
            ;;
    esac
}

main() {
    local command="${1:-menu}"

    detect_environment

    case "$command" in
        menu|main)
            show_main_menu
            ;;

        update)
            show_update_menu
            ;;

        build)
            show_build_menu
            ;;

        live)
            show_live_menu
            ;;

        installed)
            show_installed_menu
            ;;

        ssh)
            show_ssh_menu
            ;;

        ip)
            show_ipv4_addresses
            ;;

        info|status)
            show_system_overview
            ;;

        git)
            open_git_menu
            ;;

        self-test|--self-test)
            run_self_test
            ;;

        *)
            fail "Unbekannter Aufruf: $command. Möglich: menu, update, build, live, installed, ssh, ip, info, git, self-test"
            ;;
    esac
}

main "$@"
