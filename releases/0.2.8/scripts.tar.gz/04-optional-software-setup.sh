#!/usr/bin/env bash

# 04-optional-software-setup.sh
#
# Aufgabe:
# - Wird im installierten Custom-Linux-System als normaler Benutzer gestartet.
# - Zeigt optionale Programme mit ihrem aktuellen Installationsstatus an.
# - Die Auswahl erfolgt im Dialog-Menü mit Leertaste und wird vor der
#   Installation nochmals als Kontrollliste angezeigt.
# - Prüft jedes ausgewählte Programm unmittelbar vor und nach der Installation.
# - Speichert Versuchszähler und eigene Fehlerprotokolle unter
#   ~/.local/state/custom-linux/optional-software/.
#
# Rechte und Sicherheit:
# - Das Skript selbst darf nicht mit sudo gestartet werden.
# - Nur pacman, systemctl und usermod erhalten bei Bedarf über sudo Root-Rechte.
# - Eine leere, abgebrochene oder nicht bestätigte Auswahl verändert nichts.
# - Ein fehlgeschlagenes optionales Programm kann nach zehn Sekunden automatisch
#   übersprungen und bei einem späteren Aufruf erneut ausgewählt werden.
#
# Dieser erste Ausbau enthält die Programme, die bisher gemeinsam über die
# Pacman-Basisliste installiert werden. Weitere Kategorien und Installationsarten
# werden nach getrennten Paket- und Funktionstests ergänzt.

set -Eeuo pipefail
IFS=$'\n\t'

STATE_DIR="$HOME/.local/state/custom-linux/optional-software"
LOG_DIR="$STATE_DIR/logs"
DIALOGRC_FILE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/custom-dialogrc"

dialog_no_cursor() (
    trap 'tput cnorm 2>/dev/null || true' EXIT INT TERM HUP
    tput civis 2>/dev/null || true
    DIALOGRC="$DIALOGRC_FILE" command dialog "$@"
)


POWERSHELL_VERSION="7.6.5"
POWERSHELL_ARCHIVE="powershell-${POWERSHELL_VERSION}-linux-x64.tar.gz"
POWERSHELL_URL="https://github.com/PowerShell/PowerShell/releases/download/v${POWERSHELL_VERSION}/${POWERSHELL_ARCHIVE}"
POWERSHELL_SHA256="b34ab3b19acac1d3d4d0d3cfdb02acf62f457b0b6a962ff008132033f7566844"
POWERSHELL_INSTALL_DIRECTORY="/opt/microsoft/powershell/$POWERSHELL_VERSION"
POWERSHELL_LINK="/usr/local/bin/pwsh"
POWERSHELL_VERSION_QUERY="\$PSVersionTable.PSVersion.ToString()"

XAMPP_VERSION="8.2.12-0"
XAMPP_URL="https://sourceforge.net/projects/xampp/files/XAMPP%20Linux/8.2.12/xampp-linux-x64-8.2.12-0-installer.run/download"
XAMPP_SHA256="df0774e7a6d0d0754a5f0132015411234b5f953df2365b693d3758fc35a30374"

VSCODE_AUR_REPOSITORY="https://aur.archlinux.org/visual-studio-code-bin.git"
VSCODE_AUR_COMMIT="69b361eca02a84aa97c43c885e23d463eec96770"
VSCODE_PKGBUILD_SHA256="5126484b61d9a5aea86ab4f028d0ab973f2250c9cb5db5c820ae603a012d6898"
VSCODE_SRCINFO_SHA256="ea5b46738af95b1281f7e76a4ab215beb6a2ee7d07c62d2f3cd5d2fe6baf75cb"

ARDUINO_IDE_AUR_REPOSITORY="https://aur.archlinux.org/arduino-ide-bin.git"
ARDUINO_IDE_AUR_COMMIT="78ca53e1cd1b9fd1ce73b3d8b246a6900fd5ac50"
ARDUINO_IDE_PKGBUILD_SHA256="0ba571f25f0ace1f7f29552af9b85f46415b60cd0dc770a82b2c61965d5540b1"
ARDUINO_IDE_SRCINFO_SHA256="5161a6fec4309781484ac6c85279a253e0a4363b12eba7a8048a91ffbe3707f5"

ARDUINO_UDEV_RULES_FILE="/etc/udev/rules.d/60-custom-linux-arduino.rules"
ARDUINO_UDEV_RULES_SHA256="4b5f40892e81f8c2107c7a449e97f7eea0420d5a87ac6614492dfa152d48373f"

declare -a PROGRAM_IDS=(
    obsidian
    element
    discord
    prismlauncher
    mysql-workbench
    docker
    brave
    powershell
    vscode
    arduino
    xampp
)

declare -A PROGRAM_LABELS=(
    [obsidian]="Obsidian"
    [element]="Element"
    [discord]="Discord"
    [prismlauncher]="PrismLauncher"
    [mysql-workbench]="MySQL Workbench"
    [docker]="Docker mit Docker Compose"
    [brave]="Brave Browser"
    [powershell]="PowerShell 7.6.5"
    [vscode]="Visual Studio Code"
    [arduino]="Arduino IDE mit udev-Regeln"
    [xampp]="XAMPP"
)

# Für die späteren gruppierten Programmuntermenüs vorbereitete Metadaten.
# shellcheck disable=SC2034
declare -A PROGRAM_CATEGORIES=(
    [obsidian]="Schule und Organisation"
    [element]="Private Programme"
    [discord]="Private Programme"
    [prismlauncher]="Private Programme"
    [mysql-workbench]="Schule und Entwicklung"
    [docker]="Schule und Entwicklung"
    [brave]="Browser"
    [powershell]="Schule und Administration"
    [vscode]="Schule und Entwicklung"
    [arduino]="Schule und Entwicklung"
    [xampp]="Schule und Entwicklung"
)

declare -A PROGRAM_DESCRIPTIONS=(
    [obsidian]="Notizen und Wissensverwaltung"
    [element]="Matrix-Messenger"
    [discord]="Sprach- und Textchat"
    [prismlauncher]="Minecraft-Launcher"
    [mysql-workbench]="Grafische MySQL-Verwaltung"
    [docker]="Container-Laufzeit und Compose-Werkzeug"
    [brave]="Zusätzlicher Webbrowser"
    [powershell]="PowerShell für Administration und Schule"
    [vscode]="Code-Editor und Entwicklungsumgebung"
    [arduino]="Arduino IDE einschließlich Gerätezugriffsregeln"
    [xampp]="Lokale Apache-, MariaDB- und PHP-Umgebung"
)

declare -a SELECTED_PROGRAMS=()
declare -a INSTALLED_PROGRAMS=()
declare -a ALREADY_INSTALLED_PROGRAMS=()
declare -a FAILED_PROGRAMS=()
declare -a NOT_SELECTED_PROGRAMS=()

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

find_aur_helper() {
    local helper=""

    for helper in paru pikaur yay; do
        if command -v "$helper" >/dev/null 2>&1; then
            printf '%s\n' "$helper"
            return 0
        fi
    done

    return 1
}

install_brave() {
    local aur_helper=""

    aur_helper="$(find_aur_helper)" ||
        fail "Brave benötigt unter Arch einen AUR-Helfer."

    info "Installiere brave-bin mit dem vorhandenen AUR-Helfer: $aur_helper"

    "$aur_helper" \
        --sync \
        --needed \
        --noconfirm \
        brave-bin

    check_brave_complete ||
        fail "brave-bin wurde installiert, aber Brave wurde nicht gefunden."

    info "Brave-Installationsschritt abgeschlossen."
}

install_powershell() {
    local archive_file=""
    local extraction_directory=""
    local actual_hash=""
    local installed_version=""

    [[ "$(uname -m)" == "x86_64" ]] ||
        fail "Das vorbereitete PowerShell-Archiv unterstützt nur x86_64."

    if check_powershell_complete; then
        info "PowerShell $POWERSHELL_VERSION ist bereits vollständig vorhanden."
        return 0
    fi

    if [[ -x "$POWERSHELL_INSTALL_DIRECTORY/pwsh" ]]; then
        installed_version="$(
            "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
                -NoLogo \
                -NoProfile \
                -Command "$POWERSHELL_VERSION_QUERY" 2>/dev/null ||
                true
        )"

        if [[ "$installed_version" == "$POWERSHELL_VERSION" ]]; then
            if [[ -e "$POWERSHELL_LINK" && ! -L "$POWERSHELL_LINK" ]]; then
                fail "Der PowerShell-Linkpfad ist durch eine normale Datei belegt:
$POWERSHELL_LINK"
            fi

            sudo ln -sfn \
                "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
                "$POWERSHELL_LINK"

            info "Vorhandene PowerShell-Installation wurde wieder verknüpft."
            return 0
        fi
    fi

    archive_file="$(
        mktemp "$STATE_DIR/powershell-${POWERSHELL_VERSION}.XXXXXX.tar.gz"
    )"

    extraction_directory="$(
        mktemp -d "$STATE_DIR/powershell-extract.XXXXXX"
    )"

    (
        trap 'rm -f -- "$archive_file"; rm -rf -- "$extraction_directory"' EXIT

        info "Lade das offizielle PowerShell-$POWERSHELL_VERSION-Archiv."

        curl \
            --fail \
            --location \
            --show-error \
            --output "$archive_file" \
            "$POWERSHELL_URL"

        actual_hash="$(
            sha256sum "$archive_file" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$POWERSHELL_SHA256" ]] ||
            fail "Die PowerShell-Prüfsumme stimmt nicht.

Erwartet: $POWERSHELL_SHA256
Gefunden: $actual_hash"

        info "PowerShell-Archiv wurde erfolgreich per SHA-256 geprüft."

        tar \
            --extract \
            --gzip \
            --file "$archive_file" \
            --directory "$extraction_directory"

        [[ -f "$extraction_directory/pwsh" ]] ||
            fail "Das PowerShell-Archiv enthält keine pwsh-Datei."

        if [[ -e "$POWERSHELL_INSTALL_DIRECTORY" &&
              ! -d "$POWERSHELL_INSTALL_DIRECTORY" ]]; then
            fail "Der PowerShell-Zielpfad ist kein Verzeichnis:
$POWERSHELL_INSTALL_DIRECTORY"
        fi

        info "Ersetze ausschließlich das Ziel dieser PowerShell-Version:"
        info "$POWERSHELL_INSTALL_DIRECTORY"

        sudo rm -rf -- "$POWERSHELL_INSTALL_DIRECTORY"

        sudo install \
            -d \
            -m 0755 \
            "$POWERSHELL_INSTALL_DIRECTORY"

        sudo cp -a \
            "$extraction_directory/." \
            "$POWERSHELL_INSTALL_DIRECTORY/"

        sudo chmod 0755 "$POWERSHELL_INSTALL_DIRECTORY/pwsh"

        if [[ -e "$POWERSHELL_LINK" && ! -L "$POWERSHELL_LINK" ]]; then
            fail "Der PowerShell-Linkpfad ist durch eine normale Datei belegt:
$POWERSHELL_LINK"
        fi

        sudo ln -sfn \
            "$POWERSHELL_INSTALL_DIRECTORY/pwsh" \
            "$POWERSHELL_LINK"
    )

    check_powershell_complete ||
        fail "PowerShell wurde installiert, aber Version $POWERSHELL_VERSION konnte nicht bestätigt werden."

    installed_version="$(
        pwsh \
            -NoLogo \
            -NoProfile \
            -Command "$POWERSHELL_VERSION_QUERY"
    )"

    info "PowerShell wurde erfolgreich installiert: $installed_version"
}

install_pinned_aur_package() {
    local label="$1"
    local package_name="$2"
    local repository_url="$3"
    local expected_commit="$4"
    local expected_pkgbuild_hash="$5"
    local expected_srcinfo_hash="$6"
    local source_directory=""
    local actual_commit=""
    local actual_pkgbuild_hash=""
    local actual_srcinfo_hash=""

    if pacman -Q "$package_name" >/dev/null 2>&1; then
        info "$label ist bereits als Paket installiert: $package_name"
        return 0
    fi

    source_directory="$(
        mktemp -d "$STATE_DIR/${package_name}-build.XXXXXX"
    )"

    (
        trap 'rm -rf -- "$source_directory"' EXIT

        info "Lade die festgelegte AUR-Paketdefinition: $package_name"

        git clone \
            "$repository_url" \
            "$source_directory"

        git -C "$source_directory" \
            checkout \
            --detach \
            "$expected_commit"

        actual_commit="$(
            git -C "$source_directory" rev-parse HEAD
        )"

        [[ "$actual_commit" == "$expected_commit" ]] ||
            fail "Der AUR-Commit für $package_name stimmt nicht.

Erwartet: $expected_commit
Gefunden: $actual_commit"

        actual_pkgbuild_hash="$(
            sha256sum "$source_directory/PKGBUILD" |
                awk '{print $1}'
        )"

        [[ "$actual_pkgbuild_hash" == "$expected_pkgbuild_hash" ]] ||
            fail "Die PKGBUILD-Prüfsumme für $package_name stimmt nicht.

Erwartet: $expected_pkgbuild_hash
Gefunden: $actual_pkgbuild_hash"

        actual_srcinfo_hash="$(
            sha256sum "$source_directory/.SRCINFO" |
                awk '{print $1}'
        )"

        [[ "$actual_srcinfo_hash" == "$expected_srcinfo_hash" ]] ||
            fail "Die .SRCINFO-Prüfsumme für $package_name stimmt nicht.

Erwartet: $expected_srcinfo_hash
Gefunden: $actual_srcinfo_hash"

        info "AUR-Commit und Paketdefinition wurden geprüft."

        cd "$source_directory"

        makepkg \
            --syncdeps \
            --install \
            --needed \
            --noconfirm
    )

    pacman -Q "$package_name" >/dev/null 2>&1 ||
        fail "$label wurde nicht als Paket installiert: $package_name"

    info "$label wurde erfolgreich installiert."
}

install_vscode() {
    install_pinned_aur_package \
        "Microsoft Visual Studio Code" \
        visual-studio-code-bin \
        "$VSCODE_AUR_REPOSITORY" \
        "$VSCODE_AUR_COMMIT" \
        "$VSCODE_PKGBUILD_SHA256" \
        "$VSCODE_SRCINFO_SHA256"

    check_vscode_complete ||
        fail "Microsoft Visual Studio Code wurde installiert, aber 'code' fehlt."
}

install_arduino_ide() {
    install_pinned_aur_package \
        "Arduino IDE" \
        arduino-ide-bin \
        "$ARDUINO_IDE_AUR_REPOSITORY" \
        "$ARDUINO_IDE_AUR_COMMIT" \
        "$ARDUINO_IDE_PKGBUILD_SHA256" \
        "$ARDUINO_IDE_SRCINFO_SHA256"

    check_arduino_ide_complete ||
        fail "Arduino IDE wurde installiert, aber 'arduino-ide' fehlt."
}

configure_arduino_udev() {
    local temporary_rules=""
    local actual_hash=""

    command -v udevadm >/dev/null 2>&1 ||
        fail "udevadm wurde nicht gefunden."

    temporary_rules="$(
        mktemp "$STATE_DIR/arduino-udev-rules.XXXXXX"
    )"

    (
        trap 'rm -f -- "$temporary_rules"' EXIT

        cat > "$temporary_rules" <<'ARDUINO_UDEV_RULES'
# Custom Linux - Arduino udev rules
# Based on the official Arduino unified rules retrieved on 2026-09-02.

SUBSYSTEMS=="usb", ATTRS{idVendor}=="2341", MODE="0660", TAG+="uaccess"
SUBSYSTEMS=="tty", ENV{ID_REVISION}=="03eb", ENV{ID_MODEL_ID}=="2145", MODE="0660", TAG+="uaccess", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_CANDIDATE}="0"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="03eb", ATTRS{idProduct}=="2145", MODE="0660", TAG+="uaccess", ENV{ID_MM_DEVICE_IGNORE}="1"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="05c6", ATTRS{idProduct}=="9008", MODE="0660", TAG+="uaccess"
ACTION!="add|change", GOTO="custom_linux_openocd_rules_end"
SUBSYSTEM!="usb|tty|hidraw", GOTO="custom_linux_openocd_rules_end"
ATTRS{product}=="*CMSIS-DAP*", MODE="0660", TAG+="uaccess"
LABEL="custom_linux_openocd_rules_end"
ARDUINO_UDEV_RULES

        actual_hash="$(
            sha256sum "$temporary_rules" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$ARDUINO_UDEV_RULES_SHA256" ]] ||
            fail "Die erzeugten Arduino-udev-Regeln stimmen nicht.

Erwartet: $ARDUINO_UDEV_RULES_SHA256
Gefunden: $actual_hash"

        info "Die eingebetteten Arduino-udev-Regeln wurden per SHA-256 geprüft."
        info "Installiere ausschließlich die verwaltete Custom-Linux-Regeldatei:"
        info "$ARDUINO_UDEV_RULES_FILE"

        sudo install \
            --directory \
            --mode 0755 \
            /etc/udev/rules.d

        sudo install \
            --mode 0644 \
            --owner root \
            --group root \
            -- \
            "$temporary_rules" \
            "$ARDUINO_UDEV_RULES_FILE"

        sudo udevadm control --reload-rules
    )

    check_arduino_udev_complete ||
        fail "Die verwalteten Arduino-udev-Regeln konnten nicht bestätigt werden."

    info "Arduino-udev-Regeln wurden eingerichtet."
    info "Ein angeschlossenes Arduino-Board bitte einmal aus- und wieder einstecken."
}

install_xampp() {
    local installer=""
    local actual_hash=""

    if check_xampp_complete; then
        info "Eine vorhandene XAMPP-Installation wurde erkannt."
        info "XAMPP wird nicht erneut installiert."
        return 0
    fi

    installer="$(
        mktemp "$STATE_DIR/xampp-${XAMPP_VERSION}.XXXXXX.run"
    )"

    (
        trap 'rm -f -- "$installer"' EXIT

        info "Lade XAMPP $XAMPP_VERSION vom festgelegten offiziellen Download."

        curl \
            --fail \
            --location \
            --show-error \
            --output "$installer" \
            "$XAMPP_URL"

        actual_hash="$(
            sha256sum "$installer" |
                awk '{print $1}'
        )"

        [[ "$actual_hash" == "$XAMPP_SHA256" ]] ||
            fail "Die SHA-256-Prüfsumme des XAMPP-Installers stimmt nicht.

Erwartet: $XAMPP_SHA256
Gefunden: $actual_hash"

        info "Der XAMPP-Installer wurde erfolgreich per SHA-256 geprüft."

        chmod 0755 "$installer"

        info "Installiere XAMPP ohne zusätzliche Installationsdialoge."

        sudo "$installer" \
            --mode unattended \
            --unattendedmodeui none \
            --installer-language de
    )

    check_xampp_complete ||
        fail "XAMPP wurde ausgeführt, aber /opt/lampp/lampp wurde nicht gefunden."

    info "XAMPP $XAMPP_VERSION wurde erfolgreich installiert."
}

check_brave_complete() {
    command -v brave-browser >/dev/null 2>&1 ||
        command -v brave >/dev/null 2>&1
}

check_powershell_complete() {
    local command_path=""
    local installed_version=""

    command_path="$(command -v pwsh 2>/dev/null)" ||
        return 1

    installed_version="$(
        "$command_path" \
            -NoLogo \
            -NoProfile \
            -Command "$POWERSHELL_VERSION_QUERY" 2>/dev/null
    )" || return 1

    [[ "$installed_version" == "$POWERSHELL_VERSION" ]]
}

check_vscode_complete() {
    pacman -Q visual-studio-code-bin >/dev/null 2>&1 &&
        command -v code >/dev/null 2>&1
}

check_arduino_ide_complete() {
    pacman -Q arduino-ide-bin >/dev/null 2>&1 &&
        command -v arduino-ide >/dev/null 2>&1
}

check_arduino_udev_complete() {
    local actual_hash=""
    local ownership_and_mode=""

    [[ -f "$ARDUINO_UDEV_RULES_FILE" ]] ||
        return 1

    actual_hash="$(
        sha256sum "$ARDUINO_UDEV_RULES_FILE" 2>/dev/null |
            awk '{print $1}'
    )"

    [[ "$actual_hash" == "$ARDUINO_UDEV_RULES_SHA256" ]] ||
        return 1

    ownership_and_mode="$(
        stat \
            --format='%U:%G:%a' \
            "$ARDUINO_UDEV_RULES_FILE" \
            2>/dev/null
    )"

    [[ "$ownership_and_mode" == "root:root:644" ]]
}

check_xampp_complete() {
    [[ -x /opt/lampp/lampp ]]
}

program_packages() {
    case "$1" in
        obsidian)
            printf '%s\n' obsidian
            ;;
        element)
            printf '%s\n' element-desktop
            ;;
        discord)
            printf '%s\n' discord
            ;;
        prismlauncher)
            printf '%s\n' prismlauncher
            ;;
        mysql-workbench)
            printf '%s\n' mysql-workbench
            ;;
        docker)
            printf '%s\n' docker docker-compose
            ;;
        *)
            return 1
            ;;
    esac
}

program_is_installed() {
    local program_id="$1"
    local package=""
    local -a packages=()

    case "$program_id" in
        brave)
            check_brave_complete
            return
            ;;
        powershell)
            check_powershell_complete
            return
            ;;
        vscode)
            check_vscode_complete
            return
            ;;
        arduino)
            check_arduino_ide_complete &&
                check_arduino_udev_complete
            return
            ;;
        xampp)
            check_xampp_complete
            return
            ;;
    esac

    mapfile -t packages < <(
        program_packages "$program_id"
    ) || return 1

    ((${#packages[@]} > 0)) || return 1

    for package in "${packages[@]}"; do
        pacman -Q "$package" >/dev/null 2>&1 || return 1
    done

    if [[ "$program_id" == "docker" ]]; then
        command -v docker >/dev/null 2>&1 &&
            systemctl is-enabled docker.service >/dev/null 2>&1 &&
            id -nG "$USER" 2>/dev/null |
                tr ' ' '\n' |
                grep -qx docker
        return
    fi

    return 0
}

commands_are_available() {
    local command_name=""

    for command_name in "$@"; do
        if ! command -v "$command_name" >/dev/null 2>&1; then
            warn "Benötigter Befehl wurde nicht gefunden: $command_name"
            return 1
        fi
    done

    return 0
}

program_is_available() {
    local program_id="$1"
    local package=""
    local aur_helper=""
    local -a packages=()

    case "$program_id" in
        brave)
            aur_helper="$(find_aur_helper)" || {
                warn "Brave benötigt einen vorhandenen AUR-Helfer."
                return 1
            }

            info "Verfügbarer AUR-Helfer für Brave: $aur_helper"
            return 0
            ;;
        powershell)
            commands_are_available curl sha256sum tar
            return
            ;;
        vscode)
            commands_are_available git sha256sum makepkg pacman
            return
            ;;
        arduino)
            commands_are_available \
                git \
                sha256sum \
                makepkg \
                pacman \
                udevadm \
                install
            return
            ;;
        xampp)
            commands_are_available curl sha256sum chmod
            return
            ;;
    esac

    mapfile -t packages < <(
        program_packages "$program_id"
    ) || return 1

    for package in "${packages[@]}"; do
        pacman -Si "$package" >/dev/null 2>&1 || {
            warn \
                "Paket nicht in den aktiven Pacman-Repositories gefunden: $package"
            return 1
        }
    done

    return 0
}

read_failure_field() {
    local failure_file="$1"
    local field_name="$2"

    [[ -r "$failure_file" ]] || return 1

    awk \
        -F= \
        -v wanted="$field_name" \
        '
            $1 == wanted {
                sub(/^[^=]*=/, "")
                print
                exit
            }
        ' \
        "$failure_file"
}

log_matches() {
    local log_file="$1"
    local pattern="$2"

    [[ -r "$log_file" ]] || return 1

    LC_ALL=C grep \
        -E \
        -i \
        -q \
        -- \
        "$pattern" \
        "$log_file"
}

detect_failure_source() {
    local program_id="$1"
    local result="$2"
    local log_file="$3"
    local post_check_failed="${4:-0}"

    if (( post_check_failed != 0 )); then
        printf '%s\n' postcheck
        return 0
    fi

    if log_matches \
        "$log_file" \
        '\[TESTSPERRE\].*sudo.*blockiert'
    then
        printf '%s\n' test-lock
        return 0
    fi

    if log_matches \
        "$log_file" \
        'Prüfsumme.*stimmt nicht|checksum.*(failed|did not pass|mismatch)'
    then
        printf '%s\n' checksum
        return 0
    fi

    if log_matches "$log_file" 'curl: \([0-9]+\)'; then
        printf '%s\n' curl
        return 0
    fi

    if log_matches \
        "$log_file" \
        'unable to lock database|Datenbank.*nicht.*sperr|target not found|Ziel nicht gefunden|failed retrieving file|failed to commit transaction|Transaktion.*fehlgeschlagen|invalid or corrupted package|ungültiges oder beschädigtes Paket|conflicting files|Dateikonflikt'
    then
        printf '%s\n' pacman
        return 0
    fi

    if log_matches \
        "$log_file" \
        '==> (ERROR|FEHLER):|A failure occurred in build|Fehler beim Erstellen'
    then
        printf '%s\n' makepkg
        return 0
    fi

    if log_matches \
        "$log_file" \
        'fatal:|not a git repository|Authentication failed|Repository not found|pathspec .* did not match'
    then
        printf '%s\n' git
        return 0
    fi

    if log_matches \
        "$log_file" \
        'tar:|unexpected end of file|unexpected EOF|not in gzip format'
    then
        printf '%s\n' archive
        return 0
    fi

    if log_matches \
        "$log_file" \
        'Failed to enable unit|Failed to start|Unit .* not found|Einheit .* nicht gefunden|systemctl:'
    then
        printf '%s\n' systemd
        return 0
    fi

    if log_matches "$log_file" 'usermod:'; then
        printf '%s\n' usermod
        return 0
    fi

    if log_matches \
        "$log_file" \
        'sudo:|not in the sudoers|nicht in der sudoers'
    then
        printf '%s\n' sudo
        return 0
    fi

    case "$result" in
        126|127|130|137|139|141|143)
            printf '%s\n' shell
            return 0
            ;;
    esac

    case "$program_id" in
        obsidian|element|discord|prismlauncher|mysql-workbench|docker)
            printf '%s\n' pacman
            ;;
        brave)
            printf '%s\n' aur-helper
            ;;
        vscode|arduino)
            printf '%s\n' aur-build
            ;;
        powershell|xampp)
            printf '%s\n' installer
            ;;
        *)
            printf '%s\n' unknown
            ;;
    esac
}

failure_source_label() {
    case "$1" in
        pacman)
            printf '%s\n' pacman
            ;;
        curl)
            printf '%s\n' curl
            ;;
        git)
            printf '%s\n' git
            ;;
        makepkg)
            printf '%s\n' makepkg
            ;;
        aur-helper)
            printf '%s\n' AUR-Helfer
            ;;
        aur-build)
            printf '%s\n' AUR-Paketbau
            ;;
        checksum)
            printf '%s\n' SHA-256-Prüfung
            ;;
        archive)
            printf '%s\n' Archivverarbeitung
            ;;
        systemd)
            printf '%s\n' systemctl
            ;;
        usermod)
            printf '%s\n' Benutzergruppenverwaltung
            ;;
        sudo)
            printf '%s\n' sudo
            ;;
        installer)
            printf '%s\n' Installationsablauf
            ;;
        postcheck)
            printf '%s\n' Abschlussprüfung
            ;;
        test-lock)
            printf '%s\n' Testsperre
            ;;
        shell)
            printf '%s\n' Shell/Prozess
            ;;
        *)
            printf '%s\n' unbekannte Fehlerquelle
            ;;
    esac
}

failure_phase_text() {
    case "$1" in
        pacman)
            printf '%s\n' 'Paket aus Arch-Repositories installieren'
            ;;
        curl)
            printf '%s\n' 'Datei aus dem Internet herunterladen'
            ;;
        git)
            printf '%s\n' 'Git-Repository laden oder festgelegten Commit auschecken'
            ;;
        makepkg|aur-build)
            printf '%s\n' 'AUR-Paket prüfen, bauen und installieren'
            ;;
        aur-helper)
            printf '%s\n' 'AUR-Paket über einen vorhandenen Helfer installieren'
            ;;
        checksum)
            printf '%s\n' 'Heruntergeladene Datei oder Paketdefinition verifizieren'
            ;;
        archive)
            printf '%s\n' 'Heruntergeladenes Archiv entpacken'
            ;;
        systemd)
            printf '%s\n' 'Systemdienst einrichten'
            ;;
        usermod)
            printf '%s\n' 'Benutzer einer benötigten Gruppe hinzufügen'
            ;;
        sudo)
            printf '%s\n' 'Befehl mit Administratorrechten ausführen'
            ;;
        postcheck)
            printf '%s\n' 'Installation abschließend bestätigen'
            ;;
        test-lock)
            printf '%s\n' 'Sicherer Test ohne echte Installation'
            ;;
        shell)
            printf '%s\n' 'Installationsprozess ausführen'
            ;;
        *)
            printf '%s\n' 'Programminstallation ausführen'
            ;;
    esac
}

general_exit_code_meaning() {
    local result="$1"
    local signal_number=0
    local signal_name=""

    case "$result" in
        0)
            printf '%s\n' 'Der Befehl wurde erfolgreich abgeschlossen.'
            ;;
        1)
            printf '%s\n' 'Der Befehl meldete einen allgemeinen Fehler.'
            ;;
        2)
            printf '%s\n' 'Der Befehl meldete einen falschen Aufruf oder einen eigenen Fehlercode 2.'
            ;;
        126)
            printf '%s\n' 'Der Befehl wurde gefunden, konnte aber nicht ausgeführt werden.'
            ;;
        127)
            printf '%s\n' 'Der benötigte Befehl wurde nicht gefunden.'
            ;;
        130)
            printf '%s\n' 'Der Prozess wurde mit Strg+C unterbrochen.'
            ;;
        137)
            printf '%s\n' 'Der Prozess wurde gewaltsam beendet; möglich sind Speichermangel oder SIGKILL.'
            ;;
        139)
            printf '%s\n' 'Der Prozess wurde durch einen Speicherzugriffsfehler beendet.'
            ;;
        141)
            printf '%s\n' 'Eine Ausgabe-Pipeline wurde geschlossen; der Prozess erhielt SIGPIPE.'
            ;;
        143)
            printf '%s\n' 'Der Prozess wurde regulär durch SIGTERM beendet.'
            ;;
        255)
            printf '%s\n' 'Der Befehl meldete einen schweren oder nicht näher eingeordneten Fehler.'
            ;;
        *)
            if [[ "$result" =~ ^[0-9]+$ ]] &&
               (( result >= 129 && result <= 192 )); then
                signal_number=$((result - 128))
                signal_name="$(
                    kill -l "$signal_number" 2>/dev/null ||
                        true
                )"

                if [[ -n "$signal_name" ]]; then
                    printf \
                        'Der Prozess wurde durch das Signal %s beendet.' \
                        "$signal_name"
                    printf '\n'
                else
                    printf \
                        'Der Prozess wurde durch Linux-Signal %s beendet.\n' \
                        "$signal_number"
                fi
            else
                printf \
                    'Für diesen Exit-Code existiert keine eindeutige allgemeine Bedeutung.\n'
            fi
            ;;
    esac
}

curl_exit_code_meaning() {
    case "$1" in
        1)
            printf '%s\n' 'Das verwendete Netzwerkprotokoll wird von curl nicht unterstützt.'
            ;;
        2)
            printf '%s\n' 'curl konnte nicht korrekt initialisiert werden.'
            ;;
        3)
            printf '%s\n' 'Die Downloadadresse besitzt ein ungültiges Format.'
            ;;
        5)
            printf '%s\n' 'Der Name des eingestellten Proxyservers konnte nicht aufgelöst werden.'
            ;;
        6)
            printf '%s\n' 'Der Name des Downloadservers konnte nicht per DNS aufgelöst werden.'
            ;;
        7)
            printf '%s\n' 'Die Verbindung zum Downloadserver konnte nicht aufgebaut werden.'
            ;;
        18)
            printf '%s\n' 'Die heruntergeladene Datei war unvollständig.'
            ;;
        22)
            printf '%s\n' 'Der Webserver antwortete mit einem HTTP-Fehler ab Status 400.'
            ;;
        23)
            printf '%s\n' 'Die heruntergeladenen Daten konnten nicht lokal gespeichert werden.'
            ;;
        27)
            printf '%s\n' 'curl hatte nicht genügend Arbeitsspeicher.'
            ;;
        28)
            printf '%s\n' 'Der Download überschritt das erlaubte Zeitlimit.'
            ;;
        35)
            printf '%s\n' 'Der Aufbau der verschlüsselten TLS-Verbindung ist fehlgeschlagen.'
            ;;
        47)
            printf '%s\n' 'Der Download wurde zu oft auf eine andere Adresse weitergeleitet.'
            ;;
        52)
            printf '%s\n' 'Der Server schloss die Verbindung, ohne Daten zurückzugeben.'
            ;;
        55)
            printf '%s\n' 'Netzwerkdaten konnten nicht gesendet werden.'
            ;;
        56)
            printf '%s\n' 'Beim Empfangen der Netzwerkdaten trat ein Fehler auf.'
            ;;
        60)
            printf '%s\n' 'Das Zertifikat des Servers konnte nicht erfolgreich geprüft werden.'
            ;;
        63)
            printf '%s\n' 'Die heruntergeladene Datei überschritt die erlaubte Maximalgröße.'
            ;;
        77)
            printf '%s\n' 'Die lokale Datei mit vertrauenswürdigen Zertifikaten konnte nicht gelesen werden.'
            ;;
        78)
            printf '%s\n' 'Die angeforderte Datei wurde auf dem Server nicht gefunden.'
            ;;
        92)
            printf '%s\n' 'Im verwendeten HTTP/2-Datenstrom trat ein Fehler auf.'
            ;;
        95)
            printf '%s\n' 'In der HTTP/3-Verbindung trat ein Fehler auf.'
            ;;
        96)
            printf '%s\n' 'Die QUIC-Verbindung für HTTP/3 konnte nicht aufgebaut werden.'
            ;;
        97)
            printf '%s\n' 'Der Verbindungsaufbau über den Proxy ist fehlgeschlagen.'
            ;;
        *)
            general_exit_code_meaning "$1"
            ;;
    esac
}

failure_meaning() {
    local source_id="$1"
    local result="$2"
    local log_file="$3"

    case "$source_id" in
        test-lock)
            printf '%s\n' 'Die Testsperre hat den Administratorbefehl absichtlich blockiert.'
            ;;
        postcheck)
            printf '%s\n' 'Der Installationsbefehl meldete Erfolg, das Programm wurde danach aber nicht vollständig gefunden.'
            ;;
        curl)
            curl_exit_code_meaning "$result"
            ;;
        checksum)
            printf '%s\n' 'Die berechnete SHA-256-Prüfsumme stimmt nicht mit dem festgelegten Wert überein.'
            ;;
        pacman)
            if log_matches "$log_file" 'unable to lock database|Datenbank.*nicht.*sperr'; then
                printf '%s\n' 'Die Pacman-Datenbank ist durch einen anderen Paketvorgang gesperrt.'
            elif log_matches "$log_file" 'target not found|Ziel nicht gefunden'; then
                printf '%s\n' 'Das angeforderte Paket wurde in den aktiven Repositories nicht gefunden.'
            elif log_matches "$log_file" 'failed retrieving file|Datei.*konnte nicht.*übertragen'; then
                printf '%s\n' 'Eine Paketdatei konnte nicht vom Spiegelserver geladen werden.'
            elif log_matches "$log_file" 'invalid or corrupted package|ungültiges oder beschädigtes Paket|PGP signature|PGP-Signatur'; then
                printf '%s\n' 'Ein Paket oder seine kryptografische Signatur konnte nicht bestätigt werden.'
            elif log_matches "$log_file" 'not enough free disk space|nicht genügend freier Speicher'; then
                printf '%s\n' 'Für die Installation ist nicht genügend freier Speicherplatz vorhanden.'
            elif log_matches "$log_file" 'conflicting files|Dateikonflikt'; then
                printf '%s\n' 'Vorhandene Dateien stehen mit dem zu installierenden Paket in Konflikt.'
            elif log_matches "$log_file" 'could not satisfy dependencies|Abhängigkeiten.*nicht.*erfüllt'; then
                printf '%s\n' 'Mindestens eine benötigte Paketabhängigkeit konnte nicht erfüllt werden.'
            else
                printf '%s\n' 'Pacman konnte die Paketinstallation nicht abschließen.'
            fi
            ;;
        git)
            if log_matches "$log_file" 'Could not resolve host|Name or service not known'; then
                printf '%s\n' 'Der Git-Server konnte nicht per DNS aufgelöst werden.'
            elif log_matches "$log_file" 'Connection timed out|Connection refused'; then
                printf '%s\n' 'Die Verbindung zum Git-Server ist fehlgeschlagen.'
            elif log_matches "$log_file" 'Authentication failed|Permission denied'; then
                printf '%s\n' 'Die Anmeldung oder Zugriffsberechtigung am Git-Repository ist fehlgeschlagen.'
            elif log_matches "$log_file" 'Repository not found'; then
                printf '%s\n' 'Das angeforderte Git-Repository wurde nicht gefunden.'
            elif log_matches "$log_file" 'pathspec .* did not match|reference is not a tree'; then
                printf '%s\n' 'Der festgelegte Git-Commit oder Verweis ist nicht verfügbar.'
            else
                printf '%s\n' 'Git konnte das Repository oder den festgelegten Stand nicht verarbeiten.'
            fi
            ;;
        makepkg|aur-build)
            if log_matches "$log_file" 'Could not resolve all dependencies|Abhängigkeiten.*nicht.*auflösen'; then
                printf '%s\n' 'Die Abhängigkeiten des AUR-Pakets konnten nicht aufgelöst werden.'
            elif log_matches "$log_file" 'One or more files did not pass the validity check|Gültigkeitsprüfung.*fehlgeschlagen'; then
                printf '%s\n' 'Mindestens eine Quelldatei des AUR-Pakets bestand die Prüfsummenprüfung nicht.'
            elif log_matches "$log_file" 'A failure occurred in build|Fehler beim Erstellen'; then
                printf '%s\n' 'Das AUR-Paket konnte nicht erfolgreich gebaut werden.'
            else
                printf '%s\n' 'Die AUR-Paketdefinition konnte nicht vollständig gebaut oder installiert werden.'
            fi
            ;;
        aur-helper)
            printf '%s\n' 'Der AUR-Helfer konnte das ausgewählte Paket nicht installieren.'
            ;;
        archive)
            printf '%s\n' 'Das heruntergeladene Archiv konnte nicht vollständig entpackt werden.'
            ;;
        systemd)
            printf '%s\n' 'Der benötigte Systemdienst konnte nicht eingerichtet oder gestartet werden.'
            ;;
        usermod)
            printf '%s\n' 'Der Benutzer konnte nicht der benötigten Systemgruppe hinzugefügt werden.'
            ;;
        sudo)
            printf '%s\n' 'Der benötigte Administratorbefehl konnte nicht ausgeführt werden.'
            ;;
        installer)
            printf '%s\n' 'Der programmspezifische Installationsablauf konnte nicht abgeschlossen werden.'
            ;;
        shell)
            general_exit_code_meaning "$result"
            ;;
        *)
            general_exit_code_meaning "$result"
            ;;
    esac
}

failure_recommendation() {
    local source_id="$1"
    local result="$2"
    local log_file="$3"

    case "$source_id" in
        test-lock)
            printf '%s\n' 'Keine Maßnahme nötig; dies war ein absichtlich gesicherter Test.'
            ;;
        postcheck)
            printf '%s\n' 'Programmstatus und letzte Protokollzeilen prüfen und die Auswahl danach erneut starten.'
            ;;
        curl)
            case "$result" in
                5|6)
                    printf '%s\n' 'Internetverbindung und DNS-Auflösung prüfen.'
                    ;;
                7|28|52|55|56)
                    printf '%s\n' 'Netzwerk, Firewall und Erreichbarkeit des Downloadservers prüfen und später erneut versuchen.'
                    ;;
                22|78)
                    printf '%s\n' 'Downloadadresse und festgelegte Programmversion prüfen.'
                    ;;
                35|60|77)
                    printf '%s\n' 'Systemzeit, Zertifikatspaket und TLS-Verbindung prüfen.'
                    ;;
                23|63)
                    printf '%s\n' 'Freien Speicherplatz und Schreibrechte des Zielverzeichnisses prüfen.'
                    ;;
                *)
                    printf '%s\n' 'Die curl-Meldung im Programmprotokoll prüfen und den Download erneut versuchen.'
                    ;;
            esac
            ;;
        checksum)
            printf '%s\n' 'Datei nicht verwenden; Downloadquelle, Version und festgelegte Prüfsumme kontrollieren.'
            ;;
        pacman)
            if log_matches "$log_file" 'unable to lock database|Datenbank.*nicht.*sperr'; then
                printf '%s\n' 'Anderen Paketmanager beenden und niemals die Sperrdatei während eines laufenden Vorgangs löschen.'
            elif log_matches "$log_file" 'target not found|Ziel nicht gefunden'; then
                printf '%s\n' 'Paketnamen und synchronisierte Repository-Datenbanken prüfen.'
            elif log_matches "$log_file" 'failed retrieving file|Datei.*konnte nicht.*übertragen'; then
                printf '%s\n' 'Internetverbindung und Arch-Spiegelserver prüfen und später erneut versuchen.'
            elif log_matches "$log_file" 'PGP signature|PGP-Signatur|invalid or corrupted package|ungültiges oder beschädigtes Paket'; then
                printf '%s\n' 'Schlüsselbund und Systemzeit prüfen; das Paket nicht ungeprüft erzwingen.'
            elif log_matches "$log_file" 'not enough free disk space|nicht genügend freier Speicher'; then
                printf '%s\n' 'Speicherplatz freigeben und die Programmauswahl erneut starten.'
            else
                printf '%s\n' 'Die letzten Pacman-Zeilen im angegebenen Protokoll prüfen.'
            fi
            ;;
        git)
            printf '%s\n' 'Netzwerk, Repository-Adresse und festgelegten Commit anhand des Protokolls prüfen.'
            ;;
        makepkg|aur-build|aur-helper)
            printf '%s\n' 'AUR-Paketdefinition, Abhängigkeiten und die letzten Build-Zeilen im Protokoll prüfen.'
            ;;
        archive)
            printf '%s\n' 'Download und Prüfsumme kontrollieren; eine unvollständige Datei nicht weiterverwenden.'
            ;;
        systemd)
            printf '%s\n' 'Dienstname sowie systemctl- und journalctl-Ausgabe prüfen.'
            ;;
        usermod)
            printf '%s\n' 'Benutzername, Zielgruppe und Administratorrechte prüfen.'
            ;;
        sudo)
            printf '%s\n' 'sudo-Berechtigung und eingegebenes Kennwort prüfen.'
            ;;
        shell)
            case "$result" in
                126)
                    printf '%s\n' 'Dateirechte, Dateiformat und passenden Interpreter prüfen.'
                    ;;
                127)
                    printf '%s\n' 'Das fehlende Programm installieren oder den verwendeten Befehl korrigieren.'
                    ;;
                130)
                    printf '%s\n' 'Die Auswahl erneut starten, falls der Abbruch nicht beabsichtigt war.'
                    ;;
                137)
                    printf '%s\n' 'Arbeitsspeicher, Swap und Kernel-Protokoll auf einen OOM-Abbruch prüfen.'
                    ;;
                *)
                    printf '%s\n' 'Die letzten Zeilen des angegebenen Protokolls prüfen.'
                    ;;
            esac
            ;;
        *)
            printf '%s\n' 'Die letzten Zeilen des angegebenen Programmprotokolls prüfen.'
            ;;
    esac
}

program_status_text() {
    local program_id="$1"
    local failure_file="$STATE_DIR/$program_id.failed"
    local result=""
    local source_label=""
    local meaning=""

    if program_is_installed "$program_id"; then
        printf 'bereits installiert'
        return 0
    fi

    if [[ -s "$failure_file" ]]; then
        result="$(
            read_failure_field "$failure_file" exit_code ||
                true
        )"
        source_label="$(
            read_failure_field "$failure_file" source_label ||
                true
        )"
        meaning="$(
            read_failure_field "$failure_file" meaning ||
                true
        )"

        if [[ -n "$result" && -n "$meaning" ]]; then
            printf \
                'offen – Exit-Code %s (%s): %s' \
                "$result" \
                "${source_label:-unbekannt}" \
                "$meaning"
            return 0
        fi

        printf 'offen – vorheriger Installationsfehler'
        return 0
    fi

    printf 'nicht installiert'
}

validate_program_id() {
    [[ -n "${PROGRAM_LABELS[$1]+vorhanden}" ]]
}

select_programs_dialog() {
    local program_id=""
    local status=""
    local output=""
    local -a checklist_items=()

    for program_id in "${PROGRAM_IDS[@]}"; do
        status="$(program_status_text "$program_id")"

        checklist_items+=(
            "$program_id"
            "${PROGRAM_LABELS[$program_id]} – ${PROGRAM_DESCRIPTIONS[$program_id]} [$status]"
            off
        )
    done

    if ! output="$(
        dialog_no_cursor \
            --clear \
            --title "Optionale Programme" \
            --ok-label "Auswahl prüfen" \
            --cancel-label "Abbrechen" \
            --separate-output \
            --checklist \
            "Pfeiltasten: bewegen\nLeertaste: auswählen oder abwählen\nEnter: Auswahl prüfen\n\nBereits installierte Programme werden nicht neu installiert." \
            28 100 16 \
            "${checklist_items[@]}" \
            3>&1 1>&2 2>&3
    )"; then
        return 1
    fi

    if [[ -n "$output" ]]; then
        mapfile -t SELECTED_PROGRAMS <<<"$output"
    fi
}

select_programs_text() {
    local answer=""
    local program_id=""
    local -a requested=()

    printf '\nVerfügbare Programme:\n\n'

    for program_id in "${PROGRAM_IDS[@]}"; do
        printf '  %-18s %-28s %s\n' \
            "$program_id" \
            "${PROGRAM_LABELS[$program_id]}" \
            "$(program_status_text "$program_id")"
    done

    printf '\nMehrere IDs mit Leerzeichen trennen.\n'
    read -r -p 'Auswahl, leer zum Abbrechen: ' answer || return 1
    [[ -n "$answer" ]] || return 1

    IFS=' ' read -r -a requested <<<"$answer"

    for program_id in "${requested[@]}"; do
        validate_program_id "$program_id" || {
            warn "Unbekannte Programm-ID: $program_id"
            return 1
        }
    done

    SELECTED_PROGRAMS=("${requested[@]}")
}

select_programs() {
    SELECTED_PROGRAMS=()

    if [[ -t 0 && -t 2 ]] &&
       command -v dialog >/dev/null 2>&1 &&
       [[ -r "$DIALOGRC_FILE" ]]; then
        select_programs_dialog
    else
        select_programs_text
    fi
}

confirm_selection() {
    local answer=""
    local program_id=""

    printf '\nAusgewählte Programme:\n\n'

    for program_id in "${SELECTED_PROGRAMS[@]}"; do
        printf '  - %s (%s)\n' \
            "${PROGRAM_LABELS[$program_id]}" \
            "$(program_status_text "$program_id")"
    done

    printf '\n'

    while true; do
        read -r -p 'Diese Auswahl jetzt bearbeiten? [y/N]: ' answer || return 1

        case "${answer,,}" in
            y|yes)
                return 0
                ;;
            ""|n|no)
                return 1
                ;;
            *)
                printf 'Bitte y/yes oder n/no eingeben.\n'
                ;;
        esac
    done
}

confirm_continue_without_program() {
    local label="$1"
    local timeout_seconds=10
    local deadline=$((SECONDS + timeout_seconds))
    local remaining="$timeout_seconds"
    local elapsed=0
    local bar_width=10
    local position=0
    local progress=""
    local answer=""
    local character=""

    printf '\n'
    warn "Die Installation von '$label' ist fehlgeschlagen."

    if [[ ! -t 0 ]]; then
        warn "Keine interaktive Eingabe verfügbar."
        warn "Das Setup fährt in $timeout_seconds Sekunden automatisch ohne '$label' fort."
        sleep "$timeout_seconds"
        return 0
    fi

    while (( SECONDS < deadline )); do
        remaining=$((deadline - SECONDS))
        elapsed=$((timeout_seconds - remaining))
        progress=""

        for ((position = 0; position < bar_width; position++)); do
            if (( position < elapsed )); then
                progress+="█"
            else
                progress+="░"
            fi
        done

        printf '\r\033[2K'
        printf \
            "Ohne %s fortfahren? [Y/n] [%s] %2d Sekunden  Eingabe: %s" \
            "$label" \
            "$progress" \
            "$remaining" \
            "$answer"

        character=""

        if IFS= read -r -s -n 1 -t 1 character; then
            case "$character" in
                "")
                    printf '\r\033[2K'

                    case "${answer,,}" in
                        ""|y|yes)
                            return 0
                            ;;
                        n|no)
                            return 1
                            ;;
                        *)
                            printf \
                                'Bitte y/yes oder n/no eingeben. Der Timer läuft weiter.\n'
                            answer=""
                            ;;
                    esac
                    ;;

                $'\177'|$'\b')
                    if [[ -n "$answer" ]]; then
                        answer="${answer::-1}"
                    fi
                    ;;

                *)
                    if [[ "$character" =~ [[:print:]] ]] &&
                       ((${#answer} < 12)); then
                        answer+="$character"
                    fi
                    ;;
            esac
        fi
    done

    progress=""

    for ((position = 0; position < bar_width; position++)); do
        progress+="█"
    done

    printf '\r\033[2K'
    printf \
        "Ohne %s fortfahren? [Y/n] [%s]  0 Sekunden  Eingabe: %s\n" \
        "$label" \
        "$progress" \
        "$answer"
    warn "Die 10 Sekunden sind abgelaufen."
    warn "Das Setup fährt automatisch ohne '$label' fort."

    return 0
}

install_program() {
    local program_id="$1"
    local package=""
    local -a packages=()

    case "$program_id" in
        brave)
            install_brave
            return
            ;;
        powershell)
            install_powershell
            return
            ;;
        vscode)
            install_vscode
            return
            ;;
        arduino)
            install_arduino_ide
            configure_arduino_udev
            return
            ;;
        xampp)
            install_xampp
            return
            ;;
    esac

    program_is_available "$program_id" || return 1

    mapfile -t packages < <(
        program_packages "$program_id"
    ) || return 1

    info "Installiere ${PROGRAM_LABELS[$program_id]}."

    sudo pacman \
        --sync \
        --needed \
        --noconfirm \
        "${packages[@]}" || return $?

    if [[ "$program_id" == "docker" ]]; then
        sudo systemctl enable --now docker.service || return $?
        sudo usermod -aG docker "$USER" || return $?
    fi
}

next_attempt_number() {
    local program_id="$1"
    local attempts_file="$STATE_DIR/$program_id.attempts"
    local attempts=0

    if [[ -r "$attempts_file" ]]; then
        read -r attempts <"$attempts_file" || attempts=0
    fi

    [[ "$attempts" =~ ^[0-9]+$ ]] || attempts=0
    attempts=$((attempts + 1))
    printf '%s\n' "$attempts" >"$attempts_file"
    printf '%s\n' "$attempts"
}

record_program_failure() {
    local program_id="$1"
    local result="$2"
    local log_file="$3"
    local source_id="$4"
    local source_label="$5"
    local phase="$6"
    local meaning="$7"
    local recommendation="$8"

    {
        printf 'program_id=%s\n' "$program_id"
        printf 'label=%s\n' "${PROGRAM_LABELS[$program_id]}"
        printf 'timestamp=%s\n' "$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
        printf 'exit_code=%s\n' "$result"
        printf 'source=%s\n' "$source_id"
        printf 'source_label=%s\n' "$source_label"
        printf 'phase=%s\n' "$phase"
        printf 'meaning=%s\n' "$meaning"
        printf 'recommendation=%s\n' "$recommendation"
        printf 'log=%s\n' "$log_file"
    } >"$STATE_DIR/$program_id.failed"
}

run_program_action() (
    set -Eeuo pipefail
    "$@"
)

run_selected_program() {
    local program_id="$1"
    local label="${PROGRAM_LABELS[$program_id]}"
    local attempt=0
    local result=0
    local started="$SECONDS"
    local duration=0
    local log_file=""
    local post_check_failed=0
    local source_id=""
    local source_label=""
    local phase=""
    local meaning=""
    local recommendation=""

    if program_is_installed "$program_id"; then
        info "$label ist bereits vollständig installiert und wird nicht neu installiert."
        ALREADY_INSTALLED_PROGRAMS+=("$label")
        rm -f -- "$STATE_DIR/$program_id.failed"
        return 0
    fi

    attempt="$(next_attempt_number "$program_id")"
    mkdir -p "$LOG_DIR/$program_id"
    log_file="$LOG_DIR/$program_id/attempt-${attempt}-$(date -u +'%Y%m%dT%H%M%SZ').log"

    set +e
    run_program_action install_program "$program_id" 2>&1 |
        tee -a "$log_file"
    result="${PIPESTATUS[0]}"
    set -e

    duration=$((SECONDS - started))

    if (( result == 0 )) && program_is_installed "$program_id"; then
        info "$label wurde erfolgreich installiert."
        printf '[INFO] Programmdauer: %s Minute(n) und %s Sekunde(n).\n' \
            "$((duration / 60))" \
            "$((duration % 60))"

        INSTALLED_PROGRAMS+=("$label")
        rm -f -- "$STATE_DIR/$program_id.failed"
        return 0
    fi

    if (( result == 0 )); then
        result=1
        post_check_failed=1
        warn "$label meldete keinen Installationsfehler, wurde anschließend aber nicht gefunden."
    fi

    source_id="$(
        detect_failure_source \
            "$program_id" \
            "$result" \
            "$log_file" \
            "$post_check_failed"
    )"

    source_label="$(failure_source_label "$source_id")"
    phase="$(failure_phase_text "$source_id")"
    meaning="$(failure_meaning "$source_id" "$result" "$log_file")"
    recommendation="$(
        failure_recommendation \
            "$source_id" \
            "$result" \
            "$log_file"
    )"

    record_program_failure \
        "$program_id" \
        "$result" \
        "$log_file" \
        "$source_id" \
        "$source_label" \
        "$phase" \
        "$meaning" \
        "$recommendation"

    FAILED_PROGRAMS+=(
        "$label – Exit-Code $result ($source_label): $meaning – $log_file"
    )

    printf '\n'
    warn "Fehlercode: $result"
    warn "Fehlerquelle: $source_label"
    warn "Phase: $phase"
    warn "Bedeutung: $meaning"
    warn "Mögliche Abhilfe: $recommendation"
    warn "Programmprotokoll: $log_file"

    printf '[WARNUNG] Zeit bis zum Fehler: %s Minute(n) und %s Sekunde(n).\n' \
        "$((duration / 60))" \
        "$((duration % 60))"

    confirm_continue_without_program "$label"
}

collect_not_selected_programs() {
    local program_id=""
    local selected_id=""
    local was_selected=0

    NOT_SELECTED_PROGRAMS=()

    for program_id in "${PROGRAM_IDS[@]}"; do
        was_selected=0

        for selected_id in "${SELECTED_PROGRAMS[@]}"; do
            if [[ "$program_id" == "$selected_id" ]]; then
                was_selected=1
                break
            fi
        done

        if (( was_selected == 0 )); then
            NOT_SELECTED_PROGRAMS+=("${PROGRAM_LABELS[$program_id]}")
        fi
    done
}

print_named_list() {
    local heading="$1"
    shift

    (($# > 0)) || return 0

    printf '\n%s:\n' "$heading"
    printf '  - %s\n' "$@"
}

print_final_report() {
    printf '\nOptionale Programme – Zusammenfassung\n'
    printf '=====================================\n'
    printf 'Neu installiert:       %s\n' "${#INSTALLED_PROGRAMS[@]}"
    printf 'Bereits installiert:   %s\n' "${#ALREADY_INSTALLED_PROGRAMS[@]}"
    printf 'Fehlgeschlagen/offen:  %s\n' "${#FAILED_PROGRAMS[@]}"
    printf 'Nicht ausgewählt:      %s\n' "${#NOT_SELECTED_PROGRAMS[@]}"

    print_named_list "Neu installiert" "${INSTALLED_PROGRAMS[@]}"
    print_named_list "Bereits installiert" "${ALREADY_INSTALLED_PROGRAMS[@]}"
    print_named_list "Fehlgeschlagen und erneut auswählbar" "${FAILED_PROGRAMS[@]}"
    print_named_list "Nicht ausgewählt" "${NOT_SELECTED_PROGRAMS[@]}"
}

show_status() {
    local program_id=""

    printf 'Optionale Programme – Status\n'
    printf '============================\n\n'

    for program_id in "${PROGRAM_IDS[@]}"; do
        printf '%-30s %s\n' \
            "${PROGRAM_LABELS[$program_id]}" \
            "$(program_status_text "$program_id")"
    done
}

check_environment() {
    (( EUID != 0 )) || fail "Dieses Skript als normaler Benutzer und nicht mit sudo starten."
    command -v pacman >/dev/null 2>&1 || fail "pacman wurde nicht gefunden."
    command -v sudo >/dev/null 2>&1 || fail "sudo wurde nicht gefunden."

    if [[ ! -f "$HOME/.local/state/custom-linux/postinstall-setup.ok" ]]; then
        warn "Das Grundsystem-Setup ist noch nicht vollständig abgeschlossen."
        warn "Die Programmauswahl bleibt trotzdem verfügbar."
        warn "Programme mit fehlenden Voraussetzungen können fehlschlagen und später erneut ausgewählt werden."
    fi
}

test_error_catalog() (
    local temporary_directory=""
    local program_id=""
    local result=""
    local test_message=""
    local log_file=""
    local source_id=""
    local source_label=""
    local phase=""
    local meaning=""
    local recommendation=""
    local test_case=""
    local -a test_cases=(
        'obsidian|1|error: target not found: obsidian'
        'powershell|6|curl: (6) Could not resolve host: github.com'
        'vscode|128|fatal: unable to access repository: Connection timed out'
        'arduino|1|==> ERROR: A failure occurred in build().'
        'xampp|1|Die SHA-256-Prüfsumme des XAMPP-Installers stimmt nicht.'
        'obsidian|97|[TESTSPERRE] sudo wurde blockiert: pacman --sync obsidian'
        'discord|127|Benötigter Befehl wurde nicht gefunden.'
        'docker|137|Der Prozess wurde beendet.'
    )

    temporary_directory="$(
        mktemp -d -t custom-linux-error-catalog.XXXXXXXX
    )"

    trap 'rm -rf -- "$temporary_directory"' EXIT

    printf 'Fehlercode-Katalog – sicherer Test\n'
    printf '=================================\n'

    for test_case in "${test_cases[@]}"; do
        IFS='|' read -r \
            program_id \
            result \
            test_message \
            <<<"$test_case"

        log_file="$temporary_directory/$program_id-$result.log"
        printf '%s\n' "$test_message" >"$log_file"

        source_id="$(
            detect_failure_source \
                "$program_id" \
                "$result" \
                "$log_file" \
                0
        )"
        source_label="$(failure_source_label "$source_id")"
        phase="$(failure_phase_text "$source_id")"
        meaning="$(failure_meaning "$source_id" "$result" "$log_file")"
        recommendation="$(
            failure_recommendation \
                "$source_id" \
                "$result" \
                "$log_file"
        )"

        printf '\nProgramm:   %s\n' "${PROGRAM_LABELS[$program_id]}"
        printf 'Exit-Code:  %s\n' "$result"
        printf 'Quelle:     %s\n' "$source_label"
        printf 'Phase:      %s\n' "$phase"
        printf 'Bedeutung:  %s\n' "$meaning"
        printf 'Abhilfe:    %s\n' "$recommendation"
    done

    printf '\n'
    info "Der Fehlerkatalog-Test ist abgeschlossen."
    info "Es wurden keine Programme und keine Statusdateien verändert."
)

main() {
    local program_id=""
    local stop_requested=0

    if [[ "${1:-}" == "--status" ]]; then
        show_status
        return 0
    fi

    if [[ "${1:-}" == "--test-error-catalog" ]]; then
        test_error_catalog
        return 0
    fi

    if [[ "${1:-}" == "--test-countdown" ]]; then
        printf 'Visueller Timer-Test\n'
        printf '====================\n'

        if confirm_continue_without_program "Testprogramm"; then
            info "Testergebnis: ohne Testprogramm fortfahren."
        else
            info "Testergebnis: Ablauf anhalten."
        fi

        return 0
    fi

    check_environment
    mkdir -p "$STATE_DIR" "$LOG_DIR"

    printf 'Custom-Linux – optionale Programme\n'
    printf '==================================\n'

    if ! select_programs; then
        info "Die Auswahl wurde abgebrochen. Es wird nichts installiert."
        return 0
    fi

    if ((${#SELECTED_PROGRAMS[@]} == 0)); then
        info "Es wurde kein Programm ausgewählt. Es wird nichts installiert."
        return 0
    fi

    if ! confirm_selection; then
        info "Die Auswahl wurde nicht bestätigt. Es wird nichts installiert."
        return 0
    fi

    collect_not_selected_programs

    for program_id in "${SELECTED_PROGRAMS[@]}"; do
        if ! run_selected_program "$program_id"; then
            warn "Der Ablauf wurde auf Wunsch nach '${PROGRAM_LABELS[$program_id]}' angehalten."
            stop_requested=1
            break
        fi
    done

    print_final_report

    if (( stop_requested != 0 )); then
        return 1
    fi
}

main "$@"
