#!/usr/bin/env bash

# 05-keyboard-layout-setup.sh
#
# Prüft und repariert die deutsche Tastaturbelegung für Konsole, X11,
# KDE Plasma und Niri. Persönliche und systemweite Dateien werden vor
# Änderungen gesichert. Eine Niri-Benutzerregel schützt vor iNiR-Updates.

set -Eeuo pipefail
IFS=$'\n\t'

TIMESTAMP="$(date -u +'%Y%m%dT%H%M%SZ')"
STATE_DIR="$HOME/.local/state/custom-linux/keyboard-layout"
BACKUP_DIR="$STATE_DIR/backups/$TIMESTAMP"

NIRI_DIRECTORY="$HOME/.config/niri"
NIRI_CONFIG="$NIRI_DIRECTORY/config.kdl"
NIRI_INPUT="$NIRI_DIRECTORY/config.d/10-input-and-cursor.kdl"
NIRI_USER_EXTRA="$NIRI_DIRECTORY/config.d/90-user-extra.kdl"
INIR_TEMPLATE="$HOME/Projects/inir/defaults/niri/config.d/10-input-and-cursor.kdl"

NIRI_BLOCK_START="// BEGIN Custom Linux German keyboard"
NIRI_BLOCK_END="// END Custom Linux German keyboard"

SYSTEM_VCONSOLE="/etc/vconsole.conf"
SYSTEM_X11="/etc/X11/xorg.conf.d/00-keyboard.conf"

declare -a CORRECT_AREAS=()
declare -a REPAIRED_AREAS=()
declare -a SKIPPED_AREAS=()
declare -a FAILED_AREAS=()
declare -a TEMP_FILES=()

info() { printf '[INFO] %s\n' "$*"; }
warn() { printf '[WARNUNG] %s\n' "$*" >&2; }
fail() { printf '[FEHLER] %s\n' "$*" >&2; exit 1; }

cleanup() {
    local file=""

    for file in "${TEMP_FILES[@]}"; do
        [[ -n "$file" ]] && rm -f -- "$file"
    done
}

trap cleanup EXIT INT TERM HUP

record_correct() {
    CORRECT_AREAS+=("$1")
    printf '[OK] %s war bereits korrekt.\n' "$1"
}

record_repaired() {
    REPAIRED_AREAS+=("$1")
    printf '[OK] %s wurde repariert.\n' "$1"
}

record_skipped() {
    SKIPPED_AREAS+=("$1")
    printf '[INFO] %s wurde übersprungen.\n' "$1"
}

record_failed() {
    FAILED_AREAS+=("$1")
    warn "$1 konnte nicht vollständig repariert werden."
}

backup_user_file() {
    local source_file="$1"
    local backup_name="$2"

    [[ -e "$source_file" ]] || return 0

    mkdir -p -- "$BACKUP_DIR"
    chmod 0700 -- "$STATE_DIR" "$STATE_DIR/backups" "$BACKUP_DIR"
    cp -a -- "$source_file" "$BACKUP_DIR/$backup_name"
    chmod 0600 -- "$BACKUP_DIR/$backup_name"
    info "Sicherung erstellt: $BACKUP_DIR/$backup_name"
}

backup_system_file() {
    local source_file="$1"
    local backup_name="$2"

    [[ -e "$source_file" ]] || return 0

    mkdir -p -- "$BACKUP_DIR"
    chmod 0700 -- "$STATE_DIR" "$STATE_DIR/backups" "$BACKUP_DIR"
    sudo install -d -m 0700 -- "$BACKUP_DIR/system"
    sudo cp -a -- "$source_file" "$BACKUP_DIR/system/$backup_name"
    sudo chown -R -- "$(id -u):$(id -g)" "$BACKUP_DIR/system"
    info "Sicherung erstellt: $BACKUP_DIR/system/$backup_name"
}

system_keyboard_is_german() {
    [[ -f "$SYSTEM_VCONSOLE" && -f "$SYSTEM_X11" ]] || return 1

    grep -Eq '^KEYMAP="?(de|de-latin1)"?[[:space:]]*$' "$SYSTEM_VCONSOLE" &&
        grep -Eq '^[[:space:]]*Option[[:space:]]+"XkbLayout"[[:space:]]+"de"' "$SYSTEM_X11" &&
        grep -Eq '^[[:space:]]*Option[[:space:]]+"XkbModel"[[:space:]]+"pc105"' "$SYSTEM_X11" &&
        grep -Eq '^[[:space:]]*Option[[:space:]]+"XkbOptions"[[:space:]]+"terminate:ctrl_alt_bksp"' "$SYSTEM_X11"
}

configure_system_keyboard() {
    if ! command -v localectl >/dev/null 2>&1; then
        record_failed "Konsole und X11"
        warn "localectl wurde nicht gefunden."
        return
    fi

    if system_keyboard_is_german; then
        record_correct "Konsole und X11"
        return
    fi

    command -v sudo >/dev/null 2>&1 || {
        record_failed "Konsole und X11"
        warn "sudo wurde nicht gefunden."
        return
    }

    info "Root-Rechte werden einmalig für die systemweite Reparatur benötigt."

    if ! sudo -v; then
        record_failed "Konsole und X11"
        return
    fi

    backup_system_file "$SYSTEM_VCONSOLE" "vconsole.conf"
    backup_system_file "$SYSTEM_X11" "00-keyboard.conf"

    if ! sudo localectl set-keymap de-latin1 ||
       ! sudo localectl set-x11-keymap de pc105 '' terminate:ctrl_alt_bksp; then
        record_failed "Konsole und X11"
        return
    fi

    if system_keyboard_is_german; then
        record_repaired "Konsole und X11"
    else
        record_failed "Konsole und X11"
    fi
}

kde_keyboard_is_german() {
    local config="$HOME/.config/kxkbrc"

    [[ -f "$config" ]] || return 1

    awk -F= '
        /^\[Layout\]$/ { in_layout = 1; next }
        /^\[/ { in_layout = 0 }
        in_layout && $1 == "Use" && $2 == "true" { use = 1 }
        in_layout && $1 == "Model" && $2 == "pc105" { model = 1 }
        in_layout && $1 == "LayoutList" && $2 == "de" { layout = 1 }
        in_layout && $1 == "Options" && $2 == "terminate:ctrl_alt_bksp" { options = 1 }
        END { exit !(use && model && layout && options) }
    ' "$config"
}

configure_kde_keyboard() {
    local config="$HOME/.config/kxkbrc"

    if ! command -v kwriteconfig6 >/dev/null 2>&1; then
        record_skipped "KDE Plasma"
        info "kwriteconfig6 wurde nicht gefunden."
        return
    fi

    if kde_keyboard_is_german; then
        record_correct "KDE Plasma"
        return
    fi

    backup_user_file "$config" "kxkbrc"
    mkdir -p -- "$(dirname -- "$config")"

    kwriteconfig6 --file kxkbrc --group Layout --key Use true
    kwriteconfig6 --file kxkbrc --group Layout --key Model pc105
    kwriteconfig6 --file kxkbrc --group Layout --key LayoutList de
    kwriteconfig6 --file kxkbrc --group Layout --key Options terminate:ctrl_alt_bksp

    if kde_keyboard_is_german; then
        record_repaired "KDE Plasma"
    else
        record_failed "KDE Plasma"
    fi
}

niri_input_is_german() {
    [[ -f "$NIRI_INPUT" ]] || return 1

    awk '
        /^[[:space:]]*layout[[:space:]]+"[^"]*"[[:space:]]*$/ {
            count++
            if ($0 ~ /^[[:space:]]*layout[[:space:]]+"de"[[:space:]]*$/) {
                german++
            }
        }
        END { exit !(count == 1 && german == 1) }
    ' "$NIRI_INPUT"
}

repair_niri_input() {
    local temp_file=""
    local backup_file=""

    [[ -f "$NIRI_INPUT" ]] || {
        record_skipped "Niri-Eingabedatei"
        return
    }

    if niri_input_is_german; then
        record_correct "Niri-Eingabedatei"
        return
    fi

    backup_user_file "$NIRI_INPUT" "10-input-and-cursor.kdl"
    backup_file="$BACKUP_DIR/10-input-and-cursor.kdl"
    temp_file="$(mktemp "$NIRI_DIRECTORY/config.d/.10-input.XXXXXXXX")"
    TEMP_FILES+=("$temp_file")

    sed -E \
        's/^([[:space:]]*)layout[[:space:]]+"[^"]*"[[:space:]]*$/\1layout "de"/' \
        "$NIRI_INPUT" >"$temp_file"

    if cmp -s -- "$NIRI_INPUT" "$temp_file"; then
        rm -f -- "$temp_file"
        record_skipped "Niri-Eingabedatei"
        warn "Es wurde keine aktive layout-Zeile gefunden; die dauerhafte Benutzerregel übernimmt."
        return
    fi

    chmod --reference="$NIRI_INPUT" "$temp_file"
    mv -- "$temp_file" "$NIRI_INPUT"

    if command -v niri >/dev/null 2>&1 && ! niri validate; then
        cp -a -- "$backup_file" "$NIRI_INPUT"
        record_failed "Niri-Eingabedatei"
        warn "Die Änderung wurde aus der Sicherung zurückgesetzt."
        return
    fi

    if niri_input_is_german; then
        record_repaired "Niri-Eingabedatei"
    else
        record_failed "Niri-Eingabedatei"
    fi
}

niri_override_is_german() {
    [[ -f "$NIRI_USER_EXTRA" ]] || return 1

    awk -v start="$NIRI_BLOCK_START" -v end="$NIRI_BLOCK_END" '
        $0 == start { blocks++; inside = 1; next }
        $0 == end { if (inside) complete++; inside = 0; next }
        inside && /^[[:space:]]*layout[[:space:]]+"de"[[:space:]]*$/ { german++ }
        END { exit !(blocks == 1 && complete == 1 && german == 1 && !inside) }
    ' "$NIRI_USER_EXTRA"
}

configure_niri_override() {
    local temp_file=""
    local backup_file=""
    local marker_error=0

    [[ -f "$NIRI_CONFIG" ]] || {
        record_skipped "Dauerhafte Niri-Benutzerregel"
        return
    }

    mkdir -p -- "$(dirname -- "$NIRI_USER_EXTRA")"

    if niri_override_is_german; then
        record_correct "Dauerhafte Niri-Benutzerregel"
        return
    fi

    if [[ -f "$NIRI_USER_EXTRA" ]]; then
        marker_error="$(awk -v start="$NIRI_BLOCK_START" -v end="$NIRI_BLOCK_END" '
            $0 == start { starts++ }
            $0 == end { ends++ }
            END { print (starts != ends || starts > 1 || ends > 1) ? 1 : 0 }
        ' "$NIRI_USER_EXTRA")"

        if (( marker_error != 0 )); then
            record_failed "Dauerhafte Niri-Benutzerregel"
            warn "Der vorhandene Custom-Linux-Markierungsblock ist beschädigt oder doppelt."
            warn "Die persönliche Datei wurde aus Sicherheitsgründen nicht automatisch verändert."
            return
        fi
    fi

    backup_user_file "$NIRI_USER_EXTRA" "90-user-extra.kdl"
    [[ -f "$NIRI_USER_EXTRA" ]] && backup_file="$BACKUP_DIR/90-user-extra.kdl"

    temp_file="$(mktemp "$NIRI_DIRECTORY/config.d/.90-user-extra.XXXXXXXX")"
    TEMP_FILES+=("$temp_file")

    if [[ -f "$NIRI_USER_EXTRA" ]]; then
        awk -v start="$NIRI_BLOCK_START" -v end="$NIRI_BLOCK_END" '
            $0 == start { skipping = 1; next }
            $0 == end && skipping { skipping = 0; next }
            !skipping { print }
        ' "$NIRI_USER_EXTRA" >"$temp_file"
    fi

    {
        printf '\n%s\n' "$NIRI_BLOCK_START"
        printf '%s\n' \
            'input {' \
            '    keyboard {' \
            '        xkb {' \
            '            layout "de"' \
            '            options "terminate:ctrl_alt_bksp"' \
            '        }' \
            '    }' \
            '}'
        printf '%s\n' "$NIRI_BLOCK_END"
    } >>"$temp_file"

    chmod 0644 "$temp_file"
    mv -- "$temp_file" "$NIRI_USER_EXTRA"

    if command -v niri >/dev/null 2>&1 && ! niri validate; then
        if [[ -n "$backup_file" ]]; then
            cp -a -- "$backup_file" "$NIRI_USER_EXTRA"
        else
            rm -f -- "$NIRI_USER_EXTRA"
        fi

        record_failed "Dauerhafte Niri-Benutzerregel"
        warn "Die Änderung wurde zurückgesetzt."
        return
    fi

    if niri_override_is_german; then
        record_repaired "Dauerhafte Niri-Benutzerregel"
    else
        record_failed "Dauerhafte Niri-Benutzerregel"
    fi
}

check_inir_template() {
    if [[ ! -f "$INIR_TEMPLATE" ]]; then
        record_skipped "iNiR-Vorlage"
        return
    fi

    if grep -Eq '^[[:space:]]*layout[[:space:]]+"de"[[:space:]]*$' "$INIR_TEMPLATE"; then
        record_correct "iNiR-Vorlage"
    else
        info "Die iNiR-Vorlage kann eine andere Tastaturbelegung vorgeben."
        info "Das Git-Repository bleibt unverändert, damit iNiR-Updates weiterhin funktionieren."

        if niri_override_is_german; then
            record_repaired "Schutz vor der iNiR-Vorgabe"
        else
            record_failed "Schutz vor der iNiR-Vorgabe"
        fi
    fi
}

print_list() {
    local heading="$1"
    shift

    (( $# > 0 )) || return 0
    printf '\n%s:\n' "$heading"
    printf '  - %s\n' "$@"
}

show_summary() {
    printf '\nDeutsche Tastaturbelegung – Zusammenfassung\n'
    printf '===========================================\n'
    printf 'Bereits korrekt:        %s\n' "${#CORRECT_AREAS[@]}"
    printf 'Repariert/geschützt:    %s\n' "${#REPAIRED_AREAS[@]}"
    printf 'Übersprungen:           %s\n' "${#SKIPPED_AREAS[@]}"
    printf 'Fehlgeschlagen/offen:   %s\n' "${#FAILED_AREAS[@]}"

    print_list "Bereits korrekt" "${CORRECT_AREAS[@]}"
    print_list "Repariert oder geschützt" "${REPAIRED_AREAS[@]}"
    print_list "Nicht vorhanden und übersprungen" "${SKIPPED_AREAS[@]}"
    print_list "Fehlgeschlagen oder offen" "${FAILED_AREAS[@]}"

    if ((${#FAILED_AREAS[@]} > 0)); then
        printf '\n'
        warn "Mindestens ein Tastaturbereich ist weiterhin offen."
        return 1
    fi

    printf '\n[OK] Alle vorhandenen Tastaturbereiche sind auf Deutsch eingestellt oder dauerhaft geschützt.\n'
}

main() {
    local command_name=""

    (( EUID != 0 )) ||
        fail "Dieses Skript als normalen Benutzer und nicht direkt mit sudo starten."

    for command_name in awk chmod chown cmp cp date grep id install mkdir mktemp mv printf rm sed; do
        command -v "$command_name" >/dev/null 2>&1 ||
            fail "Benötigter Befehl fehlt: $command_name"
    done

    mkdir -p -- "$STATE_DIR"
    info "Prüfe bekannte Quellen der Tastaturbelegung."

    configure_system_keyboard
    configure_kde_keyboard
    repair_niri_input
    configure_niri_override
    check_inir_template
    show_summary
}

main "$@"
