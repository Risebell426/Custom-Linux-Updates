#!/usr/bin/env bash
#
# custom-update.sh
# Stable Bootstrap-Updater for Custom Arch / Custom Linux.
#
# Design goals:
# - signed, read-only update channel
# - compatibility checks before activation
# - immutable version directories
# - atomic current/previous symlink switching
# - automatic rollback after failed smoke test
# - bundled ISO/install version always remains untouched as final fallback
#
# IMPORTANT:
# This bootstrap is intentionally NOT part of normal script releases.
# Updating the bootstrap itself requires a separately controlled process.

set -Eeuo pipefail
IFS=$'\n\t'

BOOTSTRAP_VERSION="1.0.0"
SUPPORTED_SYSTEM_MANIFEST_SCHEMA=1
SUPPORTED_INDEX_SCHEMA=1
SUPPORTED_RELEASE_MANIFEST_SCHEMA=1
SUPPORTED_UPDATE_API=1

DEFAULT_CHANNEL="stable"
DEFAULT_BASE_URL="https://raw.githubusercontent.com/Risebell426/Custom-Linux-Updates/main"
SIGNER_IDENTITY="custom-arch-release"
SIGN_NAMESPACE_INDEX="custom-arch-update-index"
SIGN_NAMESPACE_RELEASE="custom-arch-update-release"
RETENTION_OLD_VERSIONS=3

SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"

UPDATE_ENVIRONMENT="unknown"
PROJECT_ROOT=""
STATE_ROOT=""
VERSION_ROOT=""
STAGING_ROOT=""
PIN_ROOT=""
CURRENT_LINK=""
PREVIOUS_LINK=""
HISTORY_FILE=""
BUNDLED_DIR=""
SYSTEM_MANIFEST=""
ALLOWED_SIGNERS_FILE=""
BASE_URL="${CUSTOM_UPDATE_BASE_URL:-$DEFAULT_BASE_URL}"
WORK_DIR=""
LOCK_FD=""

SYSTEM_VERSION=""
SYSTEM_ARCH=""
SYSTEM_BOOTSTRAP_VERSION=""
SYSTEM_UPDATE_API=""
SYSTEM_CONFIG_SCHEMA=""
BUNDLED_SCRIPT_VERSION=""

SELECTED_VERSION=""
SELECTED_CHANNEL=""
SELECTED_MANIFEST_REL=""
SELECTED_MANIFEST_FILE=""
SELECTED_MANIFEST_SIG_FILE=""
COMPAT_CODE=""
COMPAT_REASON=""
DEPENDENCY_REASON=""

info() {
    printf '[INFO] %s\n' "$*" >&2
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

update_error() {
    local code="$1"
    shift
    printf '[FEHLER] [%s] %s\n' "$code" "$*" >&2
}

die() {
    local code="$1"
    shift
    update_error "$code" "$*"
    exit 1
}

cleanup() {
    if [[ -n "${WORK_DIR:-}" && -d "$WORK_DIR" ]]; then
        rm -rf -- "$WORK_DIR"
    fi
}
trap cleanup EXIT

require_command() {
    local command_name="$1"
    command -v "$command_name" >/dev/null 2>&1 ||
        die "CA-UPD-CMD-001" "Benötigter Befehl fehlt: $command_name"
}

require_bootstrap_commands() {
    local command_name
    local commands=(
        awk
        bash
        basename
        cat
        chmod
        cp
        curl
        date
        diff
        dirname
        env
        find
        flock
        grep
        gzip
        jq
        ln
        mkdir
        mktemp
        mv
        pacman
        readlink
        rm
        sed
        sha256sum
        sort
        stat
        ssh-keygen
        tar
        uname
    )

    for command_name in "${commands[@]}"; do
        require_command "$command_name"
    done
}

require_restore_commands() {
    local command_name
    local commands=(
        bash
        dirname
        env
        find
        flock
        ln
        mkdir
        mv
        readlink
        rm
    )

    for command_name in "${commands[@]}"; do
        require_command "$command_name"
    done
}

find_project_root_from() {
    local current="$1"

    while [[ "$current" != "/" ]]; do
        if [[ -d "$current/.git" ]] &&
           [[ -d "$current/archiso/releng" ]]; then
            printf '%s\n' "$current"
            return 0
        fi
        current="$(dirname -- "$current")"
    done

    return 1
}

detect_environment() {
    local forced="${CUSTOM_UPDATE_ENVIRONMENT:-}"

    if [[ -n "$forced" ]]; then
        case "$forced" in
            live|installed|build)
                UPDATE_ENVIRONMENT="$forced"
                ;;
            *)
                die "CA-UPD-ENV-001" "Ungültige erzwungene Update-Umgebung: $forced"
                ;;
        esac
    elif [[ -e /run/archiso ]]; then
        UPDATE_ENVIRONMENT="live"
    else
        # The updater's own location is authoritative. This prevents a developer
        # machine that also has /opt/custom-linux-installer from being mistaken
        # for a normal installed-only system when the project copy is executed.
        PROJECT_ROOT="$(find_project_root_from "$SCRIPT_DIR" 2>/dev/null || true)"

        if [[ -n "$PROJECT_ROOT" ]]; then
            UPDATE_ENVIRONMENT="build"
        elif [[ -d /opt/custom-linux-installer ]]; then
            UPDATE_ENVIRONMENT="installed"
        else
            PROJECT_ROOT="$(find_project_root_from "$PWD" 2>/dev/null || true)"
            if [[ -n "$PROJECT_ROOT" ]]; then
                UPDATE_ENVIRONMENT="build"
            else
                die "CA-UPD-ENV-001" "Custom-Linux-Update-Umgebung konnte nicht erkannt werden."
            fi
        fi
    fi

    case "$UPDATE_ENVIRONMENT" in
        live)
            BUNDLED_DIR="${CUSTOM_UPDATE_BUNDLED_DIR:-/root/custom-linux}"
            STATE_ROOT="${CUSTOM_UPDATE_STATE_ROOT:-/run/custom-linux/script-updates}"
            SYSTEM_MANIFEST="${CUSTOM_UPDATE_SYSTEM_MANIFEST:-/usr/share/custom-linux/system-manifest.json}"
            ALLOWED_SIGNERS_FILE="${CUSTOM_UPDATE_ALLOWED_SIGNERS:-/usr/share/custom-linux/update-keys/allowed_signers}"
            ;;
        installed)
            BUNDLED_DIR="${CUSTOM_UPDATE_BUNDLED_DIR:-/opt/custom-linux-installer}"
            STATE_ROOT="${CUSTOM_UPDATE_STATE_ROOT:-/var/lib/custom-linux/script-updates}"
            SYSTEM_MANIFEST="${CUSTOM_UPDATE_SYSTEM_MANIFEST:-/usr/share/custom-linux/system-manifest.json}"
            ALLOWED_SIGNERS_FILE="${CUSTOM_UPDATE_ALLOWED_SIGNERS:-/usr/share/custom-linux/update-keys/allowed_signers}"
            ;;
        build)
            if [[ -z "$PROJECT_ROOT" ]]; then
                PROJECT_ROOT="$(find_project_root_from "$PWD" 2>/dev/null || true)"
            fi
            [[ -n "$PROJECT_ROOT" ]] ||
                die "CA-UPD-ENV-001" "Build-Projekt konnte nicht gefunden werden."

            BUNDLED_DIR="${CUSTOM_UPDATE_BUNDLED_DIR:-$PROJECT_ROOT/archiso/releng/airootfs/root/custom-linux}"
            STATE_ROOT="${CUSTOM_UPDATE_STATE_ROOT:-$PROJECT_ROOT/build/script-updates}"
            SYSTEM_MANIFEST="${CUSTOM_UPDATE_SYSTEM_MANIFEST:-$PROJECT_ROOT/archiso/releng/airootfs/usr/share/custom-linux/system-manifest.json}"
            ALLOWED_SIGNERS_FILE="${CUSTOM_UPDATE_ALLOWED_SIGNERS:-$PROJECT_ROOT/archiso/releng/airootfs/usr/share/custom-linux/update-keys/allowed_signers}"
            ;;
    esac

    VERSION_ROOT="$STATE_ROOT/versions"
    STAGING_ROOT="$STATE_ROOT/staging"
    PIN_ROOT="$STATE_ROOT/pinned"
    CURRENT_LINK="$STATE_ROOT/current"
    PREVIOUS_LINK="$STATE_ROOT/previous"
    HISTORY_FILE="$STATE_ROOT/history.jsonl"
}

ensure_work_dir() {
    if [[ -z "$WORK_DIR" ]]; then
        WORK_DIR="$(mktemp -d -t custom-linux-update.XXXXXXXX)"
    fi
}

ensure_state_layout() {
    mkdir -p -- \
        "$VERSION_ROOT" \
        "$STAGING_ROOT" \
        "$PIN_ROOT"
}

ensure_mutation_privileges() {
    if [[ "$UPDATE_ENVIRONMENT" == "build" ]]; then
        die "CA-UPD-ENV-002" \
            "Im Build-System werden die Quellskripte über Git verwaltet. Der Release-Updater verändert dort keine Projektdateien."
    fi

    if (( EUID == 0 )); then
        return 0
    fi

    command -v sudo >/dev/null 2>&1 ||
        die "CA-UPD-SUDO-001" "Für diese Update-Aktion werden Root-Rechte benötigt und sudo fehlt."

    info "Für diese Update-Aktion werden Administratorrechte benötigt."
    # Pass the already detected environment explicitly across sudo. This keeps
    # menu-driven Live/Installed/Build behavior deterministic.
    exec sudo -- env CUSTOM_UPDATE_ENVIRONMENT="$UPDATE_ENVIRONMENT" "$SCRIPT_PATH" "$@"
}

acquire_update_lock() {
    ensure_state_layout
    exec {LOCK_FD}>"$STATE_ROOT/update.lock"
    flock -n "$LOCK_FD" ||
        die "CA-UPD-LOCK-001" "Es läuft bereits ein Custom-Linux-Update."
}

validate_semver3() {
    [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]
}

version_cmp() {
    local left="$1"
    local right="$2"
    local l1 l2 l3 r1 r2 r3

    validate_semver3 "$left" || return 2
    validate_semver3 "$right" || return 2

    IFS=. read -r l1 l2 l3 <<<"$left"
    IFS=. read -r r1 r2 r3 <<<"$right"

    l1=$((10#$l1)); l2=$((10#$l2)); l3=$((10#$l3))
    r1=$((10#$r1)); r2=$((10#$r2)); r3=$((10#$r3))

    if (( l1 < r1 )); then printf '%s\n' -1; return 0; fi
    if (( l1 > r1 )); then printf '%s\n' 1; return 0; fi
    if (( l2 < r2 )); then printf '%s\n' -1; return 0; fi
    if (( l2 > r2 )); then printf '%s\n' 1; return 0; fi
    if (( l3 < r3 )); then printf '%s\n' -1; return 0; fi
    if (( l3 > r3 )); then printf '%s\n' 1; return 0; fi
    printf '%s\n' 0
}

version_ge() {
    local cmp
    cmp="$(version_cmp "$1" "$2")" || return 1
    (( cmp >= 0 ))
}

version_lt() {
    local cmp
    cmp="$(version_cmp "$1" "$2")" || return 1
    (( cmp < 0 ))
}

validate_release_version_label() {
    [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9]+)*$ ]]
}

validate_relative_path() {
    local path="$1"

    [[ -n "$path" ]] || return 1
    [[ "$path" != /* ]] || return 1
    [[ "$path" != *"://"* ]] || return 1
    [[ "$path" != *"//"* ]] || return 1
    [[ "$path" != "." && "$path" != ./* && "$path" != */./* && "$path" != */. ]] || return 1
    [[ "$path" != ".." ]] || return 1
    [[ "$path" != ../* ]] || return 1
    [[ "$path" != */../* ]] || return 1
    [[ "$path" != */.. ]] || return 1
    [[ "$path" != */ ]] || return 1
    [[ "$path" != *$'\n'* ]] || return 1
    [[ "$path" =~ ^[A-Za-z0-9._/-]+$ ]]
}

validate_channel() {
    case "$1" in
        stable|testing)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

load_system_manifest() {
    [[ -s "$SYSTEM_MANIFEST" ]] ||
        die "CA-COMP-LOCAL-001" "Systemmanifest fehlt oder ist leer: $SYSTEM_MANIFEST"

    jq -e \
        --argjson schema "$SUPPORTED_SYSTEM_MANIFEST_SCHEMA" \
        'type == "object"
         and .manifest_schema == $schema
         and (.system_version | type == "string")
         and (.build_id | type == "string")
         and (.git_commit | type == "string")
         and (.git_dirty | type == "boolean")
         and (.architecture | type == "string")
         and (.bootstrap_version | type == "string")
         and (.update_api | type == "number" and . >= 0 and . == floor)
         and (.config_schema | type == "number" and . >= 0 and . == floor)
         and (.bundled_script_version | type == "string")
         and (.capabilities | type == "array")
         and all(.capabilities[]; type == "string")
         and ((.capabilities | unique | length) == (.capabilities | length))' \
        "$SYSTEM_MANIFEST" >/dev/null ||
        die "CA-COMP-LOCAL-001" "Systemmanifest ist ungültig oder verwendet ein nicht unterstütztes Schema."

    SYSTEM_VERSION="$(jq -r '.system_version' "$SYSTEM_MANIFEST")"
    SYSTEM_ARCH="$(jq -r '.architecture' "$SYSTEM_MANIFEST")"
    SYSTEM_BOOTSTRAP_VERSION="$(jq -r '.bootstrap_version' "$SYSTEM_MANIFEST")"
    SYSTEM_UPDATE_API="$(jq -r '.update_api' "$SYSTEM_MANIFEST")"
    SYSTEM_CONFIG_SCHEMA="$(jq -r '.config_schema' "$SYSTEM_MANIFEST")"
    BUNDLED_SCRIPT_VERSION="$(jq -r '.bundled_script_version' "$SYSTEM_MANIFEST")"

    validate_semver3 "$SYSTEM_VERSION" ||
        die "CA-COMP-VERSION-001" "Ungültige Systemversion im Systemmanifest: $SYSTEM_VERSION"
    validate_semver3 "$SYSTEM_BOOTSTRAP_VERSION" ||
        die "CA-COMP-VERSION-001" "Ungültige Bootstrap-Version im Systemmanifest: $SYSTEM_BOOTSTRAP_VERSION"
    validate_release_version_label "$BUNDLED_SCRIPT_VERSION" ||
        die "CA-COMP-VERSION-001" "Ungültige gebündelte Script-Version: $BUNDLED_SCRIPT_VERSION"

    [[ "$SYSTEM_ARCH" == "$(uname -m)" ]] ||
        die "CA-COMP-ARCH-LOCAL-001" \
            "Systemmanifest meldet Architektur '$SYSTEM_ARCH', tatsächlich läuft '$(uname -m)'."

    [[ "$SYSTEM_BOOTSTRAP_VERSION" == "$BOOTSTRAP_VERSION" ]] ||
        die "CA-COMP-BOOTSTRAP-LOCAL-001" \
            "Systemmanifest und Bootstrap stimmen nicht überein: Manifest=$SYSTEM_BOOTSTRAP_VERSION, Bootstrap=$BOOTSTRAP_VERSION"

    (( SYSTEM_UPDATE_API == SUPPORTED_UPDATE_API )) ||
        die "CA-COMP-API-LOCAL-001" \
            "Systemmanifest und Bootstrap verwenden unterschiedliche Update-APIs."
}

check_trust_configuration() {
    local identity key_type key_data rest
    local found=0
    local key_file

    [[ -s "$ALLOWED_SIGNERS_FILE" ]] ||
        die "CA-UPD-SIG-LOCAL-001" \
            "Datei mit erlaubtem Update-Signierschlüssel fehlt oder ist leer: $ALLOWED_SIGNERS_FILE"

    key_file="$WORK_DIR/allowed-signer.pub"

    while IFS=$' \t' read -r identity key_type key_data rest; do
        [[ -n "${identity:-}" ]] || continue
        [[ "$identity" != \#* ]] || continue
        [[ "$identity" == "$SIGNER_IDENTITY" ]] || continue

        found=1
        case "$key_type" in
            ssh-ed25519|ssh-rsa|ecdsa-sha2-*) ;;
            *)
                die "CA-UPD-SIG-LOCAL-001" \
                    "Nicht unterstützter öffentlicher Schlüsseltyp für '$SIGNER_IDENTITY': $key_type"
                ;;
        esac

        [[ -n "${key_data:-}" && "$key_data" != "PUBLIC_KEY_DATA" ]] ||
            die "CA-UPD-SIG-LOCAL-001" \
                "Öffentlicher Update-Prüfschlüssel ist noch ein Platzhalter."

        [[ "$key_data" =~ ^[A-Za-z0-9+/]+={0,2}$ ]] ||
            die "CA-UPD-SIG-LOCAL-001" \
                "Öffentlicher Schlüssel für '$SIGNER_IDENTITY' hat kein gültiges Base64-Format."

        printf '%s %s\n' "$key_type" "$key_data" >"$key_file"
        ssh-keygen -l -f "$key_file" >/dev/null 2>&1 ||
            die "CA-UPD-SIG-LOCAL-001" \
                "Öffentlicher Update-Prüfschlüssel konnte von OpenSSH nicht gelesen werden."
    done <"$ALLOWED_SIGNERS_FILE"

    (( found > 0 )) ||
        die "CA-UPD-SIG-LOCAL-001" \
            "Kein gültiger Signierer '$SIGNER_IDENTITY' in $ALLOWED_SIGNERS_FILE gefunden."
}


allowed_curl_protocols() {
    if [[ "${CUSTOM_UPDATE_ALLOW_FILE_URL:-0}" == "1" ]]; then
        printf '%s\n' '=https,file'
    else
        printf '%s\n' '=https'
    fi
}

validate_base_url() {
    if [[ "$BASE_URL" == *"example.invalid"* ]]; then
        die "CA-UPD-CONFIG-001" "Update-Adresse ist noch ein Platzhalter: $BASE_URL"
    fi

    if [[ "$BASE_URL" == https://* ]]; then
        return 0
    fi

    if [[ "${CUSTOM_UPDATE_ALLOW_FILE_URL:-0}" == "1" && "$BASE_URL" == file://* ]]; then
        return 0
    fi

    die "CA-UPD-URL-001" "Update-Basis-URL ist nicht erlaubt: $BASE_URL"
}

join_url() {
    local relative="$1"
    validate_relative_path "$relative" ||
        die "CA-UPD-URL-002" "Unsicherer relativer Update-Pfad: $relative"
    printf '%s/%s\n' "${BASE_URL%/}" "$relative"
}

download_file() {
    local url="$1"
    local destination="$2"
    local protocols
    local temp_file="${destination}.part.$$"

    protocols="$(allowed_curl_protocols)"

    rm -f -- "$temp_file"

    # Offline USB updates use direct file copies instead of curl file:// URLs.
    # This also works reliably for mount paths containing spaces.
    if [[ "$url" == file://* ]]; then
        local local_source="${url#file://}"
        [[ "${CUSTOM_UPDATE_ALLOW_FILE_URL:-0}" == "1" ]] ||
            die "CA-UPD-URL-001" "Lokale Updatequelle ist nicht erlaubt."
        if ! cp -- "$local_source" "$temp_file"; then
            rm -f -- "$temp_file"
            die "CA-UPD-NET-001" "Lokale Update-Datei konnte nicht gelesen werden: $local_source"
        fi
    elif ! curl \
        --fail \
        --location \
        --silent \
        --show-error \
        --proto "$protocols" \
        --proto-redir "$protocols" \
        --connect-timeout 10 \
        --max-time 90 \
        --retry 2 \
        --output "$temp_file" \
        "$url"; then
        rm -f -- "$temp_file"
        die "CA-UPD-NET-001" "Download fehlgeschlagen: $url"
    fi

    [[ -s "$temp_file" ]] || {
        rm -f -- "$temp_file"
        die "CA-UPD-DATA-001" "Heruntergeladene Datei ist leer: $url"
    }

    mv -f -- "$temp_file" "$destination"
}

verify_signature() {
    local file="$1"
    local signature="$2"
    local namespace="$3"

    [[ -s "$file" && -s "$signature" ]] ||
        die "CA-UPD-SIG-001" "Datei oder Signatur fehlt für die Signaturprüfung."

    case "$namespace" in
        "$SIGN_NAMESPACE_INDEX"|"$SIGN_NAMESPACE_RELEASE") ;;
        *) die "CA-UPD-SIG-LOCAL-001" "Interner unbekannter Signatur-Namespace: $namespace" ;;
    esac

    if ! ssh-keygen \
        -Y verify \
        -f "$ALLOWED_SIGNERS_FILE" \
        -I "$SIGNER_IDENTITY" \
        -n "$namespace" \
        -s "$signature" \
        <"$file" >/dev/null 2>&1; then
        die "CA-UPD-SIG-001" "Ungültige Update-Signatur. Das Update wird nicht verwendet."
    fi
}

fetch_index() {
    local index_url signature_url
    local index_file="$WORK_DIR/update-index.json"
    local signature_file="$WORK_DIR/update-index.json.sig"

    index_url="$(join_url "update-index.json")"
    signature_url="$(join_url "update-index.json.sig")"

    info "Lade signierten Update-Index."
    download_file "$index_url" "$index_file"
    download_file "$signature_url" "$signature_file"
    verify_signature "$index_file" "$signature_file" "$SIGN_NAMESPACE_INDEX"

    jq -e \
        --argjson schema "$SUPPORTED_INDEX_SCHEMA" \
        '.index_schema == $schema
         and (.generated_at | type == "string")
         and (.channels | type == "object")
         and (.channels.stable | type == "array")
         and (.channels.testing | type == "array")
         and all(.channels.stable[], .channels.testing[];
             type == "object"
             and (.version | type == "string")
             and (.manifest | type == "string"))
         and (([.channels.stable[].version] | unique | length) == (.channels.stable | length))
         and (([.channels.testing[].version] | unique | length) == (.channels.testing | length))' \
        "$index_file" >/dev/null ||
        die "CA-UPD-INDEX-001" "Update-Index ist ungültig oder verwendet ein nicht unterstütztes Schema."

    printf '%s\n' "$index_file"
}

validate_release_manifest() {
    local manifest="$1"

    jq -e \
        --argjson schema "$SUPPORTED_RELEASE_MANIFEST_SCHEMA" \
        '.manifest_schema == $schema
         and (.script_version | type == "string")
         and (.channel | type == "string")
         and (.created_at | type == "string")
         and (.archive | type == "string")
         and (.archive_sha256 | type == "string")
         and (.requires | type == "object")
         and (.requires.architecture | type == "string")
         and (.requires.update_api | type == "number" and . >= 0 and . == floor)
         and (.requires.system.min_inclusive | type == "string")
         and (.requires.system.max_exclusive | type == "string")
         and (.requires.bootstrap.min_inclusive | type == "string")
         and (.requires.bootstrap.max_exclusive | type == "string")
         and (.requires.config_schema.min | type == "number" and . >= 0 and . == floor)
         and (.requires.config_schema.max | type == "number" and . >= 0 and . == floor)
         and (.requires.capabilities | type == "array")
         and all(.requires.capabilities[]; type == "string")
         and ((.requires.capabilities | unique | length) == (.requires.capabilities | length))
         and (.runtime_requirements.packages | type == "array")
         and all(.runtime_requirements.packages[]; type == "string")
         and ((.runtime_requirements.packages | unique | length) == (.runtime_requirements.packages | length))
         and (.runtime_requirements.commands | type == "array")
         and all(.runtime_requirements.commands[]; type == "string")
         and ((.runtime_requirements.commands | unique | length) == (.runtime_requirements.commands | length))
         and (.files | type == "array")
         and (.files | length > 0)
         and (([.files[].path] | unique | length) == (.files | length))
         and all(.files[];
             (.path | type == "string")
             and (.sha256 | type == "string")
             and (.mode | type == "string"))' \
        "$manifest" >/dev/null ||
        die "CA-UPD-MANIFEST-001" "Release-Manifest ist ungültig oder verwendet ein nicht unterstütztes Schema."

    local version channel archive archive_sha system_min system_max bootstrap_min bootstrap_max
    version="$(jq -r '.script_version' "$manifest")"
    channel="$(jq -r '.channel' "$manifest")"
    archive="$(jq -r '.archive' "$manifest")"
    archive_sha="$(jq -r '.archive_sha256' "$manifest")"
    system_min="$(jq -r '.requires.system.min_inclusive' "$manifest")"
    system_max="$(jq -r '.requires.system.max_exclusive' "$manifest")"
    bootstrap_min="$(jq -r '.requires.bootstrap.min_inclusive' "$manifest")"
    bootstrap_max="$(jq -r '.requires.bootstrap.max_exclusive' "$manifest")"

    validate_release_version_label "$version" ||
        die "CA-COMP-VERSION-001" "Ungültige Script-Version im Release-Manifest: $version"
    validate_channel "$channel" ||
        die "CA-UPD-MANIFEST-001" "Ungültiger Release-Kanal: $channel"
    if [[ "$channel" == "stable" ]]; then
        validate_semver3 "$version" ||
            die "CA-COMP-VERSION-001" "Stable-Releases benötigen eine numerische x.y.z-Version: $version"
    fi
    validate_relative_path "$archive" ||
        die "CA-UPD-MANIFEST-001" "Unsicherer Archivpfad im Release-Manifest: $archive"
    [[ "$archive_sha" =~ ^[0-9a-fA-F]{64}$ ]] ||
        die "CA-UPD-MANIFEST-001" "Ungültiger SHA-256-Wert für das Release-Archiv."

        if ! validate_semver3 "$system_min" || ! validate_semver3 "$system_max"; then
        die "CA-COMP-VERSION-001" \
            "Ungültiger System-Kompatibilitätsbereich im Release-Manifest."
    fi

    if ! validate_semver3 "$bootstrap_min" || ! validate_semver3 "$bootstrap_max"; then
        die "CA-COMP-VERSION-001" \
            "Ungültiger Bootstrap-Kompatibilitätsbereich im Release-Manifest."
    fi

    version_lt "$system_min" "$system_max" ||
        die "CA-UPD-MANIFEST-001" \
            "System-Kompatibilitätsbereich ist leer oder umgekehrt: $system_min .. $system_max"

    version_lt "$bootstrap_min" "$bootstrap_max" ||
        die "CA-UPD-MANIFEST-001" \
            "Bootstrap-Kompatibilitätsbereich ist leer oder umgekehrt: $bootstrap_min .. $bootstrap_max"

    local config_min config_max
    config_min="$(jq -r '.requires.config_schema.min' "$manifest")"
    config_max="$(jq -r '.requires.config_schema.max' "$manifest")"
    (( config_min <= config_max )) ||
        die "CA-UPD-MANIFEST-001" "Config-Schema-Bereich ist leer oder umgekehrt: $config_min .. $config_max"

    while IFS=$'\t' read -r path hash mode; do
        validate_relative_path "$path" ||
            die "CA-UPD-MANIFEST-001" "Unsicherer Dateipfad im Release-Manifest: $path"
        [[ "$hash" =~ ^[0-9a-fA-F]{64}$ ]] ||
            die "CA-UPD-MANIFEST-001" "Ungültiger Datei-SHA-256 für: $path"
        [[ "$mode" == "0644" || "$mode" == "0755" ]] ||
            die "CA-UPD-MANIFEST-001" "Ungültiger Dateimodus für $path: $mode (erlaubt: 0644 oder 0755)"
    done < <(jq -r '.files[] | [.path, .sha256, .mode] | @tsv' "$manifest")
}

fetch_release_manifest() {
    local manifest_rel="$1"
    local output_prefix="$2"
    local manifest_file="$WORK_DIR/${output_prefix}.manifest.json"
    local signature_file="$WORK_DIR/${output_prefix}.manifest.json.sig"

    validate_relative_path "$manifest_rel" ||
        die "CA-UPD-INDEX-002" "Unsicherer Manifestpfad im Update-Index: $manifest_rel"

    download_file "$(join_url "$manifest_rel")" "$manifest_file"
    download_file "$(join_url "${manifest_rel}.sig")" "$signature_file"
    verify_signature "$manifest_file" "$signature_file" "$SIGN_NAMESPACE_RELEASE"
    validate_release_manifest "$manifest_file"

    printf '%s\t%s\n' "$manifest_file" "$signature_file"
}

set_incompatible() {
    COMPAT_CODE="$1"
    COMPAT_REASON="$2"
    return 1
}

check_release_compatibility() {
    local manifest="$1"
    local required_arch required_api system_min system_max bootstrap_min bootstrap_max config_min config_max
    local capability

    COMPAT_CODE=""
    COMPAT_REASON=""

    required_arch="$(jq -r '.requires.architecture' "$manifest")"
    required_api="$(jq -r '.requires.update_api' "$manifest")"
    system_min="$(jq -r '.requires.system.min_inclusive' "$manifest")"
    system_max="$(jq -r '.requires.system.max_exclusive' "$manifest")"
    bootstrap_min="$(jq -r '.requires.bootstrap.min_inclusive' "$manifest")"
    bootstrap_max="$(jq -r '.requires.bootstrap.max_exclusive' "$manifest")"
    config_min="$(jq -r '.requires.config_schema.min' "$manifest")"
    config_max="$(jq -r '.requires.config_schema.max' "$manifest")"

    [[ "$required_arch" == "$SYSTEM_ARCH" ]] ||
        set_incompatible "CA-COMP-ARCH-001" "Architektur benötigt '$required_arch', vorhanden '$SYSTEM_ARCH'." || return 1

    (( required_api == SYSTEM_UPDATE_API )) ||
        set_incompatible "CA-COMP-API-001" "Update-API benötigt '$required_api', vorhanden '$SYSTEM_UPDATE_API'." || return 1

    version_ge "$SYSTEM_VERSION" "$system_min" ||
        set_incompatible "CA-COMP-SYSTEM-001" "Systemversion $SYSTEM_VERSION ist älter als $system_min." || return 1
    version_lt "$SYSTEM_VERSION" "$system_max" ||
        set_incompatible "CA-COMP-SYSTEM-001" "Systemversion $SYSTEM_VERSION liegt nicht unter $system_max." || return 1

    version_ge "$BOOTSTRAP_VERSION" "$bootstrap_min" ||
        set_incompatible "CA-COMP-BOOTSTRAP-001" "Bootstrap $BOOTSTRAP_VERSION ist älter als $bootstrap_min." || return 1
    version_lt "$BOOTSTRAP_VERSION" "$bootstrap_max" ||
        set_incompatible "CA-COMP-BOOTSTRAP-001" "Bootstrap $BOOTSTRAP_VERSION liegt nicht unter $bootstrap_max." || return 1

    (( SYSTEM_CONFIG_SCHEMA >= config_min && SYSTEM_CONFIG_SCHEMA <= config_max )) ||
        set_incompatible "CA-COMP-CONFIG-001" \
            "Config-Schema benötigt $config_min..$config_max, vorhanden $SYSTEM_CONFIG_SCHEMA." || return 1

    while IFS= read -r capability; do
        jq -e --arg capability "$capability" \
            '.capabilities | index($capability) != null' \
            "$SYSTEM_MANIFEST" >/dev/null ||
            set_incompatible "CA-COMP-CAP-001" "Benötigte Fähigkeit fehlt: $capability" || return 1
    done < <(jq -r '.requires.capabilities[]' "$manifest")

    return 0
}

check_runtime_dependencies() {
    local manifest="$1"
    local package command_name
    local missing=()

    DEPENDENCY_REASON=""

    while IFS= read -r package; do
        [[ "$package" =~ ^[A-Za-z0-9@._+:-]+$ ]] ||
            die "CA-UPD-DEP-MANIFEST-001" "Unsicherer Paketname im Release-Manifest: $package"
        pacman -Q -- "$package" >/dev/null 2>&1 || missing+=("Paket:$package")
    done < <(jq -r '.runtime_requirements.packages[]' "$manifest")

    while IFS= read -r command_name; do
        [[ "$command_name" =~ ^[A-Za-z0-9._+-]+$ ]] ||
            die "CA-UPD-DEP-MANIFEST-001" "Unsicherer Befehlsname im Release-Manifest: $command_name"
        command -v "$command_name" >/dev/null 2>&1 || missing+=("Befehl:$command_name")
    done < <(jq -r '.runtime_requirements.commands[]' "$manifest")

    if (( ${#missing[@]} > 0 )); then
        DEPENDENCY_REASON="$(IFS=', '; printf '%s' "${missing[*]}")"
        return 1
    fi

    return 0
}

install_runtime_packages() {
    local manifest="$1"
    local package
    local missing_packages=()

    while IFS= read -r package; do
        [[ "$package" =~ ^[A-Za-z0-9@._+:-]+$ ]] ||
            die "CA-UPD-DEP-MANIFEST-001" "Unsicherer Paketname im Release-Manifest: $package"

        pacman -Q -- "$package" >/dev/null 2>&1 ||
            missing_packages+=("$package")
    done < <(jq -r '.runtime_requirements.packages[]' "$manifest")

    if (( ${#missing_packages[@]} == 0 )); then
        return 0
    fi

    info "Installiere fehlende Pakete aus dem signierten Release-Manifest:"
    printf '  - %s\n' "${missing_packages[@]}"

    pacman -S --needed --noconfirm -- "${missing_packages[@]}" ||
        die "CA-UPD-DEP-INSTALL-001" "Fehlende Pakete konnten nicht installiert werden."
}

find_latest_compatible_release() {
    local index_file="$1"
    local channel="$2"
    local version manifest_rel fetched manifest_file signature_file counter=0
    local entries_file="$WORK_DIR/index-${channel}-entries.tsv"
    local sorted_file="$WORK_DIR/index-${channel}-entries.sorted.tsv"

    SELECTED_VERSION=""
    SELECTED_CHANNEL="$channel"
    SELECTED_MANIFEST_REL=""
    SELECTED_MANIFEST_FILE=""
    SELECTED_MANIFEST_SIG_FILE=""

    validate_channel "$channel" ||
        die "CA-UPD-CHANNEL-001" "Unbekannter Update-Kanal: $channel"

    jq -r --arg channel "$channel"         '.channels[$channel][] | [.version,.manifest] | @tsv'         "$index_file" >"$entries_file"

    while IFS=$'\t' read -r version manifest_rel; do
        if [[ "$channel" == "stable" ]]; then
            validate_semver3 "$version" ||
                die "CA-UPD-INDEX-002" "Stable-Index enthält keine numerische x.y.z-Version: $version"
        else
            validate_release_version_label "$version" ||
                die "CA-UPD-INDEX-002" "Testing-Index enthält eine ungültige Versionsangabe: $version"
        fi
    done <"$entries_file"

    # Version-sort makes selection deterministic even if an older release was
    # added to the signed index after a newer one. Testing naming should remain
    # version-sortable (for example 0.2.5-rc1, 0.2.5-rc2).
    sort -t $'\t' -k1,1Vr "$entries_file" >"$sorted_file"

    while IFS=$'\t' read -r version manifest_rel; do
        [[ -n "$version" ]] || continue
        counter=$((counter + 1))

        validate_release_version_label "$version" ||
            die "CA-UPD-INDEX-002" "Ungültige Versionsangabe im Update-Index: $version"
        validate_relative_path "$manifest_rel" ||
            die "CA-UPD-INDEX-002" "Unsicherer Manifestpfad im Update-Index: $manifest_rel"

        info "Prüfe Release $version ($channel)."
        fetched="$(fetch_release_manifest "$manifest_rel" "candidate-$counter")"
        IFS=$'\t' read -r manifest_file signature_file <<<"$fetched"

        [[ "$(jq -r '.script_version' "$manifest_file")" == "$version" ]] ||
            die "CA-UPD-INDEX-003" "Index und Release-Manifest nennen unterschiedliche Versionen."
        [[ "$(jq -r '.channel' "$manifest_file")" == "$channel" ]] ||
            die "CA-UPD-INDEX-003" "Index und Release-Manifest nennen unterschiedliche Kanäle."

        if check_release_compatibility "$manifest_file"; then
            SELECTED_VERSION="$version"
            SELECTED_MANIFEST_REL="$manifest_rel"
            SELECTED_MANIFEST_FILE="$manifest_file"
            SELECTED_MANIFEST_SIG_FILE="$signature_file"
            return 0
        fi

        printf '[NICHT KOMPATIBEL] %s: [%s] %s\n'             "$version" "$COMPAT_CODE" "$COMPAT_REASON"
    done <"$sorted_file"

    return 1
}

current_version() {
    local current_target

    if [[ -L "$CURRENT_LINK" ]]; then
        current_target="$(readlink -f -- "$CURRENT_LINK" 2>/dev/null || true)"
        if [[ -n "$current_target" && -s "$current_target/release-manifest.json" ]]; then
            jq -r '.script_version' "$current_target/release-manifest.json" 2>/dev/null || true
            return
        fi
    fi

    printf '%s\n' "$BUNDLED_SCRIPT_VERSION"
}

manifest_directory_relative() {
    local manifest_rel="$1"
    local dir
    dir="$(dirname -- "$manifest_rel")"
    [[ "$dir" == "." ]] && dir=""
    printf '%s\n' "$dir"
}

verify_archive_safety() {
    local archive="$1"
    local listing="$WORK_DIR/archive-list.txt"
    local verbose="$WORK_DIR/archive-verbose.txt"
    local entry

    tar -tzf "$archive" >"$listing" ||
        die "CA-UPD-DATA-002" "Release-Archiv kann nicht gelesen werden."
    tar -tvzf "$archive" >"$verbose" ||
        die "CA-UPD-DATA-002" "Release-Archiv kann nicht geprüft werden."

    while IFS= read -r entry; do
        validate_relative_path "${entry%/}" ||
            die "CA-UPD-DATA-003" "Unsicherer Pfad im Release-Archiv: $entry"
    done <"$listing"

    if awk 'substr($1,1,1) != "-" && substr($1,1,1) != "d" { bad=1 } END { exit bad ? 0 : 1 }' "$verbose"; then
        die "CA-UPD-DATA-003" "Release-Archiv enthält Links oder spezielle Dateitypen."
    fi
}

verify_extracted_release() {
    local manifest="$1"
    local release_dir="$2"
    local expected="$WORK_DIR/expected-files.txt"
    local actual="$WORK_DIR/actual-files.txt"
    local path hash mode actual_hash

    if find "$release_dir" -type l -print -quit | grep -q .; then
        die "CA-UPD-DATA-003" "Release enthält unerlaubte symbolische Links."
    fi

    jq -r '.files[].path' "$manifest" | LC_ALL=C sort >"$expected"
    find "$release_dir" -type f -printf '%P\n' | LC_ALL=C sort >"$actual"

    if ! diff -u "$expected" "$actual" >/dev/null; then
        die "CA-UPD-DATA-004" "Dateiliste im Archiv stimmt nicht mit dem signierten Manifest überein."
    fi

    while IFS=$'\t' read -r path hash mode; do
        [[ -f "$release_dir/$path" ]] ||
            die "CA-UPD-DATA-004" "Release-Datei fehlt: $path"

        actual_hash="$(sha256sum -- "$release_dir/$path" | awk '{print $1}')"
        [[ "${actual_hash,,}" == "${hash,,}" ]] ||
            die "CA-UPD-DATA-001" "SHA-256-Prüfung fehlgeschlagen: $path"

        chmod "$mode" -- "$release_dir/$path"
    done < <(jq -r '.files[] | [.path, .sha256, .mode] | @tsv' "$manifest")

    [[ -x "$release_dir/custom-linux-menu.sh" ]] ||
        die "CA-UPD-DATA-004" "Pflichtdatei custom-linux-menu.sh fehlt oder ist nicht ausführbar."

    while IFS= read -r -d '' path; do
        bash -n "$path" ||
            die "CA-UPD-TEST-STATIC-001" "Bash-Syntaxprüfung fehlgeschlagen: ${path#"$release_dir/"}"
    done < <(find "$release_dir" -type f -name '*.sh' -print0)
}

is_target_active() {
    local target="$1"
    local link resolved

    for link in "$CURRENT_LINK" "$PREVIOUS_LINK"; do
        if [[ -L "$link" ]]; then
            resolved="$(readlink -f -- "$link" 2>/dev/null || true)"
            [[ "$resolved" == "$target" ]] && return 0
        fi
    done

    return 1
}

verify_installed_version_dir() {
    local dir="$1"
    local manifest="$dir/release-manifest.json"
    local signature="$dir/release-manifest.json.sig"
    local expected actual

    expected="$WORK_DIR/installed-expected-$(basename -- "$dir").txt"
    actual="$WORK_DIR/installed-actual-$(basename -- "$dir").txt"

    [[ -d "$dir" && -s "$manifest" && -s "$signature" ]] || return 1
    verify_signature "$manifest" "$signature" "$SIGN_NAMESPACE_RELEASE"
    validate_release_manifest "$manifest"
    check_release_compatibility "$manifest" || return 1

    {
        jq -r '.files[].path' "$manifest"
        printf '%s\n' release-manifest.json release-manifest.json.sig
    } | LC_ALL=C sort >"$expected"

    find "$dir" -type f -printf '%P\n'         | grep -Ev '^(\.failed|\.pending)$'         | LC_ALL=C sort >"$actual" || true

    diff -u "$expected" "$actual" >/dev/null || return 1

    local path hash mode actual_hash actual_mode
    while IFS=$'\t' read -r path hash mode; do
        [[ -f "$dir/$path" ]] || return 1
        actual_hash="$(sha256sum -- "$dir/$path" | awk '{print $1}')"
        [[ "${actual_hash,,}" == "${hash,,}" ]] || return 1
        actual_mode="$(stat -c '%a' "$dir/$path")"
        [[ "$actual_mode" == "${mode#0}" ]] || return 1
    done < <(jq -r '.files[] | [.path, .sha256, .mode] | @tsv' "$manifest")

    return 0
}

verify_installed_version_dir_safe() {
    local dir="$1"
    ( verify_installed_version_dir "$dir" ) >/dev/null 2>&1
}

download_and_install_selected_release() {
    local manifest="$SELECTED_MANIFEST_FILE"
    local manifest_rel="$SELECTED_MANIFEST_REL"
    local manifest_dir archive_name archive_rel archive_url archive_file expected_hash actual_hash
    local extract_dir target_dir target_tmp quarantine

    manifest_dir="$(manifest_directory_relative "$manifest_rel")"
    archive_name="$(jq -r '.archive' "$manifest")"
    if [[ -n "$manifest_dir" ]]; then
        archive_rel="$manifest_dir/$archive_name"
    else
        archive_rel="$archive_name"
    fi
    validate_relative_path "$archive_rel" ||
        die "CA-UPD-MANIFEST-001" "Unsicherer zusammengesetzter Archivpfad: $archive_rel"

    archive_url="$(join_url "$archive_rel")"
    archive_file="$WORK_DIR/${SELECTED_VERSION}.tar.gz"

    info "Lade Script-Release $SELECTED_VERSION."
    download_file "$archive_url" "$archive_file"

    expected_hash="$(jq -r '.archive_sha256' "$manifest")"
    actual_hash="$(sha256sum -- "$archive_file" | awk '{print $1}')"
    [[ "${actual_hash,,}" == "${expected_hash,,}" ]] ||
        die "CA-UPD-DATA-001" "SHA-256-Prüfung des Release-Archivs fehlgeschlagen."

    verify_archive_safety "$archive_file"

    extract_dir="$STAGING_ROOT/${SELECTED_VERSION}.extract.$$"
    rm -rf -- "$extract_dir"
    mkdir -p -- "$extract_dir"

    tar -xzf "$archive_file" \
        --no-same-owner \
        --no-same-permissions \
        -C "$extract_dir" ||
        die "CA-UPD-DATA-002" "Release-Archiv konnte nicht entpackt werden."

    verify_extracted_release "$manifest" "$extract_dir"

    cp -- "$SELECTED_MANIFEST_FILE" "$extract_dir/release-manifest.json"
    cp -- "$SELECTED_MANIFEST_SIG_FILE" "$extract_dir/release-manifest.json.sig"
    chmod 0644 "$extract_dir/release-manifest.json" "$extract_dir/release-manifest.json.sig"

    target_dir="$VERSION_ROOT/$SELECTED_VERSION"

    if [[ -e "$target_dir" ]]; then
        if verify_installed_version_dir_safe "$target_dir"; then
            info "Version $SELECTED_VERSION ist bereits vollständig und gültig gespeichert."
            rm -rf -- "$extract_dir"
            printf '%s\n' "$target_dir"
            return 0
        fi

        if is_target_active "$target_dir"; then
            die "CA-UPD-VERSION-001" \
                "Eine aktive gespeicherte Version ist beschädigt und wird nicht automatisch überschrieben: $SELECTED_VERSION"
        fi

        quarantine="$STATE_ROOT/quarantine-${SELECTED_VERSION}-$(date -u +%Y%m%dT%H%M%SZ)"
        mv -- "$target_dir" "$quarantine"
        warn "Beschädigte inaktive Version wurde nach $quarantine verschoben."
    fi

    target_tmp="$VERSION_ROOT/.${SELECTED_VERSION}.new.$$"
    rm -rf -- "$target_tmp"
    mv -- "$extract_dir" "$target_tmp"
    mv -- "$target_tmp" "$target_dir"

    verify_installed_version_dir_safe "$target_dir" ||
        die "CA-UPD-DATA-005" "Installierte Release-Version konnte nach dem Speichern nicht erneut verifiziert werden."

    printf '%s\n' "$target_dir"
}

atomic_set_symlink() {
    local link="$1"
    local target="$2"
    local temp_link="${link}.new.$$"

    rm -f -- "$temp_link"
    ln -s -- "$target" "$temp_link"
    mv -Tf -- "$temp_link" "$link"
}

resolved_link_or_empty() {
    local link="$1"
    if [[ -L "$link" ]]; then
        readlink -f -- "$link" 2>/dev/null || true
    fi
}

write_history() {
    local from="$1"
    local to="$2"
    local channel="$3"
    local result="$4"
    local error_code="${5:-}"
    local timestamp

    timestamp="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
    mkdir -p -- "$STATE_ROOT"

    jq -cn \
        --arg timestamp "$timestamp" \
        --arg from "$from" \
        --arg to "$to" \
        --arg channel "$channel" \
        --arg result "$result" \
        --arg error_code "$error_code" \
        '{timestamp:$timestamp,from:$from,to:$to,channel:$channel,result:$result,error_code:$error_code}' \
        >>"$HISTORY_FILE"
}

mark_failed_version() {
    local dir="$1"
    local code="$2"
    printf '%s\n' "$code" >"$dir/.failed"
    chmod 0644 "$dir/.failed"
}

run_release_smoke_test() {
    local dir="$1"
    local resolved

    resolved="$(readlink -f -- "$dir" 2>/dev/null || true)"
    [[ -n "$resolved" ]] && dir="$resolved"

    [[ -x "$dir/custom-linux-menu.sh" ]] || return 1

    while IFS= read -r -d '' file; do
        bash -n "$file" || return 1
    done < <(find "$dir" -type f -name '*.sh' -print0)

    "$dir/custom-linux-menu.sh" --self-test >/dev/null 2>&1
}

activate_with_test_and_rollback() {
    local new_dir="$1"
    local old_current old_previous from_version

    old_current="$(resolved_link_or_empty "$CURRENT_LINK")"
    old_previous="$(resolved_link_or_empty "$PREVIOUS_LINK")"
    from_version="$(current_version)"

    info "Prüfe neue Script-Version vor der Aktivierung."
    if ! run_release_smoke_test "$new_dir"; then
        update_error "CA-UPD-TEST-001"             "Neue Script-Version hat bereits den Vorab-Funktionstest nicht bestanden. Aktive Version bleibt unverändert."
        mark_failed_version "$new_dir" "CA-UPD-TEST-001"
        write_history "$from_version" "$SELECTED_VERSION" "$SELECTED_CHANNEL" "pre_activation_test_failed" "CA-UPD-TEST-001"
        return 1
    fi

    : >"$new_dir/.pending"

    if [[ -n "$old_current" ]]; then
        atomic_set_symlink "$PREVIOUS_LINK" "$old_current"
    else
        atomic_set_symlink "$PREVIOUS_LINK" "$BUNDLED_DIR"
    fi

    atomic_set_symlink "$CURRENT_LINK" "$new_dir"

    info "Neue Script-Version ist vorläufig aktiv. Starte Funktionstest im aktiven Zustand."
    if run_release_smoke_test "$new_dir"; then
        rm -f -- "$new_dir/.pending"
        write_history "$from_version" "$SELECTED_VERSION" "$SELECTED_CHANNEL" "successful"
        info "Script-Version $SELECTED_VERSION wurde erfolgreich aktiviert."
        return 0
    fi

    update_error "CA-UPD-TEST-001"         "Neue Script-Version hat den Funktionstest nicht bestanden. Automatischer Rollback startet."
    mark_failed_version "$new_dir" "CA-UPD-TEST-001"

    if [[ -n "$old_current" ]]; then
        atomic_set_symlink "$CURRENT_LINK" "$old_current"
    else
        atomic_set_symlink "$CURRENT_LINK" "$BUNDLED_DIR"
    fi

    if [[ -n "$old_previous" ]]; then
        atomic_set_symlink "$PREVIOUS_LINK" "$old_previous"
    else
        rm -f -- "$PREVIOUS_LINK"
    fi

    if run_release_smoke_test "$CURRENT_LINK"; then
        write_history "$from_version" "$SELECTED_VERSION" "$SELECTED_CHANNEL" "rolled_back" "CA-UPD-TEST-001"
        warn "Rollback erfolgreich. Aktive Version: $(current_version)"
        return 1
    fi

    atomic_set_symlink "$CURRENT_LINK" "$BUNDLED_DIR"
    write_history "$from_version" "$SELECTED_VERSION" "$SELECTED_CHANNEL" "rollback_failed_bundled_restored" "CA-UPD-ROLLBACK-001"

    if run_release_smoke_test "$BUNDLED_DIR"; then
        die "CA-UPD-ROLLBACK-001"             "Rollback auf die vorherige Version schlug fehl. Die gebündelte Basisversion wurde aktiviert."
    fi

    die "CA-UPD-ROLLBACK-002"         "Rollback und gebündelte Basisversion sind nicht verwendbar. Manuelle Reparatur erforderlich."
}

recover_interrupted_activation() {
    local current previous interrupted_version from_version

    current="$(resolved_link_or_empty "$CURRENT_LINK")"
    [[ -n "$current" && -e "$current/.pending" ]] || return 0

    interrupted_version="$(jq -r '.script_version // "unknown"' "$current/release-manifest.json" 2>/dev/null || printf 'unknown')"
    from_version="$interrupted_version"
    warn "Unvollständig abgeschlossene Aktivierung erkannt: $interrupted_version"
    mark_failed_version "$current" "CA-UPD-INTERRUPTED-001"

    previous="$(resolved_link_or_empty "$PREVIOUS_LINK")"
    if [[ -n "$previous" ]]; then
        if [[ "$previous" == "$BUNDLED_DIR" ]]; then
            if run_release_smoke_test "$previous"; then
                atomic_set_symlink "$CURRENT_LINK" "$previous"
                write_history "$from_version" "$(current_version)" "recovery" "interrupted_activation_rolled_back" "CA-UPD-INTERRUPTED-001"
                warn "Unterbrochene Aktivierung wurde auf die vorherige Basisversion zurückgerollt."
                return 0
            fi
        elif verify_installed_version_dir_safe "$previous" && run_release_smoke_test "$previous"; then
            atomic_set_symlink "$CURRENT_LINK" "$previous"
            write_history "$from_version" "$(current_version)" "recovery" "interrupted_activation_rolled_back" "CA-UPD-INTERRUPTED-001"
            warn "Unterbrochene Aktivierung wurde auf die vorherige Version zurückgerollt."
            return 0
        fi
    fi

    if run_release_smoke_test "$BUNDLED_DIR"; then
        atomic_set_symlink "$CURRENT_LINK" "$BUNDLED_DIR"
        write_history "$from_version" "$BUNDLED_SCRIPT_VERSION" "recovery" "interrupted_activation_bundled_restored" "CA-UPD-INTERRUPTED-001"
        warn "Unterbrochene Aktivierung: gebündelte Basisversion wurde wiederhergestellt."
        return 0
    fi

    die "CA-UPD-ROLLBACK-002" \
        "Unterbrochene Aktivierung konnte weder auf previous noch auf die gebündelte Basis zurückgerollt werden."
}

prune_old_versions() {
    local current previous dir version keep_count=0
    local delete_target
    local -a candidates=()

    [[ "$VERSION_ROOT" == /* && "$VERSION_ROOT" != "/" ]] ||
        die "CA-UPD-PRUNE-001" \
            "Unsicheres Versionsverzeichnis; automatische Bereinigung wurde abgebrochen: ${VERSION_ROOT:-<leer>}"

    current="$(resolved_link_or_empty "$CURRENT_LINK")"
    previous="$(resolved_link_or_empty "$PREVIOUS_LINK")"

    while IFS= read -r dir; do
        [[ -d "$dir" ]] || continue
        [[ "$dir" == "$current" || "$dir" == "$previous" ]] && continue

        version="$(basename -- "$dir")"

        if ! validate_release_version_label "$version"; then
            warn "Ungültiger Verzeichnisname im Versionsspeicher wird nicht automatisch gelöscht: $version"
            continue
        fi

        [[ -e "$PIN_ROOT/$version" ]] && continue
        candidates+=("$version")
    done < <(find "$VERSION_ROOT" -mindepth 1 -maxdepth 1 -type d -print)

    if (( ${#candidates[@]} <= RETENTION_OLD_VERSIONS )); then
        return 0
    fi

    while IFS= read -r version; do
        keep_count=$((keep_count + 1))

        if (( keep_count > RETENTION_OLD_VERSIONS )); then
            validate_release_version_label "$version" ||
                die "CA-UPD-PRUNE-001" \
                    "Ungültige Versionsangabe vor dem Löschen erkannt: $version"

            delete_target="${VERSION_ROOT:?}/$version"

            [[ "$delete_target" == "$VERSION_ROOT/"* ]] ||
                die "CA-UPD-PRUNE-001" \
                    "Unsicheres Löschziel erkannt; Bereinigung wurde abgebrochen: $delete_target"

            rm -rf -- "$delete_target"
            info "Alte, nicht gepinnte Script-Version entfernt: $version"
        fi
    done < <(printf '%s\n' "${candidates[@]}" | sort -Vr)
}

prepare_local() {
    require_bootstrap_commands
    detect_environment
    ensure_work_dir
    load_system_manifest
}

prepare_trusted_local() {
    prepare_local
    check_trust_configuration
}

prepare_online() {
    prepare_trusted_local
    validate_base_url
}

select_release_for_channel() {
    local channel="$1"
    local index_file

    index_file="$(fetch_index)"

    if ! find_latest_compatible_release "$index_file" "$channel"; then
        die "CA-COMP-NONE-001" "Für dieses System wurde kein kompatibles Release im Kanal '$channel' gefunden."
    fi

    info "Neueste kompatible Version im Kanal '$channel': $SELECTED_VERSION"
}

cmd_check() {
    local channel="${1:-$DEFAULT_CHANNEL}"

    prepare_online
    select_release_for_channel "$channel"

    printf '\n'
    printf 'Umgebung:              %s\n' "$UPDATE_ENVIRONMENT"
    printf 'Systemversion:          %s\n' "$SYSTEM_VERSION"
    printf 'Bootstrap:              %s\n' "$BOOTSTRAP_VERSION"
    printf 'Aktuelle Scripts:       %s\n' "$(current_version)"
    printf 'Kompatibles Release:    %s\n' "$SELECTED_VERSION"
    printf 'Kanal:                  %s\n' "$channel"

    if check_runtime_dependencies "$SELECTED_MANIFEST_FILE"; then
        printf 'Abhängigkeiten:         OK\n'
    else
        printf 'Abhängigkeiten:         BLOCKIERT (%s)\n' "$DEPENDENCY_REASON"
    fi
}

cmd_update_core() {
    local channel="$1"
    local new_dir

    prepare_online
    acquire_update_lock
    recover_interrupted_activation
    select_release_for_channel "$channel"

    if [[ -e "$VERSION_ROOT/$SELECTED_VERSION/.failed" ]]; then
        die "CA-UPD-FAILED-001"             "Release $SELECTED_VERSION ist lokal als fehlerhaft markiert und wird nicht automatisch erneut aktiviert."
    fi

    install_runtime_packages "$SELECTED_MANIFEST_FILE"

    if ! check_runtime_dependencies "$SELECTED_MANIFEST_FILE"; then
        die "CA-UPD-DEP-001" "Fehlende Laufzeitabhängigkeiten nach der Paketinstallation: $DEPENDENCY_REASON"
    fi

    local active_version cmp
    active_version="$(current_version)"

    if [[ "$active_version" == "$SELECTED_VERSION" ]]; then
        info "Die neueste kompatible Version $SELECTED_VERSION ist bereits aktiv."
        return 0
    fi

    # Automatic updates never downgrade a numeric stable version. Downgrades are
    # explicit rollback operations only.
    if validate_semver3 "$active_version" && validate_semver3 "$SELECTED_VERSION"; then
        cmp="$(version_cmp "$SELECTED_VERSION" "$active_version")" ||
            die "CA-COMP-VERSION-001" "Versionen konnten nicht verglichen werden."
        if (( cmp < 0 )); then
            die "CA-UPD-DOWNGRADE-001"                 "Automatisches Downgrade von $active_version auf $SELECTED_VERSION wurde blockiert. Nutze dafür Rollback."
        fi
    fi

    new_dir="$(download_and_install_selected_release)"

    if ! activate_with_test_and_rollback "$new_dir"; then
        return 1
    fi

    prune_old_versions
}

cmd_update() {
    local channel="${1:-$DEFAULT_CHANNEL}"

    detect_environment
    ensure_mutation_privileges update "$channel"
    cmd_update_core "$channel"
}

cmd_offline_update() {
    local directory="$1"
    local channel="${2:-$DEFAULT_CHANNEL}"
    local resolved

    detect_environment
    ensure_mutation_privileges offline-update "$directory" "$channel"

    resolved="$(readlink -f -- "$directory" 2>/dev/null || true)"
    [[ -n "$resolved" && -d "$resolved" ]] ||
        die "CA-UPD-OFFLINE-001" "Offline-Update-Verzeichnis wurde nicht gefunden: $directory"

    BASE_URL="file://$resolved"
    CUSTOM_UPDATE_ALLOW_FILE_URL=1
    cmd_update_core "$channel"
}

print_version_line() {
    local dir="$1"
    local version="$2"
    local flags=()
    local current previous

    current="$(resolved_link_or_empty "$CURRENT_LINK")"
    previous="$(resolved_link_or_empty "$PREVIOUS_LINK")"

    [[ "$dir" == "$current" ]] && flags+=("AKTUELL")
    [[ "$dir" == "$previous" ]] && flags+=("VORHERIGE")
    [[ -e "$PIN_ROOT/$version" ]] && flags+=("GEPINNT")
    [[ -e "$dir/.pending" ]] && flags+=("UNBESTÄTIGT")
    [[ -e "$dir/.failed" ]] && flags+=("FEHLERHAFT")

    if (( ${#flags[@]} == 0 )); then
        printf '%-18s %s\n' "$version" "gespeichert"
    else
        printf '%-18s %s\n' "$version" "$(IFS=' / '; printf '%s' "${flags[*]}")"
    fi
}

cmd_versions() {
    local dir version

    prepare_local

    printf 'Script-Versionen\n'
    printf '===============\n\n'
    printf '%-18s %s\n' "$BUNDLED_SCRIPT_VERSION" "ISO/System-Basis (garantierter Fallback)"

    [[ -d "$VERSION_ROOT" ]] || return 0

    while IFS= read -r dir; do
        version="$(basename -- "$dir")"
        print_version_line "$dir" "$version"
    done < <(find "$VERSION_ROOT" -mindepth 1 -maxdepth 1 -type d -print | sort -V)
}

resolve_rollback_target() {
    local requested="${1:-}"
    local target=""

    if [[ -z "$requested" ]]; then
        target="$(resolved_link_or_empty "$PREVIOUS_LINK")"
        [[ -n "$target" ]] ||
            die "CA-UPD-ROLLBACK-003" "Es ist keine vorherige Version gespeichert."
        printf '%s\n' "$target"
        return 0
    fi

    if [[ "$requested" == "bundled" || "$requested" == "$BUNDLED_SCRIPT_VERSION" ]]; then
        printf '%s\n' "$BUNDLED_DIR"
        return 0
    fi

    validate_release_version_label "$requested" ||
        die "CA-UPD-ROLLBACK-004" "Ungültige Rollback-Version: $requested"

    target="$VERSION_ROOT/$requested"
    [[ -d "$target" ]] ||
        die "CA-UPD-ROLLBACK-004" "Gespeicherte Version nicht gefunden: $requested"

    printf '%s\n' "$target"
}

cmd_rollback() {
    local requested="${1:-}"
    local target old_current old_previous old_version target_version

    detect_environment
    ensure_mutation_privileges rollback "$requested"
    prepare_trusted_local
    acquire_update_lock
    recover_interrupted_activation

    target="$(resolve_rollback_target "$requested")"
    old_current="$(resolved_link_or_empty "$CURRENT_LINK")"
    old_previous="$(resolved_link_or_empty "$PREVIOUS_LINK")"
    old_version="$(current_version)"

    if [[ "$target" != "$BUNDLED_DIR" ]]; then
        verify_installed_version_dir_safe "$target" ||
            die "CA-UPD-ROLLBACK-005" "Zielversion ist beschädigt, unsigniert oder inkompatibel."
        [[ ! -e "$target/.failed" ]] ||
            die "CA-UPD-ROLLBACK-006" "Zielversion ist als fehlerhaft markiert und wird nicht aktiviert."
        target_version="$(jq -r '.script_version' "$target/release-manifest.json")"
    else
        target_version="$BUNDLED_SCRIPT_VERSION"
    fi

    [[ "$target" != "$old_current" ]] || {
        info "Gewählte Version ist bereits aktiv."
        return 0
    }

    if [[ -n "$old_current" ]]; then
        atomic_set_symlink "$PREVIOUS_LINK" "$old_current"
    fi
    atomic_set_symlink "$CURRENT_LINK" "$target"

    if run_release_smoke_test "$target"; then
        write_history "$old_version" "$target_version" "rollback" "successful"
        info "Rollback erfolgreich. Aktive Version: $target_version"
        return 0
    fi

    if [[ -n "$old_current" ]]; then
        atomic_set_symlink "$CURRENT_LINK" "$old_current"
    else
        atomic_set_symlink "$CURRENT_LINK" "$BUNDLED_DIR"
    fi
    if [[ -n "$old_previous" ]]; then
        atomic_set_symlink "$PREVIOUS_LINK" "$old_previous"
    else
        rm -f -- "$PREVIOUS_LINK"
    fi
    die "CA-UPD-ROLLBACK-001" "Rollback-Ziel bestand den Funktionstest nicht; vorherige aktive Version wurde wiederhergestellt."
}

cmd_restore_bundled() {
    local old_current

    require_restore_commands
    detect_environment
    ensure_mutation_privileges restore-bundled
    acquire_update_lock

    [[ -x "$BUNDLED_DIR/custom-linux-menu.sh" ]] ||
        die "CA-UPD-BUNDLED-001" "Gebündelte Basisversion fehlt: $BUNDLED_DIR/custom-linux-menu.sh"

    run_release_smoke_test "$BUNDLED_DIR" ||
        die "CA-UPD-BUNDLED-001" "Gebündelte Basisversion hat den Funktionstest nicht bestanden."

    old_current="$(resolved_link_or_empty "$CURRENT_LINK")"
    if [[ -n "$old_current" && "$old_current" != "$BUNDLED_DIR" ]]; then
        atomic_set_symlink "$PREVIOUS_LINK" "$old_current"
    fi

    atomic_set_symlink "$CURRENT_LINK" "$BUNDLED_DIR"
    info "Gebündelte ISO/System-Basisversion wurde als aktive Script-Basis gesetzt."
}

cmd_pin() {
    local version="$1"

    validate_release_version_label "$version" ||
        die "CA-UPD-PIN-001" "Ungültige Versionsnummer für Pin: $version"
    detect_environment
    ensure_mutation_privileges pin "$version"
    prepare_local
    acquire_update_lock

    [[ -d "$VERSION_ROOT/$version" ]] ||
        die "CA-UPD-PIN-001" "Version ist nicht gespeichert: $version"
    mkdir -p -- "$PIN_ROOT"
    : >"$PIN_ROOT/$version"
    info "Version $version wurde gepinnt."
}

cmd_unpin() {
    local version="$1"

    validate_release_version_label "$version" ||
        die "CA-UPD-PIN-001" "Ungültige Versionsnummer für Unpin: $version"
    detect_environment
    ensure_mutation_privileges unpin "$version"
    prepare_local
    acquire_update_lock

    rm -f -- "$PIN_ROOT/$version"
    info "Pin für Version $version wurde entfernt."
}

cmd_history() {
    prepare_local

    if [[ ! -s "$HISTORY_FILE" ]]; then
        info "Noch keine Update-Historie vorhanden."
        return 0
    fi

    jq -r '[.timestamp,.from,.to,.channel,.result,.error_code] | @tsv' "$HISTORY_FILE"
}

cmd_self_test() {
    # Self-test prüft auch die konfigurierte Basis-URL syntaktisch/gegen
    # Platzhalter, ohne eine Netzwerkverbindung aufzubauen.
    prepare_online

    printf '[OK] Bootstrap-Version: %s\n' "$BOOTSTRAP_VERSION"
    printf '[OK] Umgebung: %s\n' "$UPDATE_ENVIRONMENT"
    printf '[OK] Systemmanifest: %s\n' "$SYSTEM_MANIFEST"
    printf '[OK] Signierer-Konfiguration: %s\n' "$ALLOWED_SIGNERS_FILE"
    printf '[OK] Update-API: %s\n' "$SUPPORTED_UPDATE_API"
}

show_help() {
    cat <<'HELP'
Custom Linux Script-Updater

Aufrufe:
  custom-update.sh check [stable|testing]
  custom-update.sh update [stable|testing]
  custom-update.sh offline-update DIRECTORY [stable|testing]
  custom-update.sh versions
  custom-update.sh rollback [VERSION]
  custom-update.sh restore-bundled
  custom-update.sh pin VERSION
  custom-update.sh unpin VERSION
  custom-update.sh history
  custom-update.sh self-test

Hinweis:
  Die Bootstrap-/Updater-Datei selbst wird nicht durch normale Script-Releases ersetzt.
HELP
}

main() {
    local command="${1:-help}"
    shift || true

    case "$command" in
        check)
            cmd_check "${1:-$DEFAULT_CHANNEL}"
            ;;
        update)
            cmd_update "${1:-$DEFAULT_CHANNEL}"
            ;;
        offline-update)
            [[ $# -ge 1 ]] || die "CA-UPD-ARG-001" "offline-update benötigt ein Verzeichnis."
            cmd_offline_update "$1" "${2:-$DEFAULT_CHANNEL}"
            ;;
        versions)
            cmd_versions
            ;;
        rollback)
            cmd_rollback "${1:-}"
            ;;
        restore-bundled)
            cmd_restore_bundled
            ;;
        pin)
            [[ $# -ge 1 ]] || die "CA-UPD-ARG-001" "pin benötigt eine Versionsnummer."
            cmd_pin "$1"
            ;;
        unpin)
            [[ $# -ge 1 ]] || die "CA-UPD-ARG-001" "unpin benötigt eine Versionsnummer."
            cmd_unpin "$1"
            ;;
        history)
            cmd_history
            ;;
        self-test|--self-test)
            cmd_self_test
            ;;
        help|-h|--help)
            show_help
            ;;
        *)
            die "CA-UPD-ARG-001" "Unbekannter Aufruf: $command"
            ;;
    esac
}

main "$@"
