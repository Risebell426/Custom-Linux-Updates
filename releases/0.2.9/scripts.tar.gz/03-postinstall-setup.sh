#!/usr/bin/env bash

# 03-postinstall-setup.sh
#
# Aufgabe:
# - Wird nach erfolgreichem 02-postinstall-test.sh ausgeführt.
# - Installiert die dauerhaft benötigten Grundsystempakete; optionale Programme verwaltet 04.
# - Richtet KDE Plasma mit frei veränderbaren Einstellungen ein.
# - iNiR kann später bewusst als separater Test aktiviert werden.
#
# Dieses Skript soll als NORMALER Benutzer gestartet werden.
# Root-Rechte werden nur bei Bedarf über sudo angefordert.

set -Eeuo pipefail
IFS=$'\n\t'

TIMESTAMP="$(date -u +'%Y%m%dT%H%M%SZ')"

STATE_DIR="$HOME/.local/state/custom-linux"
LOG_FILE="$STATE_DIR/postinstall-setup-$TIMESTAMP.log"
STEP_STATE_DIR="$STATE_DIR/postinstall-steps"
POSTINSTALL_COMPLETE_MARKER="$STATE_DIR/postinstall-setup.ok"
SYSTEM_UPDATE_TIMESTAMP_FILE="$STATE_DIR/system-update.last-success"

declare -a COMPLETED_STEPS=()
declare -a ALREADY_COMPLETE_STEPS=()
declare -a OPEN_STEPS=()

INIR_REPOSITORY="https://github.com/snowarch/inir.git"
INIR_DIRECTORY="$HOME/Projects/inir"
INSTALL_INIR="${CUSTOM_LINUX_INSTALL_INIR:-0}"

YAY_AUR_REPOSITORY="https://aur.archlinux.org/yay-bin.git"
YAY_AUR_COMMIT="13e0a4754d106a9252b7479bf1b370fbe454fc48"
YAY_PKGBUILD_SHA256="50599630b591adde54221c5961432f8580188615a223c7ef0ee210cdadcd343e"
YAY_SRCINFO_SHA256="c9d52fb99ae60dbbc9962fbfcd251525c177f0a3fc13ee470df8957281dfdee4"

PACMAN_PACKAGES=(
    git
    base-devel
    curl
    wget
    jq
    dialog
    fuse2
    bash-completion
    fish

    plasma-meta
    sddm
    sddm-kcm
    dolphin
    konsole
    kitty
    plasma-firewall

    firefox

    firewalld
)

mkdir -p "$STATE_DIR" "$STEP_STATE_DIR"

exec > >(tee -a "$LOG_FILE") 2>&1

info() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARNUNG] %s\n' "$*" >&2
}

fail() {
    printf '[FEHLER] %s\n' "$*" >&2
    exit 1
}

rc=0
trap '
rc=$?
printf "\n[FEHLER] Zeile %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2
printf "[FEHLER] Abbruch mit Exit-Code %s.\n" "$rc" >&2
printf "[FEHLER] Protokoll: %s\n" "$LOG_FILE" >&2
exit "$rc"
' ERR

check_environment() {
    case "$INSTALL_INIR" in
        0|1)
            ;;
        *)
            fail "CUSTOM_LINUX_INSTALL_INIR muss den Wert 0 oder 1 haben."
            ;;
    esac

    (( EUID != 0 )) ||
        fail "Dieses Skript nicht mit sudo starten.

Richtig:
./03-postinstall-setup.sh"

    [[ -f /var/lib/custom-linux/postinstall-test.ok ]] ||
        fail "Der erfolgreiche Postinstall-Test wurde nicht gefunden.

Zuerst ausführen:
./02-postinstall-test.sh"

    command -v sudo >/dev/null 2>&1 ||
        fail "sudo wurde nicht gefunden."

    command -v pacman >/dev/null 2>&1 ||
        fail "pacman wurde nicht gefunden."

    info "Grundsystem und Postinstall-Test erkannt."
}

confirm_continue_without_step() {
    local label="$1"
    local answer=""

    printf '\n'
    warn "Der Schritt '$label' ist fehlgeschlagen."

    while true; do
        read -r -p \
            "Ohne diesen Teil fortfahren? [y/N] " \
            answer || return 1

        case "${answer,,}" in
            y|yes)
                return 0
                ;;
            ""|n|no)
                return 1
                ;;
            *)
                printf 'Bitte y/yes oder n/no eingeben.\n'
                ;;
        esac
    done
}

# Jeder Installationsschritt läuft in einer eigenen Subshell.
# Dadurch kann ein einzelner Fehler abgefangen werden, ohne dass
# set -e den gesamten Postinstall-Ablauf sofort beendet.
run_step_action() (
    local step_result=0

    trap '
    step_result=$?
    printf "\n[FEHLER] Schrittbefehl in Zeile %s: %s\n" \
        "$LINENO" \
        "$BASH_COMMAND" >&2
    printf "[FEHLER] Exit-Code: %s\n" "$step_result" >&2
    exit "$step_result"
    ' ERR

    set -Eeuo pipefail
    "$@"
)

run_resumable_step() {
    local step_id="$1"
    local label="$2"
    local check_function="$3"
    local action_function="$4"
    local marker="$STEP_STATE_DIR/$step_id.ok"
    local started="$SECONDS"
    local duration=0
    local result=0

    printf '\n'
    info "Prüfe Schritt: $label"

    if "$check_function"; then
        : > "$marker"

        info "Bereits vollständig vorhanden."
        info "Dieser Schritt wird übersprungen."

        ALREADY_COMPLETE_STEPS+=("$label")
        return 0
    fi

    rm -f -- "$marker"

    info "Noch nicht vollständig vorhanden."
    info "Führe diesen Schritt jetzt aus."

    set +e
    run_step_action "$action_function"
    result=$?
    set -e

    duration=$((SECONDS - started))

    if (( result == 0 )); then
        # Statusbasierte Prüfungen dürfen den Marker nach einem
        # erfolgreichen Funktionsaufruf als Nachweis verwenden.
        : > "$marker"

        if "$check_function"; then
            COMPLETED_STEPS+=("$label")

            info "Schritt erfolgreich abgeschlossen."
            printf '[INFO] Schrittzeit: %s Minute(n) und %s Sekunde(n).\n' \
                "$((duration / 60))" \
                "$((duration % 60))"

            return 0
        fi

        rm -f -- "$marker"
        result=1

        warn "Der Befehl endete ohne Fehler, aber die Abschlussprüfung schlug fehl."
    else
        warn "Der Schritt endete mit Exit-Code $result."
    fi

    rm -f -- "$marker"
    OPEN_STEPS+=("$label")

    printf '[WARNUNG] Schrittzeit bis zum Fehler: %s Minute(n) und %s Sekunde(n).\n' \
        "$((duration / 60))" \
        "$((duration % 60))"

    if confirm_continue_without_step "$label"; then
        warn "Das Setup wird ohne '$label' fortgesetzt."
        warn "Beim nächsten Start wird dieser offene Schritt erneut versucht."
        return 0
    fi

    fail "Postinstall-Setup wurde nach '$label' beendet."
}

update_system() {
    info "Aktualisiere das System."

    sudo pacman \
        --sync \
        --refresh \
        --refresh \
        --sysupgrade \
        --needed \
        --noconfirm

    date +%s > "$SYSTEM_UPDATE_TIMESTAMP_FILE"
    info "Zeitpunkt des erfolgreichen Systemupdates wurde gespeichert."
}

install_pacman_packages() {
    info "Installiere die Pakete des Grundsystems."

    sudo pacman \
        --sync \
        --needed \
        --noconfirm \
        "${PACMAN_PACKAGES[@]}"

    info "Pacman-Pakete wurden installiert."
}

configure_shell_completions() {
    local fish_file="/usr/share/fish/vendor_completions.d/custom-linux.fish"
    local bash_file="/usr/share/bash-completion/completions/custom-linux"

    info "Richte Tab-Vervollständigung für Fish und Bash ein."

    sudo install -d -m 0755 \
        "$(dirname -- "$fish_file")" \
        "$(dirname -- "$bash_file")"

    sudo tee "$fish_file" >/dev/null <<'FISH_COMPLETION'
complete -c custom-linux -f
complete -c custom-linux \
    -n 'not __fish_seen_subcommand_from menu main programs tools keyboard update versions status ip ssh git build live installed help' \
    -a '(custom-linux completion fish)'
complete -c custom-linux -s h -l help -d 'Befehlshilfe anzeigen'
FISH_COMPLETION

    sudo tee "$bash_file" >/dev/null <<'BASH_COMPLETION'
_custom_linux_complete() {
    local current="${COMP_WORDS[COMP_CWORD]}"

    COMPREPLY=()

    if (( COMP_CWORD == 1 )); then
        mapfile -t COMPREPLY < <(
            compgen -W "$(custom-linux completion bash)" -- "$current"
        )
    fi
}

complete -F _custom_linux_complete custom-linux
BASH_COMPLETION

    sudo chmod 0644 "$fish_file" "$bash_file"

    info "Tab-Vervollständigung wurde eingerichtet."
}

configure_plasma_desktop() {
    local default_target=""

    info "Richte KDE Plasma als grafische Desktop-Basis ein."

    command -v plasmashell >/dev/null 2>&1 ||
        fail "Plasma Shell wurde nicht gefunden."

    command -v systemsettings >/dev/null 2>&1 ||
        fail "Die grafischen Plasma-Systemeinstellungen wurden nicht gefunden."

    command -v kscreen-doctor >/dev/null 2>&1 ||
        fail "Die Plasma-Bildschirmverwaltung KScreen wurde nicht gefunden."

    command -v sddm >/dev/null 2>&1 ||
        fail "Der grafische Anmeldedienst SDDM wurde nicht gefunden."

    # Auflösung, Skalierung, Bildwiederholrate und Monitoranordnung
    # werden bewusst nicht vorgegeben. Plasma speichert die später
    # grafisch gewählten Werte passend zum Benutzer und Monitor.
    sudo systemctl set-default graphical.target

    # SDDM ersetzt einen eventuell zuvor ausgewählten Display-Manager,
    # wird während dieses laufenden Setups aber noch nicht gestartet.
    sudo systemctl enable --force sddm.service

    default_target="$(systemctl get-default)"

    [[ "$default_target" == "graphical.target" ]] ||
        fail "Der grafische Systemstart wurde nicht als Standard gesetzt."

    systemctl is-enabled sddm.service >/dev/null ||
        fail "SDDM konnte nicht aktiviert werden."

    info "Plasma und SDDM sind für den nächsten Neustart eingerichtet."
    info "Alle Bildschirm- und Designeinstellungen bleiben frei veränderbar."
}

show_firewalld_diagnostics() {
    warn "Status von firewalld:"
    sudo systemctl status firewalld.service --no-pager >&2 || true

    warn "Letzte Meldungen von firewalld:"
    sudo journalctl \
        --unit firewalld.service \
        --boot \
        --no-pager \
        --lines 30 \
        --output cat 2>/dev/null |
        sed -E \
            '/^[[:space:]]*JSON blob:/c\JSON blob: [für die Übersicht gekürzt]' \
            >&2 || true
}

configure_firewall() {
    local running_kernel=""
    local remaining=30
    local ready=0

    info "Aktiviere firewalld."

    running_kernel="$(uname -r)"

    if [[ ! -d "/usr/lib/modules/$running_kernel" ]]; then
        warn "Die Module des laufenden Kernels $running_kernel sind nicht mehr vorhanden."
        warn "Nach dem Systemupdate ist deshalb zuerst ein Neustart erforderlich."
        fail "Bitte neu starten und das Grundsystem-Setup danach erneut ausführen."
    fi

    sudo systemctl enable firewalld.service

    if ! sudo systemctl start firewalld.service; then
        show_firewalld_diagnostics
        fail "firewalld konnte nicht gestartet werden."
    fi

    info "Warte höchstens 30 Sekunden auf die D-Bus-Schnittstelle von firewalld."

    while (( remaining > 0 )); do
        if firewall-cmd --state >/dev/null 2>&1; then
            ready=1
            break
        fi

        if systemctl is-failed firewalld.service >/dev/null 2>&1; then
            break
        fi

        printf '\r[INFO] Verbleibende Wartezeit: %2d Sekunde(n)' "$remaining"
        sleep 1
        remaining=$((remaining - 1))
    done

    printf '\r%*s\r' 60 ''

    if (( ready == 0 )); then
        show_firewalld_diagnostics
        fail "firewalld wurde nicht rechtzeitig betriebsbereit."
    fi

    sudo firewall-cmd --set-default-zone=public

    systemctl is-enabled firewalld.service >/dev/null
    systemctl is-active firewalld.service >/dev/null

    info "firewalld ist mit der Standardzone public aktiviert."
}

install_inir() {
    info "Bereite iNiR vor."

    mkdir -p "$HOME/Projects"

    if [[ -d "$INIR_DIRECTORY/.git" ]]; then
        info "iNiR existiert bereits. Aktualisiere Repository."

        git -C "$INIR_DIRECTORY" pull --ff-only
    elif [[ -e "$INIR_DIRECTORY" ]]; then
        fail "Der Pfad existiert bereits, ist aber kein Git-Repository:
$INIR_DIRECTORY"
    else
        info "Klone iNiR."

        git clone \
            "$INIR_REPOSITORY" \
            "$INIR_DIRECTORY"
    fi

    info "Starte automatische iNiR-Installation."

    cd "$INIR_DIRECTORY"

    ./setup install -y

    # iNiR deaktiviert standardmäßig die eigenen Fensterknöpfe
    # der Anwendungen. Custom Linux lässt diese Knöpfe sichtbar.
    niri_config="$HOME/.config/niri/config.kdl"

    if [[ -f "$niri_config" ]]; then
        sed -i \
            's/^[[:space:]]*prefer-no-csd[[:space:]]*$/\/\/ prefer-no-csd/' \
            "$niri_config"

        if grep -Eq \
            '^[[:space:]]*prefer-no-csd[[:space:]]*$' \
            "$niri_config"; then
            fail "Fensterdekoration konnte nicht aktiviert werden."
        fi

        niri validate

        info "Fensterknöpfe für iNiR wurden aktiviert."
    else
        warn "Niri-Konfiguration wurde nicht gefunden: $niri_config"
    fi

    info "iNiR-Installation abgeschlossen."
}

find_aur_helper() {
    local helper=""

    for helper in paru pikaur yay; do
        if command -v "$helper" >/dev/null 2>&1; then
            printf '%s\n' "$helper"
            return 0
        fi
    done

    return 1
}

install_aur_helper() {
    local existing_helper=""
    local source_directory=""
    local actual_commit=""
    local actual_pkgbuild_hash=""
    local actual_srcinfo_hash=""

    if existing_helper="$(find_aur_helper)"; then
        info "AUR-Helfer ist bereits vorhanden: $existing_helper"
        return 0
    fi

    info "Kein AUR-Helfer gefunden."
    info "Installiere den festgelegten Stand von yay-bin."

    (
        source_directory="$(
            mktemp -d "$STATE_DIR/yay-bin-build.XXXXXX"
        )"

        trap 'rm -rf -- "$source_directory"' EXIT

        git clone \
            "$YAY_AUR_REPOSITORY" \
            "$source_directory"

        git -C "$source_directory" \
            checkout \
            --detach \
            "$YAY_AUR_COMMIT"

        actual_commit="$(
            git -C "$source_directory" rev-parse HEAD
        )"

        [[ "$actual_commit" == "$YAY_AUR_COMMIT" ]] ||
            fail "Der ausgecheckte yay-bin-Commit stimmt nicht.

Erwartet: $YAY_AUR_COMMIT
Gefunden: $actual_commit"

        actual_pkgbuild_hash="$(
            sha256sum "$source_directory/PKGBUILD" |
                awk '{print $1}'
        )"

        [[ "$actual_pkgbuild_hash" == "$YAY_PKGBUILD_SHA256" ]] ||
            fail "Die Prüfsumme des yay-bin-PKGBUILD stimmt nicht.

Erwartet: $YAY_PKGBUILD_SHA256
Gefunden: $actual_pkgbuild_hash"

        actual_srcinfo_hash="$(
            sha256sum "$source_directory/.SRCINFO" |
                awk '{print $1}'
        )"

        [[ "$actual_srcinfo_hash" == "$YAY_SRCINFO_SHA256" ]] ||
            fail "Die Prüfsumme der yay-bin-.SRCINFO stimmt nicht.

Erwartet: $YAY_SRCINFO_SHA256
Gefunden: $actual_srcinfo_hash"

        info "Commit und Paketdefinition von yay-bin wurden geprüft."

        cd "$source_directory"

        makepkg \
            --syncdeps \
            --install \
            --needed \
            --noconfirm
    )

    command -v yay >/dev/null 2>&1 ||
        fail "yay-bin wurde gebaut, aber der Befehl yay fehlt."

    info "yay wurde erfolgreich installiert."
}

configure_browser_bookmarks() {
    # Die Browser sind zu diesem Zeitpunkt bereits installiert.
    #
    # Firefox verwendet genau eine systemweite policies.json innerhalb
    # seines Installationsverzeichnisses. Brave liest einzelne JSON-Dateien
    # aus /etc/brave/policies/managed/.
    #
    # Der Ordner "Custom Linux" gilt für alle bestehenden und später
    # angelegten Browserprofile. Eigene zusätzliche Lesezeichen bleiben
    # weiterhin möglich. Die hier eingetragenen Links selbst werden durch
    # die Browser als verwaltet angezeigt und können nicht gelöscht werden.
    local firefox_policy="/usr/lib/firefox/distribution/policies.json"
    local brave_policy="/etc/brave/policies/managed/custom-linux-bookmarks.json"

    info "Richte vorbereitete Lesezeichen für Firefox und Brave ein."

    sudo install -d -m 0755 \
        /usr/lib/firefox/distribution \
        /etc/brave/policies/managed

    sudo tee "$firefox_policy" >/dev/null <<'FIREFOX_POLICY_JSON'
{
  "policies": {
    "DisplayBookmarksToolbar": "always",
    "ManagedBookmarks": [
      {
        "toplevel_name": "Custom Linux"
      },
      {
        "name": "CardCluster",
        "url": "https://cardcluster.com/"
      },
      {
        "name": "AniWorld",
        "url": "https://aniworld.to/"
      },
      {
        "name": "MangaKakalot – Lesezeichen",
        "url": "https://www.mangakakalot.gg/bookmark"
      },
      {
        "name": "Microsoft 365 Search",
        "url": "https://m365.cloud.microsoft/search"
      },
      {
        "name": "WebUntis – Stundenplan",
        "url": "https://bsh.webuntis.com/WebUntis/?school=bsh#/basic/timetablePublic/class?date=2026-08-24&entityId=11371"
      },
      {
        "name": "TSBW – IT-Ausbildung",
        "url": "https://it.ausbildung.tsbw.de/"
      },
      {
        "name": "iNiR – Originalprojekt",
        "url": "https://github.com/snowarch/iNiR"
      },
      {
        "name": "iNiR426 – Eigener Fork",
        "url": "https://github.com/Risebell426/iNiR426"
      },
      {
        "name": "IHK Flensburg – Ausbildungsportal",
        "url": "https://bildung.ihk-flensburg.de/tibrosBB/BB_auszubildende.jsp?old_url=https://bildung.ihk-flensburg.de/tibrosBB/azubiVtrg.jsp"
      },
      {
        "name": "Arch Linux",
        "url": "https://archlinux.org/"
      },
      {
        "name": "Quickshell",
        "url": "https://quickshell.org/"
      },
      {
        "name": "GIMP",
        "url": "https://www.gimp.org/"
      },
      {
        "name": "Neal.fun",
        "url": "https://neal.fun/"
      }
    ]
  }
}
FIREFOX_POLICY_JSON

    sudo tee "$brave_policy" >/dev/null <<'BRAVE_POLICY_JSON'
{
  "ManagedBookmarks": [
    {
      "toplevel_name": "Custom Linux"
    },
    {
      "name": "CardCluster",
      "url": "https://cardcluster.com/"
    },
    {
      "name": "AniWorld",
      "url": "https://aniworld.to/"
    },
    {
      "name": "MangaKakalot – Lesezeichen",
      "url": "https://www.mangakakalot.gg/bookmark"
    },
    {
      "name": "Microsoft 365 Search",
      "url": "https://m365.cloud.microsoft/search"
    },
    {
      "name": "WebUntis – Stundenplan",
      "url": "https://bsh.webuntis.com/WebUntis/?school=bsh#/basic/timetablePublic/class?date=2026-08-24&entityId=11371"
    },
    {
      "name": "TSBW – IT-Ausbildung",
      "url": "https://it.ausbildung.tsbw.de/"
    },
    {
      "name": "iNiR – Originalprojekt",
      "url": "https://github.com/snowarch/iNiR"
    },
    {
      "name": "iNiR426 – Eigener Fork",
      "url": "https://github.com/Risebell426/iNiR426"
    },
    {
      "name": "IHK Flensburg – Ausbildungsportal",
      "url": "https://bildung.ihk-flensburg.de/tibrosBB/BB_auszubildende.jsp?old_url=https://bildung.ihk-flensburg.de/tibrosBB/azubiVtrg.jsp"
    },
    {
      "name": "Arch Linux",
      "url": "https://archlinux.org/"
    },
    {
      "name": "Quickshell",
      "url": "https://quickshell.org/"
    },
    {
      "name": "GIMP",
      "url": "https://www.gimp.org/"
    },
    {
      "name": "Neal.fun",
      "url": "https://neal.fun/"
    }
  ]
}
BRAVE_POLICY_JSON

    sudo chown root:root \
        "$firefox_policy" \
        "$brave_policy"

    sudo chmod 0644 \
        "$firefox_policy" \
        "$brave_policy"

    info "Browser-Lesezeichen wurden systemweit eingerichtet."
}

# Jede Prüfung kontrolliert nach Möglichkeit den tatsächlichen
# Systemzustand. Statusdateien werden nur für Schritte verwendet,
# deren Ergebnis nicht zuverlässig über Pakete oder Dateien ermittelt
# werden kann.
step_marker_exists() {
    local step_id="$1"

    [[ -f "$STEP_STATE_DIR/$step_id.ok" ]]
}

check_system_update_complete() {
    local current_time=0
    local last_update_time=0
    local maximum_age=$((6 * 60 * 60))

    [[ -f "$SYSTEM_UPDATE_TIMESTAMP_FILE" ]] || return 1

    IFS= read -r last_update_time < "$SYSTEM_UPDATE_TIMESTAMP_FILE" ||
        return 1

    [[ "$last_update_time" =~ ^[0-9]+$ ]] || return 1

    current_time="$(date +%s)" || return 1

    (( last_update_time <= current_time )) || return 1

    (( current_time - last_update_time < maximum_age ))
}

check_pacman_packages_complete() {
    local package=""

    for package in "${PACMAN_PACKAGES[@]}"; do
        pacman -Q "$package" >/dev/null 2>&1 || return 1
    done

    return 0
}

check_shell_completions_complete() {
    local fish_file="/usr/share/fish/vendor_completions.d/custom-linux.fish"
    local bash_file="/usr/share/bash-completion/completions/custom-linux"

    [[ -s "$fish_file" ]] &&
        [[ -s "$bash_file" ]] &&
        grep -Fq \
            'custom-linux completion fish' \
            "$fish_file" &&
        grep -Fq \
            'custom-linux completion bash' \
            "$bash_file"
}

check_plasma_complete() {
    command -v plasmashell >/dev/null 2>&1 &&
        command -v systemsettings >/dev/null 2>&1 &&
        command -v kscreen-doctor >/dev/null 2>&1 &&
        command -v sddm >/dev/null 2>&1 &&
        [[ "$(systemctl get-default 2>/dev/null)" == "graphical.target" ]] &&
        systemctl is-enabled sddm.service >/dev/null 2>&1
}

check_firewall_complete() {
    command -v firewall-cmd >/dev/null 2>&1 &&
        systemctl is-enabled firewalld.service >/dev/null 2>&1 &&
        systemctl is-active firewalld.service >/dev/null 2>&1 &&
        [[ "$(firewall-cmd --get-default-zone 2>/dev/null)" == "public" ]]
}

check_inir_complete() {
    [[ -d "$INIR_DIRECTORY/.git" ]] &&
        [[ -f "$HOME/.config/niri/config.kdl" ]] &&
        command -v niri >/dev/null 2>&1
}

check_aur_helper_complete() {
    find_aur_helper >/dev/null
}

check_browser_bookmarks_complete() {
    local firefox_policy="/usr/lib/firefox/distribution/policies.json"
    local brave_policy="/etc/brave/policies/managed/custom-linux-bookmarks.json"

    command -v jq >/dev/null 2>&1 &&
        [[ -s "$firefox_policy" ]] &&
        [[ -s "$brave_policy" ]] &&
        jq -e \
            '.policies.DisplayBookmarksToolbar == "always" and (.policies.ManagedBookmarks | length > 0)' \
            "$firefox_policy" >/dev/null 2>&1 &&
        jq -e \
            '.ManagedBookmarks | length > 0' \
            "$brave_policy" >/dev/null 2>&1
}

final_check() {
    info "Prüfe Grundsystem und automatisch eingerichtete Komponenten."

    local commands=(
        git
        plasmashell
        systemsettings
        kscreen-doctor
        dolphin
        konsole
        sddm
        firefox
        firewall-cmd
    )

    local command_name
    local errors=0

    for command_name in "${commands[@]}"; do
        if command -v "$command_name" >/dev/null 2>&1; then
            info "Gefunden: $command_name"
        else
            warn "Nicht gefunden: $command_name"
            errors=$((errors + 1))
        fi
    done

    if [[ "$INSTALL_INIR" == "1" ]]; then
        if [[ -d "$INIR_DIRECTORY/.git" ]]; then
            info "Gefunden: iNiR ($INIR_DIRECTORY)"
        else
            warn "Nicht gefunden: iNiR ($INIR_DIRECTORY)"
            errors=$((errors + 1))
        fi
    else
        info "iNiR wurde für den separaten späteren Test übersprungen."
    fi

    printf '\n'

    if (( errors == 0 )); then
        info "Alle vorgesehenen Grundsystem-Komponenten wurden gefunden."
    else
        warn "$errors Grundsystem-Komponente(n) konnten nicht bestätigt werden."
    fi

    info "Postinstall-Setup abgeschlossen."
    info "Protokoll:"
    info "$LOG_FILE"
}

printf 'Custom-Linux Postinstall-Setup\n'
printf '==============================\n\n'

setup_started="$SECONDS"

check_environment

if [[ "$INSTALL_INIR" == "1" ]]; then
    info "Separater iNiR-Modus wurde gestartet."
    info "Der Abschlussstatus des normalen Postinstall-Setups bleibt unverändert."

    run_resumable_step \
        inir \
        "iNiR" \
        check_inir_complete \
        install_inir

    setup_duration=$((SECONDS - setup_started))

    printf '\n'
    printf 'iNiR-Zusammenfassung\n'
    printf '===================\n'
    printf 'Neu abgeschlossen: %s\n' "${#COMPLETED_STEPS[@]}"
    printf 'Bereits vorhanden: %s\n' "${#ALREADY_COMPLETE_STEPS[@]}"
    printf 'Offen und übersprungen: %s\n' "${#OPEN_STEPS[@]}"

    if ((${#OPEN_STEPS[@]} > 0)); then
        printf '\n'
        warn "iNiR ist weiterhin offen."
        warn "Das normale Postinstall-Setup bleibt trotzdem abgeschlossen."
    else
        printf '\n'
        info "iNiR ist vollständig vorhanden."
    fi

    printf '\n[INFO] iNiR-Dauer: %s Minute(n) und %s Sekunde(n).\n' \
        "$((setup_duration / 60))" \
        "$((setup_duration % 60))"

    exit 0
fi

# Ein bestehender Gesamtabschluss wird während einer erneuten Prüfung
# vorübergehend entfernt und erst am erfolgreichen Ende neu gesetzt.
rm -f -- "$POSTINSTALL_COMPLETE_MARKER"

run_resumable_step \
    system-update \
    "System aktualisieren" \
    check_system_update_complete \
    update_system

run_resumable_step \
    pacman-packages \
    "Pakete des Grundsystems" \
    check_pacman_packages_complete \
    install_pacman_packages

run_resumable_step \
    shell-completions \
    "Tab-Vervollständigung für Fish und Bash" \
    check_shell_completions_complete \
    configure_shell_completions

run_resumable_step \
    plasma \
    "KDE Plasma und SDDM" \
    check_plasma_complete \
    configure_plasma_desktop

run_resumable_step \
    firewall \
    "Firewalld" \
    check_firewall_complete \
    configure_firewall

info "iNiR wird unabhängig über den eigenen Menüpunkt verwaltet."

run_resumable_step \
    aur-helper \
    "AUR-Helfer" \
    check_aur_helper_complete \
    install_aur_helper

run_resumable_step \
    browser-bookmarks \
    "Browser-Lesezeichen" \
    check_browser_bookmarks_complete \
    configure_browser_bookmarks

final_check

setup_duration=$((SECONDS - setup_started))

printf '\n'
printf 'Postinstall-Zusammenfassung\n'
printf '===========================\n'
printf 'Neu abgeschlossen: %s\n' "${#COMPLETED_STEPS[@]}"
printf 'Bereits vorhanden: %s\n' "${#ALREADY_COMPLETE_STEPS[@]}"
printf 'Offen und auf Wunsch übersprungen: %s\n' "${#OPEN_STEPS[@]}"

if ((${#COMPLETED_STEPS[@]} > 0)); then
    printf '\nNeu abgeschlossen:\n'
    printf '  - %s\n' "${COMPLETED_STEPS[@]}"
fi

if ((${#ALREADY_COMPLETE_STEPS[@]} > 0)); then
    printf '\nBereits vorhanden und übersprungen:\n'
    printf '  - %s\n' "${ALREADY_COMPLETE_STEPS[@]}"
fi

if ((${#OPEN_STEPS[@]} > 0)); then
    printf '\nOffene Schritte:\n'
    printf '  - %s\n' "${OPEN_STEPS[@]}"

    printf '\n'
    warn "Das Postinstall-Setup wurde mit offenen Schritten beendet."
    warn "Beim nächsten Start werden diese Schritte erneut versucht."

    rm -f -- "$POSTINSTALL_COMPLETE_MARKER"
else
    : > "$POSTINSTALL_COMPLETE_MARKER"

    printf '\n'
    info "Alle ausgewählten Postinstall-Schritte sind vollständig."
    info "Gesamtabschluss wurde gespeichert:"
    info "$POSTINSTALL_COMPLETE_MARKER"
fi

printf '\n[INFO] Gesamtdauer: %s Minute(n) und %s Sekunde(n).\n' \
    "$((setup_duration / 60))" \
    "$((setup_duration % 60))"
