#!/usr/bin/env bash

set -Eeuo pipefail
umask 077

readonly TOOL_ROOT="$HOME/Werkzeuge"
readonly STATE_DIR="$HOME/.local/state/custom-linux/tool-overview"
readonly MANAGED_LIST="$STATE_DIR/managed-launchers.list"
readonly WRAPPER_DIR="$STATE_DIR/wrappers"
readonly BACKUP_ROOT="$STATE_DIR/backups"
readonly PLACES_FILE="${XDG_DATA_HOME:-$HOME/.local/share}/user-places.xbel"
readonly PIN_STATE_FILE="$STATE_DIR/dolphin-pin-created"
readonly GTK_BOOKMARKS_FILE="${XDG_CONFIG_HOME:-$HOME/.config}/gtk-3.0/bookmarks"
readonly NAUTILUS_PIN_STATE_FILE="$STATE_DIR/nautilus-pin-created"
readonly LOCK_FILE="$STATE_DIR/setup.lock"

CATALOG="$(
    cat <<'CATALOG'
brave|Brave Browser|Privat|brave-browser.desktop|brave,brave-browser|brave-bin,brave||brave-desktop|graphical|Brave Browser.desktop
discord|Discord|Privat|discord.desktop|discord|discord||discord|graphical|Discord.desktop
element|Element|Privat|element-desktop.desktop,im.riot.Riot.desktop|element-desktop,element|element-desktop||element|graphical|Element.desktop
prismlauncher|PrismLauncher|Privat|org.prismlauncher.PrismLauncher.desktop,prismlauncher.desktop|prismlauncher|prismlauncher||org.prismlauncher.PrismLauncher|graphical|PrismLauncher.desktop
obsidian|Obsidian|Schule|obsidian.desktop,md.obsidian.Obsidian.desktop|obsidian|obsidian||obsidian|graphical|Obsidian.desktop
powershell|PowerShell|Schule|powershell.desktop|pwsh|powershell-bin,powershell||utilities-terminal|terminal-direct|PowerShell.desktop
mysql-workbench|MySQL Workbench|Schule|mysql-workbench.desktop|mysql-workbench|mysql-workbench||mysql-workbench|graphical|MySQL Workbench.desktop
docker|Docker mit Docker Compose|Schule|docker-desktop.desktop|docker|docker,docker-compose||docker|terminal-info|Docker mit Docker Compose.desktop
vscode|Visual Studio Code|Schule|code.desktop,visual-studio-code.desktop|code|code,visual-studio-code-bin||visual-studio-code|graphical|Visual Studio Code.desktop
arduino-ide|Arduino IDE|Schule|arduino-ide.desktop,cc.arduino.IDE2.desktop|arduino-ide,arduino|arduino-ide-bin,arduino-ide,arduino||arduino-ide|graphical|Arduino IDE.desktop
xampp|XAMPP|Schule|xampp-control-panel.desktop||xampp|/opt/lampp/manager-linux-x64.run,/opt/lampp/manager-linux.run,/opt/lampp/lampp|applications-development|graphical|XAMPP.desktop
wireshark|Wireshark|Sicherheit|org.wireshark.Wireshark.desktop,wireshark.desktop|wireshark|wireshark-qt||org.wireshark.Wireshark|graphical|Wireshark.desktop
tcpdump|tcpdump|Sicherheit||tcpdump|tcpdump||network-wired|terminal-info|tcpdump.desktop
keepassxc|KeePassXC|Sicherheit|org.keepassxc.KeePassXC.desktop,keepassxc.desktop|keepassxc|keepassxc||keepassxc|graphical|KeePassXC.desktop
clamav|ClamAV|Sicherheit||clamscan|clamav||security-high|terminal-info|ClamAV.desktop
lynis|Lynis|Sicherheit||lynis|lynis||security-high|terminal-info|Lynis.desktop
nmap|Nmap|Hacking-Tests||nmap|nmap||network-wired|terminal-info|Nmap.desktop
burpsuite|Burp Suite|Hacking-Tests|burpsuite.desktop,com.portswigger.BurpSuite.desktop|burpsuite|burpsuite||burpsuite|graphical|Burp Suite.desktop
zaproxy|OWASP ZAP|Hacking-Tests|zaproxy.desktop,org.zaproxy.ZAP.desktop|zaproxy,zaproxy.sh|zaproxy||zaproxy|graphical|OWASP ZAP.desktop
sqlmap|SQLMap|Hacking-Tests||sqlmap|sqlmap||security-high|terminal-info|SQLMap.desktop
gobuster|Gobuster|Hacking-Tests||gobuster|gobuster||security-high|terminal-info|Gobuster.desktop
ffuf|ffuf|Hacking-Tests||ffuf|ffuf||security-high|terminal-info|ffuf.desktop
hydra|Hydra|Hacking-Tests||hydra|hydra||security-high|terminal-info|Hydra.desktop
john|John the Ripper|Hacking-Tests||john|john||security-high|terminal-info|John the Ripper.desktop
hashcat|Hashcat|Hacking-Tests||hashcat|hashcat||security-high|terminal-info|Hashcat.desktop
aircrack-ng|Aircrack-ng|Hacking-Tests||aircrack-ng|aircrack-ng||network-wireless|terminal-info|Aircrack-ng.desktop
metasploit|Metasploit Framework|Hacking-Tests||msfconsole|metasploit||security-high|terminal-info|Metasploit Framework.desktop
CATALOG
)"
readonly CATALOG
declare -a APPLICATION_DIRS=()
declare -a FOUND_ITEMS=()
declare -a CORRECT_ITEMS=()
declare -a CHANGED_ITEMS=()
declare -a REMOVED_ITEMS=()
declare -a SKIPPED_ITEMS=()
declare -a FAILED_ITEMS=()

DETECTED_DESKTOP=""
DETECTED_COMMAND=""
DETECTED_SPECIAL_PATH=""
WORK_DIR=""

info() { printf '[INFO] %s\n' "$*"; }
warn() { printf '[WARNUNG] %s\n' "$*" >&2; }

record_failure() {
    FAILED_ITEMS+=("$1")
    warn "$1"
}

build_application_directories() {
    local data_dir=""
    local directory=""
    local -a data_dirs=()
    local -a system_data_dirs=()
    local -A seen=()

    data_dirs+=("${XDG_DATA_HOME:-$HOME/.local/share}")
    IFS=':' read -r -a system_data_dirs <<< \
        "${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"
    data_dirs+=("${system_data_dirs[@]}")

    for data_dir in "${data_dirs[@]}"; do
        [[ -n "$data_dir" ]] || continue
        directory="${data_dir%/}/applications"
        [[ -z "${seen[$directory]:-}" ]] || continue
        seen[$directory]=1
        APPLICATION_DIRS+=("$directory")
    done
}

find_desktop_file() {
    local names_csv="$1"
    local directory=""
    local name=""
    local candidate=""
    local -a names=()

    [[ -n "$names_csv" ]] || return 1
    IFS=',' read -r -a names <<< "$names_csv"

    for directory in "${APPLICATION_DIRS[@]}"; do
        for name in "${names[@]}"; do
            candidate="$directory/$name"
            [[ -f "$candidate" ]] || continue
            grep -Eq '^Hidden=true[[:space:]]*$' "$candidate" && continue
            printf '%s\n' "$candidate"
            return 0
        done
    done

    return 1
}

find_command_path() {
    local names_csv="$1"
    local name=""
    local command_path=""
    local -a names=()

    [[ -n "$names_csv" ]] || return 1
    IFS=',' read -r -a names <<< "$names_csv"

    for name in "${names[@]}"; do
        if command_path="$(command -v "$name" 2>/dev/null)"; then
            printf '%s\n' "$command_path"
            return 0
        fi
    done

    return 1
}

installed_package_exists() {
    local names_csv="$1"
    local name=""
    local -a names=()

    [[ -n "$names_csv" ]] || return 1
    command -v pacman >/dev/null 2>&1 || return 1
    IFS=',' read -r -a names <<< "$names_csv"

    for name in "${names[@]}"; do
        pacman -Q "$name" >/dev/null 2>&1 && return 0
    done

    return 1
}

find_special_path() {
    local paths_csv="$1"
    local path=""
    local -a paths=()

    [[ -n "$paths_csv" ]] || return 1
    IFS=',' read -r -a paths <<< "$paths_csv"

    for path in "${paths[@]}"; do
        if [[ -x "$path" ]]; then
            printf '%s\n' "$path"
            return 0
        fi
    done

    return 1
}

detect_program() {
    local desktop_names="$1"
    local command_names="$2"
    local package_names="$3"
    local special_paths="$4"
    local mode="$5"
    local package_found=0

    DETECTED_DESKTOP="$(find_desktop_file "$desktop_names" || true)"
    DETECTED_COMMAND="$(find_command_path "$command_names" || true)"
    DETECTED_SPECIAL_PATH="$(find_special_path "$special_paths" || true)"

    if installed_package_exists "$package_names"; then
        package_found=1
    fi

    if [[ "$mode" == "graphical" ]]; then
        [[ -n "$DETECTED_DESKTOP" ||
           -n "$DETECTED_SPECIAL_PATH" ||
           "$package_found" -eq 1 ]]
    else
        [[ -n "$DETECTED_DESKTOP" ||
           -n "$DETECTED_COMMAND" ||
           -n "$DETECTED_SPECIAL_PATH" ||
           "$package_found" -eq 1 ]]
    fi
}

desktop_file_is_managed() {
    [[ -f "$1" ]] && grep -Fqx 'X-Custom-Linux-Managed=true' "$1"
}

path_was_managed() {
    [[ -f "$MANAGED_LIST" ]] && grep -Fqx -- "$1" "$MANAGED_LIST"
}

validate_desktop_file() {
    local file="$1"
    local validation_output=""

    if command -v desktop-file-validate >/dev/null 2>&1; then
        if validation_output="$(desktop-file-validate "$file" 2>&1)"; then
            return 0
        fi

        printf '%s\n' "$validation_output" >&2
        return 1
    fi

    grep -Fqx '[Desktop Entry]' "$file" &&
        grep -Eq '^Type=Application[[:space:]]*$' "$file" &&
        grep -Eq '^Name=.+$' "$file" &&
        grep -Eq '^Exec=.+$' "$file"
}

make_copied_desktop_file() {
    local source_file="$1"
    local output_file="$2"

    awk '
        /^\[Desktop Entry\][[:space:]]*$/ && !marker_added {
            print
            print "X-Custom-Linux-Managed=true"
            marker_added = 1
            next
        }

        /^\[/ && marker_added {
            exit
        }

        /^Actions=/ && marker_added {
            next
        }

        { print }

        END {
            if (!marker_added) {
                exit 42
            }
        }
    ' "$source_file" > "$output_file"

    chmod 0755 -- "$output_file"
}

make_terminal_wrapper() {
    local label="$1"
    local command_path="$2"
    local output_file="$3"

    cat > "$output_file" <<EOF
#!/usr/bin/env bash
# Custom-Linux-Managed: tool-overview

set -u
printf '\n%s ist installiert.\n' '$label'
printf 'Startbefehl: %s\n\n' '$command_path'
exec "\${SHELL:-/bin/bash}" -l
EOF

    chmod 0700 -- "$output_file"
}

make_command_desktop_file() {
    local label="$1"
    local executable="$2"
    local icon="$3"
    local mode="$4"
    local wrapper="$5"
    local output_file="$6"
    local terminal="false"
    local exec_value="$executable"

    case "$mode" in
        graphical)
            ;;
        terminal-direct)
            terminal="true"
            ;;
        terminal-info)
            terminal="true"
            exec_value="$wrapper"
            ;;
        *)
            return 1
            ;;
    esac

    [[ "$exec_value" != *[[:space:]]* ]] || return 1

    cat > "$output_file" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=$label
Comment=Von Custom Linux verwalteter Starter
Exec=$exec_value
Icon=$icon
Terminal=$terminal
Categories=Utility;
X-Custom-Linux-Managed=true
EOF

    chmod 0755 -- "$output_file"
}

install_launcher() {
    local generated_file="$1"
    local destination="$2"
    local description="$3"

    if [[ -e "$destination" ]] &&
       ! desktop_file_is_managed "$destination" &&
       ! path_was_managed "$destination"; then
        record_failure "$description: Vorhandene Datei wird nicht überschrieben: $destination"
        return 1
    fi

    if [[ -f "$destination" ]] && cmp -s -- "$generated_file" "$destination"; then
        rm -f -- "$generated_file"
        CORRECT_ITEMS+=("$description")
        return 0
    fi

    mv -f -- "$generated_file" "$destination"
    chmod 0755 -- "$destination"
    CHANGED_ITEMS+=("$description")
}

create_program_launcher() {
    local id="$1"
    local label="$2"
    local category="$3"
    local icon="$4"
    local mode="$5"
    local launcher_name="$6"
    local category_dir="$TOOL_ROOT/$category"
    local destination="$category_dir/$launcher_name"
    local generated_file="$WORK_DIR/$id.desktop"
    local wrapper="$WRAPPER_DIR/$id"
    local generated_wrapper="$WORK_DIR/$id.wrapper"
    local executable=""
    local effective_mode="$mode"

    FOUND_ITEMS+=("$label → $category")
    mkdir -p -- "$category_dir"
    chmod 0755 -- "$TOOL_ROOT" "$category_dir"

    if [[ -n "$DETECTED_DESKTOP" ]]; then
        if ! make_copied_desktop_file "$DETECTED_DESKTOP" "$generated_file"; then
            record_failure "$label: Vorhandener Programmstarter ist ungültig."
            return 1
        fi
    else
        executable="$DETECTED_COMMAND"
        [[ -n "$executable" ]] || executable="$DETECTED_SPECIAL_PATH"

        if [[ -z "$executable" ]]; then
            record_failure "$label: Installiert, aber kein startbarer Befehl wurde gefunden."
            return 1
        fi

        if [[ "$id" == "xampp" && "$executable" == */lampp ]]; then
            effective_mode="terminal-info"
        fi

        if [[ "$effective_mode" == "terminal-info" ]]; then
            make_terminal_wrapper "$label" "$executable" "$generated_wrapper"

            if [[ ! -f "$wrapper" ]] ||
               ! cmp -s -- "$generated_wrapper" "$wrapper"; then
                mv -f -- "$generated_wrapper" "$wrapper"
                chmod 0700 -- "$wrapper"
            else
                rm -f -- "$generated_wrapper"
            fi
        fi

        if ! make_command_desktop_file \
            "$label" "$executable" "$icon" "$effective_mode" \
            "$wrapper" "$generated_file"; then
            record_failure "$label: Sicherer Programmstarter konnte nicht erzeugt werden."
            return 1
        fi
    fi

    if ! validate_desktop_file "$generated_file"; then
        rm -f -- "$generated_file"
        record_failure "$label: Programmstarter hat die Prüfung nicht bestanden."
        return 1
    fi

    if install_launcher "$generated_file" "$destination" "$label → $category"; then
        printf '%s\n' "$destination" >> "$WORK_DIR/new-managed.list"
        if [[ "$effective_mode" == "terminal-info" && -f "$wrapper" ]]; then
            printf '%s\n' "$wrapper" >> "$WORK_DIR/new-wrappers.list"
        fi
        return 0
    fi

    return 1
}

remove_obsolete_launchers() {
    local old_path=""

    [[ -f "$MANAGED_LIST" ]] || return 0

    while IFS= read -r old_path; do
        [[ -n "$old_path" ]] || continue

        case "$old_path" in
            "$TOOL_ROOT"/*/*.desktop)
                ;;
            *)
                record_failure "Ungültiger Verwaltungspfad wurde nicht entfernt: $old_path"
                continue
                ;;
        esac

        grep -Fqx -- "$old_path" "$WORK_DIR/new-managed.list" && continue

        if desktop_file_is_managed "$old_path"; then
            rm -f -- "$old_path"
            REMOVED_ITEMS+=("$old_path")
        elif [[ -e "$old_path" ]]; then
            record_failure "Verwaltungsmarkierung fehlt; nicht entfernt: $old_path"
        fi
    done < "$MANAGED_LIST"
}

remove_obsolete_wrappers() {
    local wrapper=""

    while IFS= read -r -d '' wrapper; do
        grep -Fqx -- "$wrapper" "$WORK_DIR/new-wrappers.list" && continue

        if grep -Fqx '# Custom-Linux-Managed: tool-overview' "$wrapper"; then
            rm -f -- "$wrapper"
        fi
    done < <(find "$WRAPPER_DIR" -maxdepth 1 -type f -print0)
}

remove_empty_directories() {
    local category=""

    for category in Arbeit Privat Schule Sicherheit Hacking-Tests; do
        rmdir -- "$TOOL_ROOT/$category" 2>/dev/null || true
    done
    rmdir -- "$TOOL_ROOT" 2>/dev/null || true
}

urlencode_path() {
    local value="$1"
    local character=""
    local encoded=""
    local index=0
    local numeric=0
    local LC_ALL=C

    for ((index = 0; index < ${#value}; index++)); do
        character="${value:index:1}"
        case "$character" in
            [a-zA-Z0-9._~/-]) encoded+="$character" ;;
            *)
                printf -v numeric '%d' "'$character"
                printf -v character '%%%02X' "$numeric"
                encoded+="$character"
                ;;
        esac
    done

    printf '%s\n' "$encoded"
}

places_file_contains_uri() {
    [[ -f "$PLACES_FILE" ]] && grep -Fq -- "href=\"$1\"" "$PLACES_FILE"
}

validate_places_file() {
    local file="$1"

    if command -v xmllint >/dev/null 2>&1; then
        xmllint --noout "$file"
    elif command -v python3 >/dev/null 2>&1; then
        python3 - "$file" <<'PYTHON'
import sys
import xml.etree.ElementTree as ET
ET.parse(sys.argv[1])
PYTHON
    else
        return 1
    fi
}

backup_places_file() {
    local backup_dir=""

    backup_dir="$BACKUP_ROOT/$(date -u +%Y%m%dT%H%M%SZ)-$$"

    mkdir -p -- "$backup_dir"
    chmod 0700 -- "$BACKUP_ROOT" "$backup_dir"
    cp -a -- "$PLACES_FILE" "$backup_dir/user-places.xbel"
    chmod 0600 -- "$backup_dir/user-places.xbel"
    info "Sicherung erstellt: $backup_dir/user-places.xbel"
}

replace_places_file() {
    local prepared_file="$1"
    local expected_hash="$2"
    local current_hash=""
    local original_mode=""

    if ! validate_places_file "$prepared_file"; then
        rm -f -- "$prepared_file"
        record_failure "Vorbereitete Dolphin-Seitenleistendatei ist ungültig."
        return 1
    fi

    current_hash="$(sha256sum "$PLACES_FILE" | awk '{print $1}')"
    if [[ "$current_hash" != "$expected_hash" ]]; then
        rm -f -- "$prepared_file"
        record_failure "Dolphin-Seitenleiste wurde gleichzeitig verändert; nichts wurde übernommen."
        return 1
    fi

    backup_places_file
    original_mode="$(stat -c '%a' "$PLACES_FILE")"
    chmod "$original_mode" -- "$prepared_file"
    mv -f -- "$prepared_file" "$PLACES_FILE"
}

pin_tools_folder_in_dolphin() {
    local tools_uri=""
    local places_dir=""
    local prepared_file=""
    local bookmark_id=""
    local original_hash=""

    tools_uri="file://$(urlencode_path "$TOOL_ROOT")"
    bookmark_id="$(date +%s)/$$"

    if [[ ! -f "$PLACES_FILE" || -L "$PLACES_FILE" || ! -O "$PLACES_FILE" ]]; then
        record_failure "Dolphin-Seitenleistendatei fehlt: $PLACES_FILE"
        return 1
    fi

    if ! validate_places_file "$PLACES_FILE"; then
        record_failure "Vorhandene Dolphin-Seitenleistendatei ist ungültig."
        return 1
    fi

    if places_file_contains_uri "$tools_uri"; then
        CORRECT_ITEMS+=("Dolphin-Verknüpfung → Werkzeuge")
        return 0
    fi

    places_dir="$(dirname -- "$PLACES_FILE")"
    prepared_file="$(mktemp "$places_dir/.user-places.xbel.custom-linux.XXXXXXXX")"
    original_hash="$(sha256sum "$PLACES_FILE" | awk '{print $1}')"

    if ! awk -v uri="$tools_uri" -v id="$bookmark_id" '
        /^[[:space:]]*<\/xbel>[[:space:]]*$/ && !inserted {
            print " <bookmark href=\"" uri "\">"
            print "  <title>Werkzeuge</title>"
            print "  <info>"
            print "   <metadata owner=\"http://freedesktop.org\">"
            print "    <bookmark:icon name=\"folder-development\"/>"
            print "   </metadata>"
            print "   <metadata owner=\"http://www.kde.org\">"
            print "    <ID>" id "</ID>"
            print "    <isSystemItem>false</isSystemItem>"
            print "   </metadata>"
            print "  </info>"
            print " </bookmark>"
            inserted = 1
        }
        { print }
        END { if (!inserted) exit 42 }
    ' "$PLACES_FILE" > "$prepared_file"; then
        rm -f -- "$prepared_file"
        record_failure "Dolphin-Eintrag konnte nicht sicher vorbereitet werden."
        return 1
    fi

    if replace_places_file "$prepared_file" "$original_hash"; then
        printf '%s\n' "$tools_uri" > "$PIN_STATE_FILE"
        chmod 0600 -- "$PIN_STATE_FILE"
        CHANGED_ITEMS+=("Dolphin-Verknüpfung → Werkzeuge")
        return 0
    fi

    return 1
}

unpin_tools_folder_in_dolphin_if_managed() {
    local tools_uri=""
    local places_dir=""
    local prepared_file=""
    local original_hash=""

    [[ -f "$PIN_STATE_FILE" ]] || return 0
    IFS= read -r tools_uri < "$PIN_STATE_FILE"

    if [[ ! -f "$PLACES_FILE" ]] ||
       ! places_file_contains_uri "$tools_uri"; then
        rm -f -- "$PIN_STATE_FILE"
        return 0
    fi

    if [[ -L "$PLACES_FILE" || ! -O "$PLACES_FILE" ]]; then
        record_failure "Dolphin-Seitenleistendatei ist kein reguläres eigenes Benutzerziel."
        return 1
    fi

    if ! validate_places_file "$PLACES_FILE"; then
        record_failure "Ungültige Dolphin-Seitenleistendatei wurde nicht verändert."
        return 1
    fi

    places_dir="$(dirname -- "$PLACES_FILE")"
    prepared_file="$(mktemp "$places_dir/.user-places.xbel.custom-linux.XXXXXXXX")"
    original_hash="$(sha256sum "$PLACES_FILE" | awk '{print $1}')"

    if ! awk -v uri="$tools_uri" '
        function flush() {
            if (target) {
                removed = 1
            } else {
                printf "%s", bookmark
            }
            bookmark = ""
            target = 0
            inside = 0
        }
        /<bookmark[[:space:]][^>]*>/ && !inside {
            inside = 1
            bookmark = $0 ORS
            target = index($0, "href=\"" uri "\"") > 0
            next
        }
        inside {
            bookmark = bookmark $0 ORS
            if (/<\/bookmark>/) flush()
            next
        }
        { print }
        END {
            if (inside || !removed) exit 42
        }
    ' "$PLACES_FILE" > "$prepared_file"; then
        rm -f -- "$prepared_file"
        record_failure "Verwalteter Dolphin-Eintrag konnte nicht entfernt werden."
        return 1
    fi

    if replace_places_file "$prepared_file" "$original_hash"; then
        rm -f -- "$PIN_STATE_FILE"
        REMOVED_ITEMS+=("Dolphin-Verknüpfung → Werkzeuge")
    fi
}

gtk_bookmarks_file_contains_uri() {
    local tools_uri="$1"

    [[ -f "$GTK_BOOKMARKS_FILE" ]] || return 1

    awk -v uri="$tools_uri" '
        $1 == uri { found = 1 }
        END { exit !found }
    ' "$GTK_BOOKMARKS_FILE"
}

backup_gtk_bookmarks_file() {
    local backup_dir=""

    backup_dir="$BACKUP_ROOT/$(date -u +%Y%m%dT%H%M%SZ)-$$"

    mkdir -p -- "$backup_dir"
    chmod 0700 -- "$BACKUP_ROOT" "$backup_dir"
    cp -a -- "$GTK_BOOKMARKS_FILE" "$backup_dir/gtk-bookmarks"
    chmod 0600 -- "$backup_dir/gtk-bookmarks"
    info "Sicherung erstellt: $backup_dir/gtk-bookmarks"
}

pin_tools_folder_in_nautilus() {
    local tools_uri=""
    local bookmarks_dir=""
    local prepared_file=""
    local original_hash="missing"
    local current_hash="missing"

    tools_uri="file://$(urlencode_path "$TOOL_ROOT")"

    if [[ -e "$GTK_BOOKMARKS_FILE" &&
          (-L "$GTK_BOOKMARKS_FILE" || ! -f "$GTK_BOOKMARKS_FILE" ||
           ! -O "$GTK_BOOKMARKS_FILE") ]]; then
        record_failure "Nautilus-Lesezeichendatei ist kein reguläres eigenes Benutzerziel."
        return 1
    fi

    if gtk_bookmarks_file_contains_uri "$tools_uri"; then
        CORRECT_ITEMS+=("Nautilus-Verknüpfung → Werkzeuge")
        return 0
    fi

    bookmarks_dir="$(dirname -- "$GTK_BOOKMARKS_FILE")"

    if [[ -e "$bookmarks_dir" &&
          (-L "$bookmarks_dir" || ! -d "$bookmarks_dir" ||
           ! -O "$bookmarks_dir") ]]; then
        record_failure "Nautilus-Konfigurationsordner ist kein reguläres eigenes Benutzerziel."
        return 1
    fi

    if [[ ! -d "$bookmarks_dir" ]]; then
        mkdir -p -- "$bookmarks_dir"
        chmod 0700 -- "$bookmarks_dir"
    fi

    prepared_file="$(mktemp "$bookmarks_dir/.bookmarks.custom-linux.XXXXXXXX")"

    if [[ -f "$GTK_BOOKMARKS_FILE" ]]; then
        original_hash="$(sha256sum "$GTK_BOOKMARKS_FILE" | awk '{print $1}')"
        cp -- "$GTK_BOOKMARKS_FILE" "$prepared_file"

        if [[ -s "$prepared_file" ]] &&
           [[ "$(tail -c 1 "$prepared_file" | wc -l)" -eq 0 ]]; then
            printf '\n' >> "$prepared_file"
        fi
    fi

    printf '%s %s\n' "$tools_uri" "Werkzeuge" >> "$prepared_file"
    chmod 0600 -- "$prepared_file"

    if gtk_bookmarks_file_contains_uri "$tools_uri"; then
        rm -f -- "$prepared_file"
        CORRECT_ITEMS+=("Nautilus-Verknüpfung → Werkzeuge")
        return 0
    fi

    if [[ -f "$GTK_BOOKMARKS_FILE" ]]; then
        current_hash="$(sha256sum "$GTK_BOOKMARKS_FILE" | awk '{print $1}')"
    fi

    if [[ "$current_hash" != "$original_hash" ]]; then
        rm -f -- "$prepared_file"
        record_failure "Nautilus-Lesezeichen wurden gleichzeitig verändert; nichts wurde übernommen."
        return 1
    fi

    [[ ! -f "$GTK_BOOKMARKS_FILE" ]] || backup_gtk_bookmarks_file
    mv -f -- "$prepared_file" "$GTK_BOOKMARKS_FILE"
    printf '%s\n' "$tools_uri" > "$NAUTILUS_PIN_STATE_FILE"
    chmod 0600 -- "$NAUTILUS_PIN_STATE_FILE"
    CHANGED_ITEMS+=("Nautilus-Verknüpfung → Werkzeuge")
}

unpin_tools_folder_in_nautilus_if_managed() {
    local tools_uri=""
    local bookmarks_dir=""
    local prepared_file=""
    local original_hash=""
    local current_hash=""

    [[ -f "$NAUTILUS_PIN_STATE_FILE" ]] || return 0
    IFS= read -r tools_uri < "$NAUTILUS_PIN_STATE_FILE"

    if [[ ! -f "$GTK_BOOKMARKS_FILE" ]] ||
       ! gtk_bookmarks_file_contains_uri "$tools_uri"; then
        rm -f -- "$NAUTILUS_PIN_STATE_FILE"
        return 0
    fi

    if [[ -L "$GTK_BOOKMARKS_FILE" || ! -O "$GTK_BOOKMARKS_FILE" ]]; then
        record_failure "Nautilus-Lesezeichendatei ist kein reguläres eigenes Benutzerziel."
        return 1
    fi

    bookmarks_dir="$(dirname -- "$GTK_BOOKMARKS_FILE")"
    prepared_file="$(mktemp "$bookmarks_dir/.bookmarks.custom-linux.XXXXXXXX")"
    original_hash="$(sha256sum "$GTK_BOOKMARKS_FILE" | awk '{print $1}')"

    if ! awk -v uri="$tools_uri" '
        $1 == uri && !removed {
            removed = 1
            next
        }
        { print }
        END { if (!removed) exit 42 }
    ' "$GTK_BOOKMARKS_FILE" > "$prepared_file"; then
        rm -f -- "$prepared_file"
        record_failure "Verwalteter Nautilus-Eintrag konnte nicht entfernt werden."
        return 1
    fi

    current_hash="$(sha256sum "$GTK_BOOKMARKS_FILE" | awk '{print $1}')"
    if [[ "$current_hash" != "$original_hash" ]]; then
        rm -f -- "$prepared_file"
        record_failure "Nautilus-Lesezeichen wurden gleichzeitig verändert; nichts wurde übernommen."
        return 1
    fi

    backup_gtk_bookmarks_file
    chmod 0600 -- "$prepared_file"
    mv -f -- "$prepared_file" "$GTK_BOOKMARKS_FILE"
    rm -f -- "$NAUTILUS_PIN_STATE_FILE"
    REMOVED_ITEMS+=("Nautilus-Verknüpfung → Werkzeuge")
}

pin_tools_folder() {
    local nautilus_running=0
    local dolphin_running=0
    local default_handler=""
    local active_file_manager=""

    pgrep -x nautilus >/dev/null 2>&1 && nautilus_running=1
    pgrep -x dolphin >/dev/null 2>&1 && dolphin_running=1

    if ((nautilus_running == 1 && dolphin_running == 0)); then
        active_file_manager="nautilus"
    elif ((dolphin_running == 1 && nautilus_running == 0)); then
        active_file_manager="dolphin"
    elif ((nautilus_running == 1 && dolphin_running == 1)); then
        record_failure "Nautilus und Dolphin laufen gleichzeitig; aktiver Dateimanager ist nicht eindeutig."
        return 1
    elif command -v xdg-mime >/dev/null 2>&1; then
        default_handler="$(xdg-mime query default inode/directory 2>/dev/null || true)"
        case "$default_handler" in
            org.gnome.Nautilus.desktop)
                active_file_manager="nautilus"
                ;;
            org.kde.dolphin.desktop)
                active_file_manager="dolphin"
                ;;
        esac
    fi

    case "$active_file_manager" in
        nautilus)
            info "Aktiver Dateimanager erkannt: Nautilus"
            if pin_tools_folder_in_nautilus; then
                unpin_tools_folder_in_dolphin_if_managed || true
            fi
            ;;
        dolphin)
            info "Aktiver Dateimanager erkannt: Dolphin"
            if pin_tools_folder_in_dolphin; then
                unpin_tools_folder_in_nautilus_if_managed || true
            fi
            ;;
        *)
            record_failure "Aktiver Dateimanager konnte nicht eindeutig erkannt werden. Öffne Nautilus oder Dolphin und starte den Vorgang erneut."
            return 1
            ;;
    esac
}

unpin_tools_folder_if_managed() {
    unpin_tools_folder_in_nautilus_if_managed || true
    unpin_tools_folder_in_dolphin_if_managed || true
}

print_list() {
    local heading="$1"
    shift
    local item=""

    (($# > 0)) || return 0
    printf '\n%s:\n' "$heading"
    for item in "$@"; do
        printf '  - %s\n' "$item"
    done
}

print_summary() {
    printf '\nWerkzeugübersicht – Zusammenfassung\n'
    printf '===================================\n'
    printf 'Erkannte Programme:     %s\n' "${#FOUND_ITEMS[@]}"
    printf 'Bereits korrekt:        %s\n' "${#CORRECT_ITEMS[@]}"
    printf 'Erstellt/aktualisiert:  %s\n' "${#CHANGED_ITEMS[@]}"
    printf 'Entfernt:               %s\n' "${#REMOVED_ITEMS[@]}"
    printf 'Übersprungen:           %s\n' "${#SKIPPED_ITEMS[@]}"
    printf 'Fehlgeschlagen/offen:   %s\n' "${#FAILED_ITEMS[@]}"
    print_list "Erkannte Programme und Kategorien" "${FOUND_ITEMS[@]}"
    print_list "Bereits korrekt" "${CORRECT_ITEMS[@]}"
    print_list "Erstellt oder aktualisiert" "${CHANGED_ITEMS[@]}"
    print_list "Entfernt" "${REMOVED_ITEMS[@]}"
    print_list "Übersprungen" "${SKIPPED_ITEMS[@]}"
    print_list "Fehlgeschlagen oder offen" "${FAILED_ITEMS[@]}"
}

main() {
    local row=""
    local id="" label="" category="" desktop_names=""
    local command_names="" package_names="" special_paths=""
    local icon="" mode="" launcher_name=""
    local launcher_count=0

    build_application_directories
    mkdir -p -- "$STATE_DIR" "$WRAPPER_DIR" "$BACKUP_ROOT"
    chmod 0700 -- "$STATE_DIR" "$WRAPPER_DIR" "$BACKUP_ROOT"

    exec 9> "$LOCK_FILE"
    command -v flock >/dev/null 2>&1 && flock -x 9

    WORK_DIR="$(mktemp -d "$STATE_DIR/work.XXXXXXXX")"
    trap '[[ -n "${WORK_DIR:-}" ]] && rm -rf -- "$WORK_DIR"' EXIT
    : > "$WORK_DIR/new-managed.list"
    : > "$WORK_DIR/new-wrappers.list"

    info "Prüfe bekannte installierte Programme und Werkzeuge."

    while IFS= read -r row; do
        IFS='|' read -r \
            id label category desktop_names command_names package_names \
            special_paths icon mode launcher_name <<< "$row"

        if detect_program \
            "$desktop_names" "$command_names" \
            "$package_names" "$special_paths" "$mode"; then
            create_program_launcher \
                "$id" "$label" "$category" "$icon" \
                "$mode" "$launcher_name" || true
        fi
    done <<< "$CATALOG"

    remove_obsolete_launchers
    remove_obsolete_wrappers
    remove_empty_directories
    launcher_count="$(wc -l < "$WORK_DIR/new-managed.list")"

    if ((launcher_count > 0)); then
        pin_tools_folder || true
    else
        SKIPPED_ITEMS+=("Keine bekannten installierten Programme")
        unpin_tools_folder_if_managed || true
    fi

    install -m 0600 -- "$WORK_DIR/new-managed.list" "$MANAGED_LIST"
    print_summary

    if ((${#FAILED_ITEMS[@]} > 0)); then
        printf '\n[WARNUNG] Die Werkzeugübersicht ist noch nicht vollständig.\n' >&2
        return 1
    fi

    if ((launcher_count > 0)); then
        printf '\n[OK] Installierte Programme sind unter %s gruppiert.\n' "$TOOL_ROOT"
    else
        printf '\n[INFO] Keine bekannten installierten Programme gefunden.\n'
    fi
}

main "$@"
